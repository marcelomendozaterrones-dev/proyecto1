## Resumen
Añadir 2 pestañas nuevas al modo Editor libre: **Doctores** (gestión + comisiones + reporte Excel por doctor) e **Instituciones** (campañas con precios especiales y vigencia que se aplican automáticamente al registrar pacientes).

## 1. Base de datos (nueva migración)

### Tabla `doctors_directory`
Catálogo unificado de doctores editables (reemplaza/extiende `custom_doctors`).
- `id`, `full_name` (único), `specialty`, `phone`, `email`, `notes`, timestamps.
- RLS: admin para todo.
- Migración: copia los nombres existentes de `custom_doctors` + los nombres distintos encontrados en `patient_registrations.doctor_name` y `studies.referring_doctor`.

### Tabla `doctor_commissions`
Comisión por doctor + estudio.
- `id`, `doctor_id` (fk a doctors_directory), `tarifario_item_id` (fk a tarifario_items, nullable), `commission_type` ('percent' | 'fixed'), `commission_value` numeric, `enabled` boolean default true, `is_default` boolean (cuando `tarifario_item_id` es null = aplica a todos los estudios sin regla específica).
- Único: (doctor_id, tarifario_item_id).
- RLS: admin.

### Tabla `institutions`
- `id`, `name`, `contact`, `phone`, `notes`, timestamps. RLS admin.

### Tabla `institution_campaigns`
- `id`, `institution_id`, `tarifario_item_id`, `special_price` numeric, `valid_from` date, `valid_to` date, `active` boolean.
- RLS admin (lectura admin).

### Cambios a `patient_registrations`
- Añadir columna `institution_id` (uuid, nullable) para trazar qué institución generó el precio especial.

## 2. Pestaña Doctores (`DoctorsTab.tsx`)
Visible siempre en admin (con botones de editar/agregar solo en modo Editor libre, si quieres lo dejamos abierto a admin normal también — confirmar).

Vista en 2 paneles:
- **Lista de doctores** (izquierda): buscador, botón "+ Agregar doctor", click para seleccionar.
- **Panel detalle** (derecha) del doctor seleccionado:
  - Pestañas internas:
    1. **Datos**: editar nombre, especialidad, teléfono, email.
    2. **Comisiones**: tabla con cada estudio del tarifario + columna comisión (% o S/. fijo) + switch "Activado". Permite también una fila "Por defecto" que aplica si no hay regla específica.
    3. **Pacientes**: tabla de `patient_registrations` filtrados por `doctor_name` con columnas: Fecha, Paciente, Estudios, Monto pagado, Comisión calculada, Aplica comisión (sí/no según switch).
  - Botón **"Exportar Excel"**: genera xlsx con: Nombre del doctor, fecha, paciente, estudio(s), monto pagado, comisión sí/no, monto comisión, total acumulado al final. Usa la librería `xlsx` (ya en deps si no, instalar `xlsx`).

## 3. Pestaña Instituciones (`InstitutionsTab.tsx`)
- Lista vacía al inicio + botón "+ Agregar institución".
- Al crear/editar: nombre, contacto, y sub-tabla de **campañas**: agregar fila con `estudio (select del tarifario)`, `precio especial`, `vigencia desde`, `vigencia hasta`, `activa`.
- Soporta múltiples estudios por institución.

## 4. Aplicar precio institucional al registrar paciente
En `PatientRegistrationTab.tsx`:
- Nuevo selector "Institución" (opcional, encima de Doctor solicitante).
- Al seleccionar institución → al añadir un estudio que tenga campaña activa (hoy entre `valid_from` y `valid_to`, `active=true`) → aplica automáticamente el `special_price` de la campaña, marca `special_price=true` y `special_reason="Campaña: <institución>"`.
- Guarda `institution_id` en el registro.

## 5. Detalles técnicos
- Nuevos componentes: `src/components/DoctorsTab.tsx`, `src/components/InstitutionsTab.tsx`, `src/components/CommissionsEditor.tsx`.
- Hook `useTarifario()` ya existe (vía `tarifario_items`); reutilizamos.
- Para Excel: `xlsx` library — `import * as XLSX from 'xlsx'`. Se descarga con `XLSX.writeFile`.
- `Admin.tsx`: registrar las 2 nuevas pestañas en el array de tabs (incluyendo persistencia de orden ya existente).
- Comisión calculada: si tipo `percent` → `monto_pagado_estudio * value/100`; si `fixed` → `value` por estudio. Si el switch `enabled=false` → 0 y se marca "No aplica".

## Fuera de alcance
- Pago/liquidación efectiva al doctor (solo reporte).
- Histórico de comisiones cambiadas en el tiempo (se aplica la comisión vigente al momento del reporte).

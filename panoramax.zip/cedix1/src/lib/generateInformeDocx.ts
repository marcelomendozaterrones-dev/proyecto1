import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  ImageRun,
  AlignmentType,
  Header,
  Footer,
  Table,
  TableRow,
  TableCell,
  WidthType,
  BorderStyle,
  ShadingType,
  HeightRule,
  VerticalAlign,
  TabStopType,
  TabStopPosition,
} from "docx";
import cedixLogo from "@/assets/panoramax-logo.jpg";
import firmaImg from "@/assets/informe-firma.jpg";
import { supabase } from "@/integrations/supabase/client";

export interface InformeDocxData {
  patientName: string;
  age: number | string;
  ticketCode: string;
  doctorName: string;
  motivo: string;
  /** Optional studies to try to find a panoramic radiograph among. */
  studies?: Array<{ id: string; study_type: string; file_name: string }>;
}

const fetchArrayBuffer = async (url: string): Promise<ArrayBuffer> => {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`No se pudo leer ${url}`);
  return await r.arrayBuffer();
};

const detectImageType = (
  fileName: string,
): "png" | "jpg" | "gif" | "bmp" => {
  const n = fileName.toLowerCase();
  if (n.endsWith(".png")) return "png";
  if (n.endsWith(".gif")) return "gif";
  if (n.endsWith(".bmp")) return "bmp";
  return "jpg";
};

const findPanoramic = (studies: InformeDocxData["studies"]) => {
  if (!studies?.length) return [];
  const isPano = (s: { study_type: string; file_name: string }) =>
    /panor/i.test(s.study_type || "") || /panor/i.test(s.file_name || "");
  return studies.filter(isPano);
};

const getSignedUrl = async (
  id: string,
): Promise<{ url: string; fileName: string } | null> => {
  try {
    const { data, error } = await supabase.functions.invoke("sign-study-url", {
      body: { study_id: id, action: "sign" },
    });
    if (error || !data?.url) return null;
    return { url: data.url as string, fileName: (data.file_name as string) || "panoramica.jpg" };
  } catch {
    return null;
  }
};

const triggerDownload = (blob: Blob, fileName: string) => {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1500);
};

const labelRun = (text: string) =>
  new TextRun({ text, font: "Times New Roman", size: 24 });

const valueRun = (text: string) =>
  new TextRun({ text, font: "Times New Roman", size: 24 });

const fieldParagraph = (label: string, value: string, secondLabel?: string, secondValue?: string) => {
  const children = [labelRun(`${label}\t: `), valueRun(value || "")];
  if (secondLabel) {
    children.push(new TextRun({ text: "\t", font: "Times New Roman", size: 24 }));
    children.push(labelRun(`${secondLabel}: `));
    children.push(valueRun(secondValue || ""));
  }
  return new Paragraph({
    tabStops: [
      { type: TabStopType.LEFT, position: 1500 },
      { type: TabStopType.LEFT, position: 5500 },
    ],
    spacing: { after: 120 },
    children,
  });
};

export async function buildInformeDocx(
  d: InformeDocxData,
): Promise<{ blob: Blob; fileName: string }> {
  return await buildInforme(d);
}


export async function fetchPanoramicBlob(
  d: InformeDocxData,
): Promise<{ blob: Blob; fileName: string } | null> {
  const panos = findPanoramic(d.studies);
  for (const p of panos) {
    const sig = await getSignedUrl(p.id);
    if (!sig) continue;
    try {
      const r = await fetch(sig.url);
      if (!r.ok) continue;
      const blob = await r.blob();
      return { blob, fileName: sig.fileName };
    } catch {
      // try next
    }
  }
  return null;
}

async function buildInforme(d: InformeDocxData): Promise<{ blob: Blob; fileName: string }> {
  const fecha = new Date().toLocaleDateString("es-PE");

  // Fetch logo + firma as ArrayBuffers
  const [logoBuf, firmaBuf] = await Promise.all([
    fetchArrayBuffer(cedixLogo),
    fetchArrayBuffer(firmaImg),
  ]);

  // Build the doc
  const headerLeftLines = ["Radiografías Extraorales", "Radiografías Intraorales", "Estudios para Ortodoncia"];

  const headerTable = new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [4680, 4680],
    borders: {
      top: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
      bottom: { style: BorderStyle.SINGLE, size: 18, color: "000000" },
      left: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
      right: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
      insideHorizontal: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
      insideVertical: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
    },
    rows: [
      new TableRow({
        children: [
          new TableCell({
            width: { size: 4680, type: WidthType.DXA },
            verticalAlign: VerticalAlign.CENTER,
            children: headerLeftLines.map(
              (line) =>
                new Paragraph({
                  spacing: { after: 40 },
                  children: [
                    new TextRun({
                      text: `•  ${line}`,
                      bold: true,
                      color: "0FA895",
                      font: "Arial",
                      size: 20,
                    }),
                  ],
                }),
            ),
          }),
          new TableCell({
            width: { size: 4680, type: WidthType.DXA },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                alignment: AlignmentType.RIGHT,
                children: [
                  new ImageRun({
                    type: "jpg",
                    data: logoBuf,
                    transformation: { width: 180, height: 70 },
                  } as any),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });

  const footerTable = new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [7000, 2360],
    borders: {
      top: { style: BorderStyle.SINGLE, size: 4, color: "000000" },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: "000000" },
      left: { style: BorderStyle.SINGLE, size: 4, color: "000000" },
      right: { style: BorderStyle.SINGLE, size: 4, color: "000000" },
      insideVertical: { style: BorderStyle.SINGLE, size: 4, color: "000000" },
      insideHorizontal: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
    },
    rows: [
      new TableRow({
        height: { value: 500, rule: HeightRule.ATLEAST },
        children: [
          new TableCell({
            width: { size: 7000, type: WidthType.DXA },
            shading: { fill: "0FA895", type: ShadingType.CLEAR, color: "auto" },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({
                    text: "Jr. Chinchaysuyo 245 - Zarate",
                    bold: true,
                    font: "Arial",
                    size: 22,
                  }),
                ],
              }),
            ],
          }),
          new TableCell({
            width: { size: 2360, type: WidthType.DXA },
            shading: { fill: "0FA895", type: ShadingType.CLEAR, color: "auto" },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({ text: "Tel. 7348119", bold: true, font: "Arial", size: 22 }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });

  const motivoLines = (d.motivo || "").split(/\r?\n/);
  const motivoParagraphs = motivoLines.map((line, idx) =>
    new Paragraph({
      spacing: { after: 80 },
      children:
        idx === 0
          ? [
              new TextRun({ text: "MOTIVO DE CONSULTA : ", bold: true, font: "Times New Roman", size: 24 }),
              new TextRun({ text: line, font: "Times New Roman", size: 24 }),
            ]
          : [new TextRun({ text: line, font: "Times New Roman", size: 24 })],
    }),
  );

  const doc = new Document({
    creator: "Panoramax 3D",
    title: `Informe ${d.ticketCode}`,
    styles: {
      default: { document: { run: { font: "Times New Roman", size: 24 } } },
    },
    sections: [
      {
        properties: {
          page: {
            size: { width: 12240, height: 15840 },
            margin: { top: 1080, right: 1440, bottom: 1080, left: 1440 },
          },
        },
        headers: {
          default: new Header({ children: [headerTable, new Paragraph("")] }),
        },
        footers: {
          default: new Footer({ children: [footerTable] }),
        },
        children: [
          new Paragraph({ spacing: { after: 120 }, children: [new TextRun("")] }),
          fieldParagraph("Paciente", d.patientName),
          fieldParagraph("Edad", `${d.age ?? ""} Años`, "Código", d.ticketCode),
          fieldParagraph("Doctor (a)", d.doctorName || "", "Fecha", fecha),
          new Paragraph({ spacing: { before: 240, after: 120 }, alignment: AlignmentType.CENTER, children: [
            new TextRun({ text: "INFORME ODONTOLOGICO RADIOGRAFICO", bold: true, underline: {}, font: "Times New Roman", size: 26 }),
          ] }),
          new Paragraph({ spacing: { after: 200 }, children: [
            new TextRun({ text: "A la evaluación de la Radiografía Panorámica se observa:", font: "Times New Roman", size: 24 }),
          ] }),
          new Paragraph({ spacing: { after: 200 }, children: [new TextRun("")] }),
          ...motivoParagraphs,
          new Paragraph({ spacing: { before: 600 }, children: [new TextRun("")] }),
          new Paragraph({ alignment: AlignmentType.CENTER, children: [
            new ImageRun({
              type: "jpg",
              data: firmaBuf,
              transformation: { width: 180, height: 70 },
            } as any),
          ] }),
        ],
      },
    ],
  });

  const blob = await Packer.toBlob(doc);
  const safeName = d.patientName.replace(/[^\w\s-]/g, "").trim().replace(/\s+/g, "_") || "Paciente";
  const fileName = `Informe_${safeName}_${d.ticketCode}.docx`;
  return { blob, fileName };
}

export async function generateAndDownloadInformeDocx(d: InformeDocxData) {
  const { blob, fileName } = await buildInforme(d);
  triggerDownload(blob, fileName);

  // Download panoramic radiograph(s) separately so the doctor receives them as images
  const safeName = d.patientName.replace(/[^\w\s-]/g, "").trim().replace(/\s+/g, "_") || "Paciente";
  const panos = findPanoramic(d.studies);
  let panoCount = 0;
  for (const p of panos) {
    const sig = await getSignedUrl(p.id);
    if (!sig) continue;
    try {
      const r = await fetch(sig.url);
      if (!r.ok) continue;
      const ab = await r.blob();
      panoCount++;
      const ext = sig.fileName.split(".").pop() || "jpg";
      const fname = `Panoramica_${safeName}_${d.ticketCode}${panos.length > 1 ? `_${panoCount}` : ""}.${ext}`;
      triggerDownload(ab, fname);
    } catch {
      // ignore
    }
  }
  return { panoCount };
}


export const getPeruWhatsAppPhone = (value: string) => {
  const digits = value.replace(/\D/g, "");
  if (!digits) return "";
  return digits.startsWith("51") ? digits : `51${digits}`;
};

const buildWhatsAppAppUrl = ({ phone, message }: { phone?: string; message: string }) => {
  const cleanPhone = (phone ?? "").replace(/\D/g, "");
  const text = encodeURIComponent(message);
  const query = cleanPhone ? `phone=${cleanPhone}&text=${text}` : `text=${text}`;

  return `whatsapp://send?${query}`;
};

const escapeHtml = (value: string) => {
  const div = document.createElement("div");
  div.textContent = value;
  return div.innerHTML;
};

export const openPendingExternalTab = () => {
  const tab = window.open("", "_blank");
  if (!tab) return null;

  try {
    tab.document.title = "Preparando WhatsApp";
    tab.document.body.innerHTML = "Preparando mensaje de WhatsApp…";
  } catch {
    // Some browsers restrict writing to the new tab; navigation still works.
  }

  return tab;
};

export const renderWhatsAppShareTab = (tab: Window | null, { phone, message }: { phone?: string; message: string }) => {
  if (!tab || tab.closed) return false;

  const appUrl = buildWhatsAppAppUrl({ phone, message });
  const cleanPhone = (phone ?? "").replace(/\D/g, "");
  const safeMessage = escapeHtml(message);
  const safeAppUrl = escapeHtml(appUrl);
  const safePhone = escapeHtml(cleanPhone || "Sin número registrado");

  try {
    tab.document.open();
    tab.document.write(`<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Enviar por WhatsApp</title><style>body{font-family:Arial,sans-serif;margin:0;background:#f8fafc;color:#0f172a}.wrap{max-width:760px;margin:40px auto;padding:24px}.panel{background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:24px;box-shadow:0 10px 30px rgba(15,23,42,.08)}h1{font-size:22px;margin:0 0 8px}.hint{color:#475569;margin:0 0 16px;line-height:1.45}.warning{background:#fff7ed;border:1px solid #fed7aa;color:#9a3412;border-radius:8px;padding:10px 12px;margin-bottom:16px;font-size:14px}.phone{font-weight:700;color:#0f172a}.actions{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px}a,button{appearance:none;border:0;border-radius:8px;padding:11px 14px;font-weight:700;text-decoration:none;cursor:pointer}.primary{background:#16a34a;color:#fff}.secondary{background:#e2e8f0;color:#0f172a}.msg{width:100%;min-height:260px;border:1px solid #cbd5e1;border-radius:8px;padding:12px;font:14px/1.45 Arial,sans-serif;box-sizing:border-box;white-space:pre-wrap}</style></head><body><main class="wrap"><section class="panel"><h1>Mensaje listo para WhatsApp</h1><p class="hint">El mensaje ya fue copiado. Usa WhatsApp instalado en esta computadora o pega manualmente el mensaje en tu celular.</p><div class="warning">WhatsApp Web está bloqueado por este navegador o red, por eso ya no se abrirá desde aquí. Número destino: <span class="phone">${safePhone}</span></div><div class="actions"><a class="primary" href="${safeAppUrl}">Abrir app WhatsApp</a><button class="secondary" id="copy">Copiar mensaje otra vez</button><button class="secondary" id="copyPhone">Copiar número</button></div><textarea class="msg" id="message" readonly>${safeMessage}</textarea></section></main><script>const message=document.getElementById('message');const phone='${safePhone}';document.getElementById('copy').addEventListener('click',async()=>{message.select();try{await navigator.clipboard.writeText(message.value)}catch{document.execCommand('copy')}});document.getElementById('copyPhone').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(phone)}catch{}});<\/script></body></html>`);
    tab.document.close();
    try {
      tab.opener = null;
    } catch {
      // Ignore browsers that prevent clearing opener.
    }
    return true;
  } catch {
    return false;
  }
};

export const closePendingExternalTab = (tab: Window | null) => {
  if (tab && !tab.closed) tab.close();
};
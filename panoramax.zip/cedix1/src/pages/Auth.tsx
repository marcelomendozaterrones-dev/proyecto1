import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, MapPin } from "lucide-react";
import BrandLogo from "@/components/BrandLogo";
import { SEDES, type SedeId } from "@/data/sedes";
import { setCurrentSede, getCurrentSede } from "@/hooks/useCurrentSede";
import { toast } from "sonner";
import PageBackground from "@/components/PageBackground";

const Auth = () => {
  const navigate = useNavigate();
  const [sede, setSede] = useState<SedeId | "">(() => getCurrentSede());
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [masterKey, setMasterKey] = useState("");
  const [loading, setLoading] = useState(false);
  const ADMIN_MASTER_KEY = "CEDIX123.";

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate("/admin");
    });
  }, [navigate]);

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!sede) return toast.error("Selecciona la sede");
    setLoading(true);
    const { data: signInData, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) { setLoading(false); return toast.error(error.message); }

    // Enforce sede restrictions if any are configured for this user
    const uid = signInData.user?.id;
    if (uid) {
      const { data: allowed } = await supabase
        .from("user_sede_access")
        .select("sede")
        .eq("user_id", uid);
      if (allowed && allowed.length > 0) {
        const allowedSedes = allowed.map((r: any) => r.sede);
        if (!allowedSedes.includes(sede)) {
          await supabase.auth.signOut();
          setLoading(false);
          const names = allowedSedes
            .map((id: string) => SEDES.find((s) => s.id === id)?.name ?? id)
            .join(", ");
          return toast.error(`Esta cuenta solo puede acceder a: ${names}`);
        }
      }
    }
    setLoading(false);
    setCurrentSede(sede);
    navigate("/admin");
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!sede) return toast.error("Selecciona la sede");
    if (masterKey !== ADMIN_MASTER_KEY) {
      return toast.error("Clave maestra de administrador incorrecta");
    }
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email, password,
      options: { emailRedirectTo: `${window.location.origin}/admin` },
    });
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Cuenta de administrador creada. Ya puedes iniciar sesión.");
  };

  return (
    <PageBackground>
      <header className="container py-6">
        <Link to="/"><BrandLogo className="h-18 md:h-20 w-auto" /></Link>
      </header>
      <main className="flex-1 container max-w-md flex items-center">
        <Card className="w-full p-6 shadow-elevated">
          <h1 className="text-2xl font-bold mb-1">Acceso administrador</h1>
          <p className="text-sm text-muted-foreground mb-6">Inicia sesión para subir y gestionar estudios.</p>
          <div className="mb-4">
            <Label className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5 text-primary" /> Sede</Label>
            <Select value={sede} onValueChange={(v) => setSede(v as SedeId)}>
              <SelectTrigger><SelectValue placeholder="Selecciona la sede de trabajo" /></SelectTrigger>
              <SelectContent>
                {SEDES.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <Tabs defaultValue="signin">
            <TabsList className="grid grid-cols-2 w-full mb-4">
              <TabsTrigger value="signin">Iniciar sesión</TabsTrigger>
              <TabsTrigger value="signup">Registrarme</TabsTrigger>
            </TabsList>
            <TabsContent value="signin">
              <form onSubmit={handleSignIn} className="space-y-3">
                <div><Label>Email</Label><Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></div>
                <div><Label>Contraseña</Label><Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required /></div>
                <Button className="w-full bg-gradient-hero" disabled={loading}>
                  {loading && <Loader2 className="h-4 w-4 animate-spin mr-2" />}Entrar
                </Button>
              </form>
            </TabsContent>
            <TabsContent value="signup">
              <form onSubmit={handleSignUp} className="space-y-3">
                <div><Label>Email</Label><Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></div>
                <div><Label>Contraseña</Label><Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} minLength={6} required /></div>
                <div><Label>Clave maestra de administrador</Label><Input type="password" value={masterKey} onChange={(e) => setMasterKey(e.target.value)} required placeholder="Requerida para crear admin" /></div>
                <Button className="w-full bg-gradient-hero" disabled={loading}>
                  {loading && <Loader2 className="h-4 w-4 animate-spin mr-2" />}Crear cuenta
                </Button>
                <p className="text-xs text-muted-foreground">Solo personal autorizado con la clave maestra puede crear cuentas de administrador.</p>
              </form>
            </TabsContent>
          </Tabs>
        </Card>
      </main>
    </PageBackground>
  );
};

export default Auth;

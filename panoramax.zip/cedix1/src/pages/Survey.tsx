import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Star, Loader2, CheckCircle2 } from "lucide-react";
import BrandLogo from "@/components/BrandLogo";
import { toast } from "sonner";
import { getSede, getSedeName } from "@/components/SedeGate";
import marlon from "@/assets/tech-marlon.jpg";
import lenin from "@/assets/tech-lenin.jpg";
import gaviota from "@/assets/tech-gaviota.jpg";
import PageBackground from "@/components/PageBackground";

const TECHS = [
  { id: "Marlon Mendoza Navarro", photo: marlon },
  { id: "Lenin Huaman", photo: lenin },
  { id: "Gaviota Gomez", photo: gaviota },
];

const Stars = ({ value, onChange }: { value: number; onChange: (v: number) => void }) => (
  <div className="flex gap-1">
    {[1, 2, 3, 4, 5].map((n) => (
      <button
        key={n}
        type="button"
        onClick={() => onChange(n)}
        className="transition-transform hover:scale-110"
        aria-label={`${n} estrellas`}
      >
        <Star
          className={`h-8 w-8 ${n <= value ? "fill-primary text-primary" : "text-muted-foreground/40"}`}
        />
      </button>
    ))}
  </div>
);

const Survey = () => {
  const navigate = useNavigate();
  const [tech, setTech] = useState<string>("");
  const [techRating, setTechRating] = useState(0);
  const [techObs, setTechObs] = useState("");
  const [serviceRating, setServiceRating] = useState(0);
  const [recommendations, setRecommendations] = useState("");
  const [patientCode, setPatientCode] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tech) return toast.error("Selecciona el técnico que te atendió");
    if (!techRating || !serviceRating) return toast.error("Califica al técnico y al servicio");

    setSubmitting(true);
    const { error } = await supabase.from("surveys").insert({
      technician: tech,
      technician_rating: techRating,
      technician_observation: techObs.trim() || null,
      service_rating: serviceRating,
      recommendations: recommendations.trim() || null,
      patient_code: patientCode.trim() || null,
      sede: getSede() || null,
    });
    setSubmitting(false);
    if (error) return toast.error(error.message);
    setDone(true);
  };

  if (done) {
    return (
      <PageBackground className="flex items-center justify-center p-6">
        <Card className="p-10 max-w-md text-center shadow-elevated">
          <CheckCircle2 className="h-16 w-16 text-primary mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">¡Gracias por tu opinión!</h2>
          <p className="text-muted-foreground mb-6">Tu encuesta ha sido registrada con éxito.</p>
          <Button onClick={() => navigate("/")} className="bg-gradient-hero">Volver al inicio</Button>
        </Card>
      </PageBackground>
    );
  }

  return (
    <PageBackground>
      <header className="container flex items-center justify-between py-6">
        <Link to="/"><BrandLogo className="h-16 w-auto" /></Link>
        <Link to="/"><Button variant="ghost" size="sm"><ArrowLeft className="h-4 w-4 mr-1" /> Volver</Button></Link>
      </header>

      <main className="container max-w-3xl pb-16">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-2">Encuesta de atención</h1>
          <p className="text-muted-foreground">Tu opinión nos ayuda a mejorar nuestro servicio.</p>
          {getSedeName() && <p className="text-xs text-primary mt-1">{getSedeName()}</p>}
        </div>

        <form onSubmit={submit} className="space-y-6">
          <Card className="p-6 shadow-soft">
            <h2 className="font-semibold text-lg mb-4">1. ¿Qué técnico te atendió?</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {TECHS.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setTech(t.id)}
                  className={`rounded-xl border-2 p-4 text-center transition-all hover:shadow-soft ${
                    tech === t.id ? "border-primary bg-accent shadow-soft" : "border-border bg-background"
                  }`}
                >
                  <img src={t.photo} alt={t.id} loading="lazy" width={512} height={512}
                    className="h-24 w-24 rounded-full object-cover mx-auto mb-2 border-2 border-primary/20" />
                  <div className="font-medium text-sm">{t.id}</div>
                </button>
              ))}
            </div>
          </Card>

          <Card className="p-6 shadow-soft space-y-4">
            <div>
              <h2 className="font-semibold text-lg mb-2">2. Calificación al técnico</h2>
              <Stars value={techRating} onChange={setTechRating} />
            </div>
            <div>
              <Label>Observaciones sobre el técnico (opcional)</Label>
              <Textarea value={techObs} onChange={(e) => setTechObs(e.target.value)} rows={3}
                placeholder="Comparte tu experiencia con el personal..." maxLength={500} />
            </div>
          </Card>

          <Card className="p-6 shadow-soft space-y-4">
            <div>
              <h2 className="font-semibold text-lg mb-2">3. Calificación del servicio</h2>
              <Stars value={serviceRating} onChange={setServiceRating} />
            </div>
            <div>
              <Label>Recomendaciones para mejorar (opcional)</Label>
              <Textarea value={recommendations} onChange={(e) => setRecommendations(e.target.value)} rows={3}
                placeholder="¿Qué podemos mejorar?" maxLength={500} />
            </div>
          </Card>

          <Card className="p-6 shadow-soft">
            <Label>Código de paciente (opcional)</Label>
            <Input value={patientCode} onChange={(e) => setPatientCode(e.target.value)} placeholder="PAC-001" maxLength={50} />
          </Card>

          <Button type="submit" disabled={submitting} size="lg" className="w-full bg-gradient-hero shadow-elevated">
            {submitting && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
            Enviar encuesta
          </Button>
        </form>
      </main>
    </PageBackground>
  );
};

export default Survey;

import { useEffect, useMemo, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import BrandLogo from "@/components/BrandLogo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Loader2, LogOut, Search, FileDown, FolderOpen, Stethoscope, Calendar, MapPin, Eye, ChevronLeft, ChevronRight, Users, FileText, Inbox, ZoomIn, ZoomOut, Maximize2 } from "lucide-react";
import { toast } from "sonner";
import { clearDoctorSession, getDoctorSession } from "./DoctorAuth";
import { TransformWrapper, TransformComponent } from "react-zoom-pan-pinch";
interface Patient {
  id: string;
  ticket_code: string;
  sede: string;
  first_names: string;
  last_names: string;
  doc_number: string | null;
  age: number | null;
  items: any;
  total: number;
  created_at: string;
}

interface Study {
  id: string;
  study_type: string;
  file_name: string;
  file_path: string;
  notes: string | null;
  created_at: string;
}

type PreviewType = "image" | "pdf" | "other";
type PreviewState = { studyId: string; url: string | null; name: string; type: PreviewType; loading: boolean };

const SEDE_LABEL: Record<string, string> = { sjl: "San Juan de Lurigancho", surco: "Surco", sanborja: "San Borja" };
const PAGE_SIZE = 10;

export default function DoctorPortal() {
  const navigate = useNavigate();
  const session = getDoctorSession();
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Patient | null>(null);
  const [studies, setStudies] = useState<Study[]>([]);
  const [loadingStudies, setLoadingStudies] = useState(false);
  const [preview, setPreview] = useState<PreviewState | null>(null);
  const [signedUrlCache, setSignedUrlCache] = useState<Record<string, { url: string; expiresAt: number }>>({});

  useEffect(() => {
    if (!session?.full_name) { navigate("/doctor"); return; }
    if (session.must_change) { navigate("/doctor/cambiar-clave"); return; }
    (async () => {
      const { data, error } = await supabase.rpc("doctor_patients", { _token: session.token });
      setLoading(false);
      if (error) return toast.error(error.message);
      setPatients((data as any) ?? []);
    })();
  }, [session, navigate]);

  const filtered = useMemo(() => {
    const t = q.trim().toUpperCase();
    if (!t) return patients;
    return patients.filter((p) =>
      `${p.first_names} ${p.last_names}`.toUpperCase().includes(t) ||
      (p.doc_number ?? "").includes(t) || p.ticket_code.includes(t)
    );
  }, [patients, q]);

  useEffect(() => { setPage(1); }, [q]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageItems = useMemo(
    () => filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE),
    [filtered, page]
  );

  const openPatient = async (p: Patient) => {
    setSelected(p); setStudies([]); setLoadingStudies(true);
    const { data, error } = await supabase.rpc("doctor_patient_studies", {
      _token: session.token, _patient_code: p.ticket_code,
    });
    setLoadingStudies(false);
    if (error) return toast.error(error.message);
    setStudies((data as any) ?? []);
  };

  const getPreviewType = (fileName: string): PreviewType => {
    const ext = (fileName.split(".").pop() || "").toLowerCase();
    return ["jpg","jpeg","png","webp","gif","bmp","heic","heif","avif","tif","tiff"].includes(ext) ? "image"
      : ext === "pdf" ? "pdf" : "other";
  };

  const getSignedUrl = async (s: Study, options?: { silent?: boolean }) => {
    const cached = signedUrlCache[s.id];
    if (cached && cached.expiresAt > Date.now()) return cached.url;

    const { data, error } = await supabase.functions.invoke("doctor-study-url", {
      body: { token: session.token, study_id: s.id },
    });
    if (error || !data?.url) {
      if (!options?.silent) toast.error(data?.error || error?.message || "No se pudo generar el enlace");
      return null;
    }
    setSignedUrlCache((prev) => ({ ...prev, [s.id]: { url: data.url as string, expiresAt: Date.now() + 240_000 } }));
    return data.url as string;
  };

  useEffect(() => {
    if (!studies.length) return;
    const studiesToPrefetch = studies
      .filter((s) => !signedUrlCache[s.id] || signedUrlCache[s.id].expiresAt <= Date.now())
      .slice(0, 8);
    if (!studiesToPrefetch.length) return;

    const timer = window.setTimeout(() => {
      studiesToPrefetch.forEach((s) => void getSignedUrl(s, { silent: true }));
    }, 250);

    return () => window.clearTimeout(timer);
  }, [studies]);

  const download = async (s: Study) => {
    const { data, error } = await supabase.functions.invoke("doctor-study-url", {
      body: { token: session.token, study_id: s.id, download: true },
    });
    if (error || !data?.url) {
      toast.error(data?.error || error?.message || "No se pudo generar el enlace");
      return;
    }
    // Native download: browser handles streaming & progress bar.
    window.location.href = data.url as string;
  };

  const previewStudy = async (s: Study) => {
    const type = getPreviewType(s.file_name);
    const cached = signedUrlCache[s.id];
    setPreview({ studyId: s.id, url: cached?.expiresAt > Date.now() ? cached.url : null, name: s.file_name, type, loading: !cached || cached.expiresAt <= Date.now() });
    if (cached && cached.expiresAt > Date.now()) return;

    const url = await getSignedUrl(s); if (!url) { setPreview((current) => current?.studyId === s.id ? null : current); return; }
    setPreview((current) => current?.studyId === s.id ? { ...current, url, loading: false } : current);
  };

  const logout = () => { clearDoctorSession(); navigate("/"); };

  return (
    <div className="min-h-screen bg-gradient-soft">
      <header className="container py-5 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3"><BrandLogo className="h-12 w-auto" /></Link>
        <div className="flex items-center gap-3">
          <span className="hidden sm:inline-flex items-center gap-1.5 text-xs bg-emerald-100 text-emerald-900 rounded-full px-3 py-1">
            <Stethoscope className="h-3.5 w-3.5" /> Dr(a). {session?.full_name}
          </span>
          <Button variant="outline" size="sm" onClick={logout}><LogOut className="h-4 w-4 mr-1" /> Salir</Button>
        </div>
      </header>

      <main className="container py-6 max-w-6xl">
        {!selected ? (
          <Card className="p-5 md:p-6 shadow-elevated">
            <div className="flex items-center justify-between gap-3 mb-4 flex-wrap">
              <div>
                <h1 className="text-xl md:text-2xl font-bold">Mis pacientes</h1>
                <p className="text-sm text-muted-foreground">Pacientes que te tienen como doctor solicitante.</p>
              </div>
              <div className="relative w-full sm:w-72">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input className="pl-8" placeholder="Buscar nombre, DNI o talón" value={q} onChange={(e) => setQ(e.target.value)} />
              </div>
            </div>
            {loading ? (
              <div className="py-10 flex justify-center"><Loader2 className="h-5 w-5 animate-spin" /></div>
            ) : filtered.length === 0 ? (
              <EmptyPatients />
            ) : (
              <>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead><tr className="text-left text-xs text-muted-foreground border-b">
                      <th className="py-2 px-2">Talón</th><th className="py-2 px-2">Paciente</th><th className="py-2 px-2">DNI</th>
                      <th className="py-2 px-2">Edad</th><th className="py-2 px-2">Sede</th><th className="py-2 px-2">Fecha</th><th></th>
                    </tr></thead>
                    <tbody>
                      {pageItems.map((p) => (
                        <tr key={p.id} className="border-b hover:bg-accent/50 cursor-pointer" onClick={() => openPatient(p)}>
                          <td className="py-2 px-2 font-mono text-xs">{p.ticket_code}</td>
                          <td className="py-2 px-2 font-medium">{p.first_names} {p.last_names}</td>
                          <td className="py-2 px-2">{p.doc_number ?? "—"}</td>
                          <td className="py-2 px-2">{p.age ?? "—"}</td>
                          <td className="py-2 px-2 text-xs">{SEDE_LABEL[p.sede] ?? p.sede}</td>
                          <td className="py-2 px-2 text-xs">{new Date(p.created_at).toLocaleDateString()}</td>
                          <td className="py-2 px-2 text-right">
                            <Button size="sm" variant="outline" onClick={(e) => { e.stopPropagation(); openPatient(p); }}>
                              <FolderOpen className="h-4 w-4 mr-1" /> Ver estudios
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="flex items-center justify-between mt-4 text-sm">
                  <span className="text-muted-foreground text-xs">
                    Mostrando {(page - 1) * PAGE_SIZE + 1}–{Math.min(page * PAGE_SIZE, filtered.length)} de {filtered.length}
                  </span>
                  <div className="flex items-center gap-1">
                    <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    {Array.from({ length: totalPages }, (_, i) => i + 1).slice(Math.max(0, page - 3), Math.max(0, page - 3) + 5).map((n) => (
                      <Button key={n} size="sm" variant={n === page ? "default" : "outline"} onClick={() => setPage(n)} className="min-w-9">
                        {n}
                      </Button>
                    ))}
                    <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </>
            )}
          </Card>
        ) : (
          <Card className="p-5 md:p-6 shadow-elevated">
            <Button variant="ghost" size="sm" className="mb-3" onClick={() => setSelected(null)}>← Volver a la lista</Button>
            <h2 className="text-xl font-bold">{selected.first_names} {selected.last_names}</h2>
            <div className="text-xs text-muted-foreground flex flex-wrap gap-3 mt-1 mb-4">
              <span className="font-mono">{selected.ticket_code}</span>
              <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" /> {SEDE_LABEL[selected.sede] ?? selected.sede}</span>
              <span className="inline-flex items-center gap-1"><Calendar className="h-3 w-3" /> {new Date(selected.created_at).toLocaleDateString()}</span>
              {selected.age != null && <span>Edad: {selected.age}</span>}
            </div>

            <h3 className="font-semibold text-sm mb-2">Estudios / Informes</h3>
            {loadingStudies ? (
              <div className="py-6 flex justify-center"><Loader2 className="h-5 w-5 animate-spin" /></div>
            ) : studies.length === 0 ? (
              <EmptyStudies />
            ) : (
              <div className="space-y-2">
                {studies.map((s) => (
                  <div key={s.id} className="flex items-center justify-between border rounded-lg p-3 hover:bg-accent/40 gap-3 flex-wrap">
                    <div className="min-w-0 flex items-center gap-3">
                      <div className="h-10 w-10 rounded-md bg-primary/10 text-primary flex items-center justify-center shrink-0">
                        <FileText className="h-5 w-5" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-medium truncate">{s.study_type}</div>
                        <div className="text-xs text-muted-foreground truncate">{s.file_name}</div>
                        {s.notes && <div className="text-xs italic text-muted-foreground truncate">{s.notes}</div>}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onMouseEnter={() => void getSignedUrl(s, { silent: true })}
                        onFocus={() => void getSignedUrl(s, { silent: true })}
                        onClick={() => previewStudy(s)}
                      >
                        <Eye className="h-4 w-4 mr-1" /> Vista previa
                      </Button>
                      <Button size="sm" onClick={() => download(s)}>
                        <FileDown className="h-4 w-4 mr-1" /> Descargar
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        )}
      </main>

      <Dialog open={!!preview} onOpenChange={(o) => !o && setPreview(null)}>
        <DialogContent className="max-w-[100vw] sm:max-w-5xl w-screen sm:w-auto h-[100dvh] sm:h-auto max-h-[100dvh] sm:max-h-[90vh] p-0 sm:p-6 gap-0 rounded-none sm:rounded-lg flex flex-col">
          <DialogHeader className="px-4 py-3 sm:p-0 border-b sm:border-0 shrink-0">
            <DialogTitle className="truncate text-sm sm:text-base pr-8">{preview?.name}</DialogTitle>
          </DialogHeader>
          {preview?.loading ? (
            <div className="flex-1 min-h-[70vh] bg-black/95 text-primary-foreground flex flex-col items-center justify-center gap-3">
              <Loader2 className="h-8 w-8 animate-spin" />
              <p className="text-sm">Abriendo vista previa...</p>
            </div>
          ) : preview?.type === "image" && preview.url ? (
            <TransformWrapper
              initialScale={1}
              minScale={1}
              maxScale={8}
              doubleClick={{ mode: "toggle", step: 2 }}
              wheel={{ step: 0.15 }}
              pinch={{ step: 5 }}
            >
              {({ zoomIn, zoomOut, resetTransform }) => (
                <>
                  <div className="absolute bottom-4 right-4 z-10 flex flex-col gap-2 bg-background/90 backdrop-blur rounded-lg p-1 shadow-elevated border">
                    <Button size="icon" variant="ghost" onClick={() => zoomIn()} className="h-9 w-9"><ZoomIn className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => zoomOut()} className="h-9 w-9"><ZoomOut className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => resetTransform()} className="h-9 w-9"><Maximize2 className="h-4 w-4" /></Button>
                  </div>
                  <TransformComponent
                    wrapperClass="!w-full !h-full flex-1 bg-black/95"
                    contentClass="!w-full !h-full flex items-center justify-center"
                  >
                    <img src={preview.url} alt={preview.name} className="max-w-full max-h-full object-contain select-none" draggable={false} />
                  </TransformComponent>
                </>
              )}
            </TransformWrapper>
          ) : preview?.type === "pdf" && preview.url ? (
            <iframe src={preview.url} title={preview.name} className="w-full flex-1 sm:h-[75vh] border-0 sm:border sm:rounded" />
          ) : null}
        </DialogContent>
      </Dialog>

    </div>
  );
}

function EmptyPatients() {
  return (
    <div className="py-10 flex flex-col items-center text-center gap-4">
      <div className="grid grid-cols-3 gap-3 max-w-md w-full opacity-90">
        {[Users, FileText, Inbox].map((Icon, i) => (
          <div key={i} className="aspect-square rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/10 flex items-center justify-center">
            <Icon className="h-8 w-8 text-primary/60" />
          </div>
        ))}
      </div>
      <div>
        <p className="font-medium">Aún no tienes pacientes registrados</p>
        <p className="text-sm text-muted-foreground max-w-sm">Cuando un paciente te indique como doctor solicitante, aparecerá aquí automáticamente.</p>
      </div>
    </div>
  );
}

function EmptyStudies() {
  return (
    <div className="py-10 flex flex-col items-center text-center gap-3">
      <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
        <FileText className="h-8 w-8 text-primary/60" />
      </div>
      <div>
        <p className="font-medium">Sin estudios cargados</p>
        <p className="text-sm text-muted-foreground">Aún no se han subido estudios o informes para este paciente.</p>
      </div>
    </div>
  );
}

import { useEffect, useMemo, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import BrandLogo from "@/components/BrandLogo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Stethoscope, Copy, Search, Plus, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { DOCTORS } from "@/data/doctors";
import PageBackground from "@/components/PageBackground";

const SESSION_KEY = "cedix.doctor";
export const getDoctorSession = () => {
  try { return JSON.parse(localStorage.getItem(SESSION_KEY) || "null"); } catch { return null; }
};
export const setDoctorSession = (s: any) => localStorage.setItem(SESSION_KEY, JSON.stringify(s));
export const clearDoctorSession = () => localStorage.removeItem(SESSION_KEY);

export default function DoctorAuth() {
  const navigate = useNavigate();
  const [tab, setTab] = useState("login");

  useEffect(() => {
    const s = getDoctorSession();
    if (s?.full_name) {
      if (s.must_change) navigate("/doctor/cambiar-clave");
      else navigate("/doctor/portal");
    }
  }, [navigate]);

  return (
    <PageBackground>
      <header className="container py-6 flex items-center justify-between">
        <Link to="/"><BrandLogo className="h-18 md:h-20 w-auto" /></Link>
        <button
          onClick={() => { localStorage.removeItem("cedix.role"); localStorage.removeItem("cedix.sede"); navigate("/"); }}
          className="text-sm text-muted-foreground hover:text-foreground inline-flex items-center gap-1"
        >
          <ArrowLeft className="h-4 w-4" /> Volver
        </button>
      </header>
      <main className="flex-1 container max-w-xl flex items-start py-4">
        <Card className="w-full p-6 md:p-8 shadow-elevated">
          <div className="flex items-center gap-3 mb-2">
            <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
              <Stethoscope className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-bold">Hola, doctor(a)</h1>
              <p className="text-sm text-muted-foreground">Bienvenido al portal profesional Panoramax 3D.</p>
            </div>
          </div>
          <Tabs value={tab} onValueChange={setTab} className="mt-4">
            <TabsList className="grid grid-cols-2 w-full mb-4">
              <TabsTrigger value="login">Ya tengo cuenta</TabsTrigger>
              <TabsTrigger value="register">Es mi primera vez</TabsTrigger>
            </TabsList>
            <TabsContent value="login"><LoginForm /></TabsContent>
            <TabsContent value="register"><RegisterForm onDone={() => setTab("login")} /></TabsContent>
          </Tabs>
        </Card>
      </main>
    </PageBackground>
  );
}

function NameAutocomplete({ value, onChange, extra }: { value: string; onChange: (v: string) => void; extra: string[] }) {
  const [open, setOpen] = useState(false);
  const all = useMemo(() => Array.from(new Set([...DOCTORS, ...extra])).sort(), [extra]);
  const results = useMemo(() => {
    const t = value.trim().toUpperCase();
    if (!t) return [];
    return all.filter((d) => d.includes(t)).slice(0, 10);
  }, [value, all]);
  return (
    <div className="relative">
      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          className="pl-8"
          value={value}
          placeholder="Escribe tu nombre completo"
          onChange={(e) => { onChange(e.target.value.toUpperCase()); setOpen(true); }}
          onFocus={() => setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 150)}
        />
      </div>
      {open && results.length > 0 && (
        <div className="absolute z-20 mt-1 w-full bg-popover border border-border rounded-lg shadow-elevated max-h-56 overflow-auto">
          {results.map((d) => (
            <button key={d} type="button" onMouseDown={(e) => { e.preventDefault(); onChange(d); setOpen(false); }}
              className="w-full text-left px-3 py-2 text-sm hover:bg-accent">{d}</button>
          ))}
        </div>
      )}
    </div>
  );
}

function LoginForm() {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [pwd, setPwd] = useState("");
  const [loading, setLoading] = useState(false);
  const [extra, setExtra] = useState<string[]>([]);

  useEffect(() => {
    supabase.rpc("doctor_all_known_names").then(({ data }) => {
      setExtra((data as any[] | null)?.map((r) => r.full_name) ?? []);
    });
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !pwd) return;
    setLoading(true);
    const { data, error } = await supabase.rpc("doctor_login", { _full_name: name, _password: pwd });
    setLoading(false);
    if (error) return toast.error(error.message);
    const sess = data as any;
    setDoctorSession(sess);
    if (sess.must_change) { toast.info("Debes cambiar tu contraseña inicial."); navigate("/doctor/cambiar-clave"); }
    else { toast.success("Bienvenido(a)"); navigate("/doctor/portal"); }
  };

  return (
    <form onSubmit={submit} className="space-y-3">
      <div>
        <Label>Nombre completo</Label>
        <NameAutocomplete value={name} onChange={setName} extra={extra} />
      </div>
      <div><Label>Contraseña</Label><Input type="password" value={pwd} onChange={(e) => setPwd(e.target.value)} required /></div>
      <Button className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 text-white" disabled={loading}>
        {loading && <Loader2 className="h-4 w-4 animate-spin mr-2" />} Iniciar sesión
      </Button>
    </form>
  );
}

function RegisterForm({ onDone }: { onDone: () => void }) {
  const [name, setName] = useState("");
  const [extra, setExtra] = useState<string[]>([]);
  const [cop, setCop] = useState("");
  const [specialty, setSpecialty] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [pwd, setPwd] = useState("");
  const [pwd2, setPwd2] = useState("");
  const [loading, setLoading] = useState(false);
  const [created, setCreated] = useState<string | null>(null);

  useEffect(() => {
    supabase.rpc("doctor_all_known_names").then(({ data }) => {
      setExtra((data as any[] | null)?.map((r) => r.full_name) ?? []);
    });
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return toast.error("Ingresa tu nombre");
    if (!email.trim() || !email.includes("@")) return toast.error("Ingresa un correo válido");
    if (pwd.length < 6) return toast.error("La contraseña debe tener más de 5 caracteres");
    if (pwd !== pwd2) return toast.error("Las contraseñas no coinciden");
    setLoading(true);
    const { data, error } = await supabase.rpc("doctor_register", {
      _full_name: name, _cop: cop, _specialty: specialty, _email: email, _phone: phone, _password: pwd,
    } as any);
    setLoading(false);
    if (error) return toast.error(error.message);
    const r = data as any;
    setCreated(r.full_name);
    toast.success("Cuenta creada");
  };

  if (created) {
    return (
      <div className="space-y-4">
        <div className="rounded-xl border-2 border-emerald-300 bg-emerald-50 p-4">
          <p className="text-sm font-semibold text-emerald-900 mb-2">¡Cuenta creada!</p>
          <p className="text-xs text-emerald-800">Ya puedes iniciar sesión con tu nombre y la contraseña que elegiste.</p>
          <p className="text-xs text-muted-foreground mt-2">Nombre de usuario: <strong>{created}</strong></p>
        </div>
        <Button className="w-full" onClick={onDone}>Ir a iniciar sesión</Button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-3">
      <div>
        <Label>Nombre completo *</Label>
        <NameAutocomplete value={name} onChange={setName} extra={extra} />
        <p className="text-xs text-muted-foreground mt-1">Si no apareces en la lista, simplemente escríbelo y se agregará.</p>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div><Label>COP (opcional)</Label><Input value={cop} onChange={(e) => setCop(e.target.value)} /></div>
        <div><Label>Especialidad (opcional)</Label><Input value={specialty} onChange={(e) => setSpecialty(e.target.value)} /></div>
      </div>
      <div><Label>Correo electrónico *</Label><Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></div>
      <div><Label>Celular *</Label><Input value={phone} onChange={(e) => setPhone(e.target.value)} required /></div>
      <div><Label>Contraseña * <span className="text-xs text-muted-foreground">(mínimo 6 caracteres)</span></Label><Input type="password" value={pwd} onChange={(e) => setPwd(e.target.value)} required minLength={6} /></div>
      <div><Label>Confirmar contraseña *</Label><Input type="password" value={pwd2} onChange={(e) => setPwd2(e.target.value)} required minLength={6} /></div>
      <Button className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 text-white" disabled={loading}>
        {loading && <Loader2 className="h-4 w-4 animate-spin mr-2" />} <Plus className="h-4 w-4 mr-1" /> Crear mi cuenta
      </Button>
    </form>
  );
}

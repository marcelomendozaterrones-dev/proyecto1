import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import PageBackground from "@/components/PageBackground";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <PageBackground className="flex items-center justify-center">
      <div className="text-center bg-white/70 backdrop-blur rounded-3xl p-12 shadow-2xl border border-white/60">
        <h1 className="mb-4 text-6xl font-bold text-slate-800">404</h1>
        <p className="mb-4 text-xl text-muted-foreground">Página no encontrada</p>
        <a href="/" className="text-primary underline hover:text-primary/90">
          Volver al inicio
        </a>
      </div>
    </PageBackground>
  );
};

export default NotFound;

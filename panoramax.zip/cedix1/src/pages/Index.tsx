import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { FileSearch, ShieldCheck, Upload, Sparkles, Target, Eye, Heart } from "lucide-react";
import BrandLogo from "@/components/BrandLogo";
import SedeGate, { SedeBadge } from "@/components/SedeGate";
import RoleGate, { RoleBadge, getRole, type Role } from "@/components/RoleGate";
import dentalBg from "@/assets/dental-bg.png";

const Index = () => {
  const [role, setRoleState] = useState<Role | null>(getRole());
  return (
    <>
      <RoleGate onSelected={setRoleState} />
      {role === "paciente" && <SedeGate />}

      {/* Full-page background: dental clinic photo + blur + white overlay */}
      <div
        className="min-h-screen relative"
        style={{
          backgroundImage: `url(${dentalBg})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundAttachment: "fixed",
        }}
      >
        {/* Blur + white overlay — same as RoleGate */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            backdropFilter: "blur(6px)",
            WebkitBackdropFilter: "blur(6px)",
            background: "rgba(255, 255, 255, 0.82)",
          }}
        />

        {/* All content sits above the overlay */}
        <div className="relative z-10">
          <header className="container flex items-center justify-between py-6">
            <div className="flex items-center gap-3">
              <BrandLogo
                className="h-24 md:h-28 w-auto"
                style={{ mixBlendMode: "multiply" }}
              />
              <RoleBadge />
              <SedeBadge />
            </div>
          </header>

          <main className="container py-10 md:py-16">

            {/* Hero */}
            <section className="max-w-3xl mx-auto text-center space-y-6">
              <span className="inline-flex items-center gap-2 rounded-full bg-accent text-accent-foreground px-4 py-1.5 text-xs font-medium">
                <ShieldCheck className="h-3.5 w-3.5" /> Acceso seguro a tus estudios médicos
              </span>
              <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-foreground">
                Consulta tus estudios{" "}
                <span className="bg-gradient-hero bg-clip-text text-transparent">cuando lo necesites</span>
              </h1>
              <p className="text-lg text-muted-foreground">
                Panoramax 3D - Tomografía y Radiología Odontológica. Ingresa tu código de paciente y tu fecha de nacimiento para ver y descargar tus archivos médicos de forma privada.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
                <Link to="/buscar">
                  <Button size="lg" className="bg-gradient-hero shadow-elevated hover:opacity-95 transition">
                    <FileSearch className="mr-2 h-5 w-5" /> Buscar mis estudios
                  </Button>
                </Link>
              </div>
            </section>

            {/* Encuesta banner */}
            <section className="mt-16 max-w-5xl mx-auto">
              <div className="rounded-3xl bg-gradient-hero p-[2px] shadow-elevated">
                <div className="rounded-3xl bg-card/90 backdrop-blur p-8 md:p-10 grid md:grid-cols-[auto,1fr,auto] gap-6 items-center">
                  <div className="h-16 w-16 rounded-2xl bg-accent flex items-center justify-center">
                    <Sparkles className="h-8 w-8 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl md:text-2xl font-bold mb-1">¿Cómo fue tu visita?</h3>
                    <p className="text-muted-foreground">Comparte tu experiencia y ayúdanos a brindarte un mejor servicio.</p>
                  </div>
                  <Link to="/encuesta">
                    <Button className="bg-gradient-hero shadow-soft" size="lg">Responder ahora</Button>
                  </Link>
                </div>
              </div>
            </section>

            {/* Misión / Visión / Valores */}
            <section className="grid md:grid-cols-3 gap-6 mt-16 max-w-5xl mx-auto">
              {[
                { icon: Target, title: "Misión", desc: "Brindar diagnóstico imagenológico dental de alta precisión, apoyando al odontólogo y al paciente con tecnología y calidez." },
                { icon: Eye, title: "Visión", desc: "Ser el centro radiológico dental de referencia en el Perú por innovación, calidad y compromiso con la salud bucal." },
                { icon: Heart, title: "Valores", desc: "Compromiso, ética profesional, calidad humana y mejora continua en cada atención." },
              ].map((f) => (
                <div key={f.title} className="bg-white/70 backdrop-blur rounded-2xl p-6 shadow-soft border border-white/60 hover:shadow-elevated hover:-translate-y-1 transition-all">
                  <div className="h-12 w-12 rounded-xl bg-gradient-hero flex items-center justify-center mb-3 shadow-soft">
                    <f.icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="font-semibold mb-1">{f.title}</h3>
                  <p className="text-sm text-muted-foreground">{f.desc}</p>
                </div>
              ))}
            </section>

            {/* Features */}
            <section className="grid md:grid-cols-3 gap-6 mt-8 max-w-5xl mx-auto">
              {[
                { icon: ShieldCheck, title: "Privado y seguro", desc: "Tus archivos solo se muestran al verificar dos datos personales." },
                { icon: FileSearch, title: "Acceso simple", desc: "Sin registro. Solo tu código y tu fecha de nacimiento." },
                { icon: Upload, title: "Siempre disponible", desc: "Consulta tus estudios cuando quieras, desde cualquier dispositivo." },
              ].map((f) => (
                <div key={f.title} className="bg-white/70 backdrop-blur rounded-2xl p-6 shadow-soft border border-white/60 hover:shadow-elevated hover:-translate-y-1 transition-all">
                  <div className="h-12 w-12 rounded-xl bg-accent flex items-center justify-center mb-3">
                    <f.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-1">{f.title}</h3>
                  <p className="text-sm text-muted-foreground">{f.desc}</p>
                </div>
              ))}
            </section>
          </main>

          <footer className="container py-10 text-center text-xs text-muted-foreground space-y-1">
            <div className="font-semibold text-sm text-foreground">Panoramax 3D · Tomografía y Radiología Odontológica</div>
            <div>Calle Lima N°488 - 2do Piso (Al costado de la Farmacia QF Magistral), Ica, Perú</div>
            <div>
              📞 <a href="tel:+51956764523" className="hover:underline">956 764 523</a>
              {" · "}
              ✉️ <a href="mailto:rxpanoramax@gmail.com" className="hover:underline">rxpanoramax@gmail.com</a>
            </div>
            <div className="pt-1">© {new Date().getFullYear()} Panoramax 3D · Todos los derechos reservados</div>
          </footer>
        </div>
      </div>
    </>
  );
};

export default Index;

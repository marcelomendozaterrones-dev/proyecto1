import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Upload, LogOut, Trash2, FileText, Loader2, Star, BarChart3, FolderArchive, UserPlus, Building2, Hash, ChevronLeft, ChevronRight, Wrench, Stethoscope, Building, Ban, Send, CloudUpload } from "lucide-react";
import R2MigrationTab from "@/components/R2MigrationTab";
import QuickShareTab from "@/components/QuickShareTab";
import BrandLogo from "@/components/BrandLogo";
import DoctorSelect from "@/components/DoctorSelect";
import PatientRegistrationTab from "@/components/PatientRegistrationTab";
import PatientStudiesTab from "@/components/PatientStudiesTab";
import SedeAdminTab from "@/components/SedeAdminTab";
import CatalogTab from "@/components/CatalogTab";
import CountersTab from "@/components/CountersTab";
import DoctorsTab from "@/components/DoctorsTab";
import InstitutionsTab from "@/components/InstitutionsTab";
import CancelDoctorsTab from "@/components/CancelDoctorsTab";
import ChangePasswordDialog from "@/components/ChangePasswordDialog";
import PasswordsManagerDialog from "@/components/PasswordsManagerDialog";
import SuperAdminModeDialog from "@/components/SuperAdminModeDialog";
import { useEditorMode } from "@/hooks/useEditorMode";
import { useCurrentSede } from "@/hooks/useCurrentSede";
import { loadAppPasswords } from "@/hooks/useAppPasswords";
import { SEDES } from "@/data/sedes";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MapPin } from "lucide-react";
import { toast } from "sonner";

interface Study {
  id: string;
  patient_name: string;
  patient_code: string;
  birth_date: string;
  study_type: string;
  notes: string | null;
  file_name: string;
  file_path: string;
  created_at: string;
}

interface Survey {
  id: string;
  technician: string;
  technician_rating: number;
  technician_observation: string | null;
  service_rating: number;
  recommendations: string | null;
  patient_code: string | null;
  created_at: string;
}

const Admin = () => {
  const navigate = useNavigate();
  const [userId, setUserId] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const { email, isSuperAdmin, editorMode, setEditorMode } = useEditorMode();
  const { sede: currentSede, setSede: setCurrentSedeVal } = useCurrentSede();
  const [modeChosen, setModeChosen] = useState<boolean>(() => sessionStorage.getItem("cedix.modeChosen") === "1");

  useEffect(() => { loadAppPasswords(); }, []);

  const [patientName, setPatientName] = useState("");
  const [patientCode, setPatientCode] = useState("");
  const [birthDate, setBirthDate] = useState("");
  const [studyType, setStudyType] = useState("");
  const [notes, setNotes] = useState("");
  const [sede, setSedeState] = useState<string>("");
  const [doctor, setDoctor] = useState<string>("");
  const [files, setFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);

  const [studies, setStudies] = useState<Study[]>([]);
  const [surveys, setSurveys] = useState<Survey[]>([]);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      if (!session) navigate("/auth");
      else setUserId(session.user.id);
    });
    supabase.auth.getSession().then(({ data }) => {
      if (!data.session) navigate("/auth");
      else setUserId(data.session.user.id);
    });
    return () => sub.subscription.unsubscribe();
  }, [navigate]);

  useEffect(() => {
    if (!userId) return;
    (async () => {
      const { data } = await supabase.from("user_roles").select("role").eq("user_id", userId).eq("role", "admin").maybeSingle();
      setIsAdmin(!!data);
      loadStudies();
      loadSurveys();
    })();
  }, [userId, currentSede]);

  const loadStudies = async () => {
    let q = supabase.from("studies").select("*").order("created_at", { ascending: false });
    if (currentSede) q = q.eq("sede", currentSede);
    const { data } = await q;
    setStudies(data ?? []);
  };

  const loadSurveys = async () => {
    let q = supabase.from("surveys").select("*").order("created_at", { ascending: false });
    if (currentSede) q = q.eq("sede", currentSede);
    const { data } = await q;
    setSurveys((data ?? []) as Survey[]);
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (files.length === 0 || !userId) return toast.error("Selecciona al menos un archivo");
    if (!patientName || !patientCode || !birthDate || !studyType) return toast.error("Completa todos los campos");

    setUploading(true);
    try {
      for (const f of files) {
        const ext = f.name.split(".").pop();
        const path = `${patientCode.trim()}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
        // Upload directly to Cloudflare R2 (no Supabase Storage)
        const { data: signed, error: signErr } = await supabase.functions.invoke("r2-sign-upload", {
          body: { key: path, content_type: f.type || "application/octet-stream" },
        });
        if (signErr) throw signErr;
        if ((signed as any)?.error) throw new Error((signed as any).error);
        const putRes = await fetch((signed as any).url, {
          method: "PUT",
          headers: f.type ? { "Content-Type": f.type } : undefined,
          body: f,
        });
        if (!putRes.ok) throw new Error(`Error subiendo a R2 (${putRes.status})`);

        const { error: insErr } = await supabase.from("studies").insert({
          patient_name: patientName.trim(),
          patient_code: patientCode.trim(),
          birth_date: birthDate,
          study_type: studyType.trim(),
          notes: notes.trim() || null,
          sede: sede || null,
          referring_doctor: doctor.trim() || null,
          file_path: path,
          file_name: f.name,
          storage_provider: "r2",
          r2_key: path,
          created_by: userId,
        } as any);
        if (insErr) throw insErr;
      }

      toast.success(`${files.length} archivo(s) subido(s) correctamente`);
      setPatientName(""); setPatientCode(""); setBirthDate(""); setStudyType(""); setNotes(""); setSedeState(""); setDoctor(""); setFiles([]);
      (document.getElementById("file-input") as HTMLInputElement).value = "";
      loadStudies();
    } catch (err: any) {
      toast.error(err.message ?? "Error al subir");
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (s: Study) => {
    if (!editorMode && !confirm(`¿Eliminar estudio de ${s.patient_name}?`)) return;
    await supabase.storage.from("studies").remove([s.file_path]);
    const { error } = await supabase.from("studies").delete().eq("id", s.id);
    if (error) return toast.error(error.message);
    toast.success("Eliminado");
    loadStudies();
  };

  const handleDeleteSurvey = async (id: string) => {
    if (!editorMode && !confirm("¿Eliminar esta encuesta?")) return;
    const { error } = await supabase.from("surveys").delete().eq("id", id);
    if (error) return toast.error(error.message);
    loadSurveys();
  };

  const handleSignOut = async () => {
    sessionStorage.removeItem("cedix.modeChosen");
    setEditorMode(false);
    await supabase.auth.signOut();
    navigate("/");
  };

  const chooseMode = (mode: "admin" | "editor") => {
    setEditorMode(mode === "editor");
    sessionStorage.setItem("cedix.modeChosen", "1");
    setModeChosen(true);
  };


  // Stats
  const avg = (arr: number[]) => (arr.length ? (arr.reduce((a, b) => a + b, 0) / arr.length) : 0);
  const techGroups = surveys.reduce<Record<string, number[]>>((acc, s) => {
    (acc[s.technician] ||= []).push(s.technician_rating);
    return acc;
  }, {});
  const avgService = avg(surveys.map((s) => s.service_rating));

  // Tab definitions + persisted ordering
  const TAB_DEFS = [
    { id: "register", label: "Registro de paciente", icon: UserPlus },
    { id: "sedes", label: "Atenciones por sede", icon: Building2 },
    { id: "studies", label: "Estudios", icon: FileText },
    { id: "surveys", label: "Encuestas", icon: BarChart3 },
    { id: "doctors", label: "Doctores", icon: Stethoscope },
    { id: "quick-share", label: "Envíos rápidos", icon: Send },
    ...(editorMode ? [
      { id: "catalog", label: "Catálogo", icon: FolderArchive },
      { id: "counters", label: "Talones", icon: Hash },
      { id: "cancel-doctors", label: "Doctores CANCELADO", icon: Ban },
      { id: "institutions", label: "Instituciones", icon: Building },
      { id: "r2-migration", label: "Migración R2", icon: CloudUpload },
    ] : []),
  ];
  const ORDER_KEY = "cedix.tabOrder";
  const [tabOrder, setTabOrder] = useState<string[]>(() => {
    try {
      const stored = JSON.parse(localStorage.getItem(ORDER_KEY) || "[]") as string[];
      return Array.isArray(stored) && stored.length ? stored : TAB_DEFS.map((t) => t.id);
    } catch { return TAB_DEFS.map((t) => t.id); }
  });
  // Reconcile order whenever editorMode toggles tab list
  useEffect(() => {
    setTabOrder((prev) => {
      const ids = TAB_DEFS.map((t) => t.id);
      const filtered = prev.filter((id) => ids.includes(id));
      const missing = ids.filter((id) => !filtered.includes(id));
      const next = [...filtered, ...missing];
      localStorage.setItem(ORDER_KEY, JSON.stringify(next));
      return next;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editorMode]);
  const moveTab = (id: string, dir: -1 | 1) => {
    setTabOrder((prev) => {
      const idx = prev.indexOf(id);
      const j = idx + dir;
      if (idx < 0 || j < 0 || j >= prev.length) return prev;
      const next = [...prev];
      [next[idx], next[j]] = [next[j], next[idx]];
      localStorage.setItem(ORDER_KEY, JSON.stringify(next));
      return next;
    });
  };
  const orderedTabs = tabOrder.map((id) => TAB_DEFS.find((t) => t.id === id)).filter(Boolean) as typeof TAB_DEFS;

  if (isAdmin === false) {
    return (
      <div className="min-h-screen bg-gradient-soft flex items-center justify-center p-6">
        <Card className="p-6 max-w-md text-center">
          <h2 className="font-semibold text-lg mb-2">Sin permisos</h2>
          <p className="text-sm text-muted-foreground mb-4">Tu cuenta no tiene rol de administrador.</p>
          <Button onClick={handleSignOut}>Cerrar sesión</Button>
        </Card>
      </div>
    );
  }


  return (
    <div className="min-h-screen bg-gradient-soft">
      <SuperAdminModeDialog open={isSuperAdmin && !modeChosen} onChoose={chooseMode} />
      <header className="container flex items-center justify-between py-6 gap-2 flex-wrap">
        <Link to="/"><BrandLogo className="h-20 w-auto" /></Link>
        <div className="flex items-center gap-2 flex-wrap">
          {editorMode ? (
            <div className="flex items-center gap-1.5 bg-primary/10 text-primary px-2 py-1 rounded-full">
              <MapPin className="h-3.5 w-3.5" />
              <Select value={currentSede || undefined} onValueChange={(v) => setCurrentSedeVal(v as any)}>
                <SelectTrigger className="h-7 border-0 bg-transparent text-xs font-semibold px-1 focus:ring-0 gap-1">
                  <SelectValue placeholder="Sede" />
                </SelectTrigger>
                <SelectContent>
                  {SEDES.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          ) : currentSede ? (
            <span className="inline-flex items-center gap-1 text-xs bg-accent text-accent-foreground px-2.5 py-1 rounded-full font-semibold">
              <MapPin className="h-3 w-3" /> {SEDES.find((s) => s.id === currentSede)?.short ?? currentSede}
            </span>
          ) : null}
          {editorMode && (
            <span className="inline-flex items-center gap-1 text-xs bg-primary/10 text-primary px-2 py-1 rounded-full font-semibold">
              <Wrench className="h-3 w-3" /> Editor libre
            </span>
          )}
          {isSuperAdmin && (
            <Button variant="outline" size="sm" onClick={() => { sessionStorage.removeItem("cedix.modeChosen"); setModeChosen(false); }}>
              Cambiar modo
            </Button>
          )}
          {editorMode && <PasswordsManagerDialog />}
          <ChangePasswordDialog />
          <Button variant="ghost" size="sm" onClick={handleSignOut}><LogOut className="h-4 w-4 mr-1" /> Salir</Button>
        </div>
      </header>

      <main className="container py-6 max-w-6xl">
        <Tabs defaultValue={orderedTabs[0]?.id ?? "register"}>
          <TabsList className="mb-6 flex-wrap h-auto">
            {orderedTabs.map((t, i) => {
              const Icon = t.icon;
              return (
                <div key={t.id} className="flex items-center">
                  <TabsTrigger value={t.id}><Icon className="h-4 w-4 mr-1" /> {t.label}</TabsTrigger>
                  {editorMode && (
                    <div className="flex flex-col -ml-1 mr-1">
                      <button type="button" onClick={() => moveTab(t.id, -1)} disabled={i === 0} className="text-muted-foreground hover:text-primary disabled:opacity-30" title="Mover arriba/izq">
                        <ChevronLeft className="h-3 w-3" />
                      </button>
                      <button type="button" onClick={() => moveTab(t.id, 1)} disabled={i === orderedTabs.length - 1} className="text-muted-foreground hover:text-primary disabled:opacity-30" title="Mover abajo/der">
                        <ChevronRight className="h-3 w-3" />
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </TabsList>

          <TabsContent value="register">
            <PatientRegistrationTab key={currentSede || "none"} defaultSede={currentSede || ""} onSaved={() => {}} />
          </TabsContent>

          <TabsContent value="sedes">
            <SedeAdminTab />
          </TabsContent>

          <TabsContent value="studies">
            <PatientStudiesTab />
          </TabsContent>

          <TabsContent value="surveys" className="space-y-6">
            <div className="grid md:grid-cols-4 gap-4">
              <Card className="p-5 shadow-soft">
                <div className="text-xs text-muted-foreground">Total encuestas</div>
                <div className="text-3xl font-bold text-primary">{surveys.length}</div>
              </Card>
              <Card className="p-5 shadow-soft">
                <div className="text-xs text-muted-foreground">Promedio servicio</div>
                <div className="text-3xl font-bold text-primary flex items-center gap-1">
                  {avgService.toFixed(1)} <Star className="h-5 w-5 fill-primary" />
                </div>
              </Card>
              {Object.entries(techGroups).slice(0, 2).map(([t, ratings]) => (
                <Card key={t} className="p-5 shadow-soft">
                  <div className="text-xs text-muted-foreground truncate">{t}</div>
                  <div className="text-3xl font-bold text-primary flex items-center gap-1">
                    {avg(ratings).toFixed(1)} <Star className="h-5 w-5 fill-primary" />
                  </div>
                  <div className="text-xs text-muted-foreground">{ratings.length} respuesta(s)</div>
                </Card>
              ))}
            </div>

            <Card className="p-6 shadow-soft">
              <h3 className="font-bold text-lg mb-4">Por técnico</h3>
              <div className="space-y-3">
                {Object.entries(techGroups).map(([t, ratings]) => (
                  <div key={t} className="flex items-center gap-3">
                    <div className="w-48 text-sm font-medium truncate">{t}</div>
                    <div className="flex-1 bg-muted rounded-full h-3 overflow-hidden">
                      <div className="h-full bg-gradient-hero" style={{ width: `${(avg(ratings) / 5) * 100}%` }} />
                    </div>
                    <div className="text-sm font-semibold w-20 text-right">{avg(ratings).toFixed(1)} / 5</div>
                    <div className="text-xs text-muted-foreground w-12">({ratings.length})</div>
                  </div>
                ))}
                {Object.keys(techGroups).length === 0 && <p className="text-sm text-muted-foreground">Aún no hay encuestas.</p>}
              </div>
            </Card>

            <Card className="p-6 shadow-soft">
              <h3 className="font-bold text-lg mb-4">Encuestas recibidas ({surveys.length})</h3>
              <div className="space-y-3 max-h-[500px] overflow-y-auto">
                {surveys.map((s) => (
                  <div key={s.id} className="p-4 rounded-lg border border-border bg-background">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium">{s.technician}</span>
                          <span className="inline-flex items-center text-xs gap-0.5 bg-accent text-accent-foreground px-2 py-0.5 rounded-full">
                            Técnico: {s.technician_rating}<Star className="h-3 w-3 fill-current" />
                          </span>
                          <span className="inline-flex items-center text-xs gap-0.5 bg-accent text-accent-foreground px-2 py-0.5 rounded-full">
                            Servicio: {s.service_rating}<Star className="h-3 w-3 fill-current" />
                          </span>
                        </div>
                        {s.technician_observation && <p className="text-sm mt-2"><strong>Observación:</strong> {s.technician_observation}</p>}
                        {s.recommendations && <p className="text-sm mt-1"><strong>Recomendación:</strong> {s.recommendations}</p>}
                        <div className="text-xs text-muted-foreground mt-2">
                          {s.patient_code && `${s.patient_code} · `}{new Date(s.created_at).toLocaleString()}
                        </div>
                      </div>
                      <Button size="icon" variant="ghost" onClick={() => handleDeleteSurvey(s.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                ))}
                {surveys.length === 0 && <p className="text-sm text-muted-foreground">Sin encuestas todavía.</p>}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="doctors"><DoctorsTab /></TabsContent>
          <TabsContent value="quick-share"><QuickShareTab /></TabsContent>

          {editorMode && (
            <>
              <TabsContent value="catalog"><CatalogTab /></TabsContent>
              <TabsContent value="counters"><CountersTab /></TabsContent>
              <TabsContent value="cancel-doctors"><CancelDoctorsTab /></TabsContent>
              <TabsContent value="institutions"><InstitutionsTab /></TabsContent>
              <TabsContent value="r2-migration"><R2MigrationTab /></TabsContent>
            </>
          )}
        </Tabs>
      </main>
    </div>
  );
};

export default Admin;

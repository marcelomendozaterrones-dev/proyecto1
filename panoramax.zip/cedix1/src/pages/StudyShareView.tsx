import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, FileText, Download, ExternalLink, ShieldCheck, Sparkles } from "lucide-react";
import BrandLogo from "@/components/BrandLogo";
import { Link } from "react-router-dom";
import PageBackground from "@/components/PageBackground";

interface SharedStudy {
  id: string;
  file_name: string;
  study_type: string;
  created_at: string;
  url: string | null;
  download_url?: string | null;
}

interface SharePayload {
  patient_name: string;
  patient_code: string;
  doctor_name: string | null;
  expires_at: string;
  studies: SharedStudy[];
}

export default function StudyShareView() {
  const { slug } = useParams<{ slug: string }>();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<SharePayload | null>(null);

  useEffect(() => {
    (async () => {
      if (!slug) return;
      setLoading(true);
      const { data: res, error: err } = await supabase.functions.invoke("resolve-share", {
        body: { slug },
      });
      if (err) setError(err.message);
      else if ((res as any)?.error) setError((res as any).error);
      else setData(res as SharePayload);
      setLoading(false);
    })();
  }, [slug]);

  return (
    <PageBackground>
      <header className="border-b bg-background/80 backdrop-blur">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <BrandLogo className="h-12 md:h-14 w-auto" />
          <div className="text-xs text-muted-foreground flex items-center gap-1">
            <ShieldCheck className="h-4 w-4 text-primary" /> Enlace seguro Panoramax 3D
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        {loading && (
          <div className="flex items-center justify-center py-20 text-muted-foreground">
            <Loader2 className="h-6 w-6 animate-spin mr-2" /> Cargando estudios...
          </div>
        )}

        {!loading && error && (
          <Card className="p-8 text-center">
            <h1 className="text-lg font-bold mb-2">No se pudo abrir el enlace</h1>
            <p className="text-sm text-muted-foreground">{error}</p>
          </Card>
        )}

        {!loading && data && (
          <>
            <Card className="p-6 mb-6 shadow-soft">
              <h1 className="text-2xl font-bold">{data.patient_name}</h1>
              <p className="text-sm text-muted-foreground mt-1">
                Talón <span className="font-mono">{data.patient_code}</span>
                {data.doctor_name && <> · Dr(a). {data.doctor_name}</>}
              </p>
              <p className="text-xs text-muted-foreground mt-2">
                Enlace válido hasta {new Date(data.expires_at).toLocaleString()}
              </p>
            </Card>

            <h2 className="font-semibold text-lg mb-3">
              Estudios ({data.studies.length})
            </h2>
            <div className="space-y-3">
              {data.studies.map((s) => (
                <Card key={s.id} className="p-4 flex items-center gap-3">
                  <FileText className="h-6 w-6 text-primary shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate">{s.study_type}</div>
                    <div className="text-xs text-muted-foreground truncate">{s.file_name}</div>
                    <div className="text-xs text-muted-foreground">
                      {new Date(s.created_at).toLocaleString()}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {s.url && (
                      <>
                        <Button size="sm" variant="outline" asChild>
                          <a href={s.url} target="_blank" rel="noreferrer">
                            <ExternalLink className="h-4 w-4 mr-1" /> Ver
                          </a>
                        </Button>
                        <Button
                          size="sm"
                          className="bg-gradient-hero"
                          asChild
                        >
                          <a href={s.download_url || s.url!}>
                            <Download className="h-4 w-4 mr-1" /> Descargar
                          </a>
                        </Button>
                      </>
                    )}
                  </div>
                </Card>
              ))}
            </div>

            <section className="mt-8">
              <div className="rounded-3xl bg-gradient-hero p-[2px] shadow-elevated">
                <div className="rounded-3xl bg-card p-6 md:p-8 grid md:grid-cols-[auto,1fr,auto] gap-4 items-center">
                  <div className="h-14 w-14 rounded-2xl bg-accent flex items-center justify-center">
                    <Sparkles className="h-7 w-7 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg md:text-xl font-bold mb-1">¿Cómo fue tu visita?</h3>
                    <p className="text-sm text-muted-foreground">Comparte tu experiencia y ayúdanos a brindarte un mejor servicio.</p>
                  </div>
                  <Link to="/encuesta">
                    <Button className="bg-gradient-hero shadow-soft">Responder ahora</Button>
                  </Link>
                </div>
              </div>
            </section>
          </>
        )}
      </main>
    </PageBackground>
  );
}

import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, MailX, CheckCircle2, AlertTriangle } from "lucide-react";
import PageBackground from "@/components/PageBackground";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string;

type State = "loading" | "ready" | "already" | "invalid" | "done" | "error";

export default function Unsubscribe() {
  const [state, setState] = useState<State>("loading");
  const [submitting, setSubmitting] = useState(false);
  const token = new URLSearchParams(window.location.search).get("token");

  useEffect(() => {
    if (!token) { setState("invalid"); return; }
    (async () => {
      try {
        const r = await fetch(`${SUPABASE_URL}/functions/v1/handle-email-unsubscribe?token=${encodeURIComponent(token)}`, {
          headers: { apikey: SUPABASE_ANON_KEY },
        });
        const data = await r.json();
        if (data.valid) setState("ready");
        else if (data.reason === "already_unsubscribed") setState("already");
        else setState("invalid");
      } catch { setState("error"); }
    })();
  }, [token]);

  const confirm = async () => {
    if (!token) return;
    setSubmitting(true);
    const { data, error } = await supabase.functions.invoke("handle-email-unsubscribe", { body: { token } });
    setSubmitting(false);
    if (error) { setState("error"); return; }
    if ((data as any)?.reason === "already_unsubscribed") setState("already");
    else setState("done");
  };

  return (
    <PageBackground className="flex items-center justify-center p-4">
      <Card className="max-w-md w-full p-8 text-center space-y-4">
        <div className="flex justify-center">
          {state === "loading" && <Loader2 className="h-12 w-12 text-primary animate-spin" />}
          {state === "ready" && <MailX className="h-12 w-12 text-primary" />}
          {state === "done" && <CheckCircle2 className="h-12 w-12 text-emerald-600" />}
          {state === "already" && <CheckCircle2 className="h-12 w-12 text-emerald-600" />}
          {(state === "invalid" || state === "error") && <AlertTriangle className="h-12 w-12 text-destructive" />}
        </div>
        <h1 className="text-2xl font-bold">Cancelar suscripción — Panoramax 3D</h1>
        {state === "loading" && <p className="text-muted-foreground">Validando enlace…</p>}
        {state === "ready" && (
          <>
            <p className="text-muted-foreground">¿Deseas dejar de recibir correos de Panoramax 3D?</p>
            <Button onClick={confirm} disabled={submitting} className="w-full">
              {submitting && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
              Confirmar cancelación
            </Button>
          </>
        )}
        {state === "done" && <p className="text-muted-foreground">Listo. Ya no recibirás más correos.</p>}
        {state === "already" && <p className="text-muted-foreground">Este correo ya estaba dado de baja.</p>}
        {state === "invalid" && <p className="text-muted-foreground">El enlace no es válido o ha expirado.</p>}
        {state === "error" && <p className="text-muted-foreground">Ocurrió un error. Intenta más tarde.</p>}
      </Card>
    </PageBackground>
  );
}

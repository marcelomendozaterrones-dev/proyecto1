import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import BrandLogo from "@/components/BrandLogo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Loader2, KeyRound } from "lucide-react";
import { toast } from "sonner";
import { clearDoctorSession, getDoctorSession, setDoctorSession } from "./DoctorAuth";
import PageBackground from "@/components/PageBackground";

export default function DoctorChangePassword() {
  const navigate = useNavigate();
  const session = getDoctorSession();
  const [oldPwd, setOldPwd] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => { if (!session?.full_name) navigate("/doctor"); }, [session, navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPwd.length < 6) return toast.error("Mínimo 6 caracteres");
    if (newPwd !== confirm) return toast.error("Las contraseñas no coinciden");
    setLoading(true);
    const { error } = await supabase.rpc("doctor_change_password", {
      _full_name: session.full_name, _old: oldPwd, _new: newPwd,
    });
    setLoading(false);
    if (error) return toast.error(error.message);
    setDoctorSession({ ...session, must_change: false });
    toast.success("Contraseña actualizada");
    navigate("/doctor/portal");
  };

  return (
    <PageBackground>
      <header className="container py-6"><Link to="/"><BrandLogo className="h-18 md:h-20 w-auto" /></Link></header>
      <main className="flex-1 container max-w-md flex items-start">
        <Card className="w-full p-6 shadow-elevated">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-11 w-11 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
              <KeyRound className="h-5 w-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Cambia tu contraseña</h1>
              <p className="text-xs text-muted-foreground">Por seguridad, define una contraseña personal.</p>
            </div>
          </div>
          <form onSubmit={submit} className="space-y-3">
            <div><Label>Contraseña temporal</Label><Input type="password" value={oldPwd} onChange={(e) => setOldPwd(e.target.value)} required /></div>
            <div><Label>Nueva contraseña</Label><Input type="password" value={newPwd} onChange={(e) => setNewPwd(e.target.value)} required minLength={6} /></div>
            <div><Label>Confirmar nueva contraseña</Label><Input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} required /></div>
            <Button className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 text-white" disabled={loading}>
              {loading && <Loader2 className="h-4 w-4 animate-spin mr-2" />} Guardar
            </Button>
            <button type="button" onClick={() => { clearDoctorSession(); navigate("/doctor"); }} className="w-full text-xs text-muted-foreground hover:text-foreground mt-2">
              Cancelar y salir
            </button>
          </form>
        </Card>
      </main>
    </PageBackground>
  );
}

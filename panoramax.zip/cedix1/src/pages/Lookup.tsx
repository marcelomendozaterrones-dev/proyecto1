import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import JSZip from "jszip";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ArrowLeft, FileText, Download, Loader2, Eye, FolderArchive, FileImage } from "lucide-react";
import BrandLogo from "@/components/BrandLogo";
import { toast } from "sonner";
import PageBackground from "@/components/PageBackground";

interface Study {
  id: string;
  patient_name: string;
  patient_code: string;
  study_type: string;
  notes: string | null;
  file_name: string;
  created_at: string;
  url: string | null;
}

interface ZipEntry { name: string; url: string; isImage: boolean; isPdf: boolean; }

const Lookup = () => {
  const [searchParams] = useSearchParams();
  const [code, setCode] = useState(searchParams.get("code") ?? "");
  const [birthDate, setBirthDate] = useState("");
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<Study[] | null>(null);
  const [preview, setPreview] = useState<Study | null>(null);

  useEffect(() => {
    const c = searchParams.get("code");
    if (c) setCode(c);
  }, [searchParams]);
  const [zipEntries, setZipEntries] = useState<ZipEntry[] | null>(null);
  const [zipLoading, setZipLoading] = useState(false);
  const [zipSelected, setZipSelected] = useState<ZipEntry | null>(null);

  const isImage = (name: string) => /\.(jpe?g|png|gif|webp|bmp|svg)$/i.test(name);
  const isPdf = (name: string) => /\.pdf$/i.test(name);
  const isZip = (name: string) => /\.zip$/i.test(name);
  const isDicom = (name: string) => /\.(dcm|dicom)$/i.test(name);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || !birthDate) {
      toast.error("Completa código y fecha de nacimiento");
      return;
    }
    setLoading(true);
    setResults(null);
    try {
      const { data, error } = await supabase.functions.invoke("lookup-studies", {
        body: { code: code.trim(), birth_date: birthDate },
      });
      if (error) throw error;
      setResults(data?.studies ?? []);
    } catch (err: any) {
      toast.error(err.message ?? "Error al buscar estudios");
    } finally {
      setLoading(false);
    }
  };

  const openPreview = async (s: Study) => {
    setPreview(s);
    setZipEntries(null);
    setZipSelected(null);
    if (s.url && isZip(s.file_name)) {
      setZipLoading(true);
      try {
        const res = await fetch(s.url);
        const buf = await res.arrayBuffer();
        const zip = await JSZip.loadAsync(buf);
        const entries: ZipEntry[] = [];
        await Promise.all(Object.values(zip.files).map(async (f) => {
          if (f.dir) return;
          const blob = await f.async("blob");
          const url = URL.createObjectURL(blob);
          entries.push({ name: f.name, url, isImage: isImage(f.name), isPdf: isPdf(f.name) });
        }));
        entries.sort((a, b) => a.name.localeCompare(b.name));
        setZipEntries(entries);
        const firstViewable = entries.find((e) => e.isImage || e.isPdf);
        if (firstViewable) setZipSelected(firstViewable);
      } catch (err: any) {
        toast.error("No se pudo abrir el archivo ZIP");
      } finally {
        setZipLoading(false);
      }
    }
  };

  const closePreview = () => {
    if (zipEntries) zipEntries.forEach((e) => URL.revokeObjectURL(e.url));
    setPreview(null);
    setZipEntries(null);
    setZipSelected(null);
  };

  return (
    <PageBackground>
      <header className="container flex items-center justify-between py-6">
        <Link to="/"><BrandLogo className="h-20 w-auto" /></Link>
        <Link to="/"><Button variant="ghost" size="sm"><ArrowLeft className="h-4 w-4 mr-1" /> Volver</Button></Link>
      </header>

      <main className="container max-w-2xl py-8 md:py-14">
        <h1 className="text-3xl md:text-4xl font-bold mb-2">Consulta tus estudios</h1>
        <p className="text-muted-foreground mb-8">Ingresa tu código y fecha de nacimiento para ver tus archivos.</p>

        <Card className="p-6 shadow-soft">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="code">Código de paciente</Label>
              <Input id="code" value={code} onChange={(e) => setCode(e.target.value)} placeholder="Ej. PAC-00123" autoComplete="off" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bd">Fecha de nacimiento</Label>
              <Input id="bd" type="date" value={birthDate} onChange={(e) => setBirthDate(e.target.value)} />
            </div>
            <Button type="submit" disabled={loading} className="w-full bg-gradient-hero">
              {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              Buscar mis estudios
            </Button>
          </form>
        </Card>

        {results !== null && (
          <section className="mt-8 space-y-3">
            <h2 className="font-semibold text-lg">
              {results.length === 0 ? "No se encontraron estudios" : `${results.length} estudio(s) encontrado(s)`}
            </h2>
            {results.length === 0 && (
              <p className="text-sm text-muted-foreground">Verifica que tu código y fecha de nacimiento sean correctos.</p>
            )}
            {results.map((s) => (
              <Card key={s.id} className="p-5 shadow-soft">
                <div className="flex items-start gap-4">
                  <div className="h-11 w-11 rounded-xl bg-accent text-accent-foreground flex items-center justify-center shrink-0">
                    {isZip(s.file_name) ? <FolderArchive className="h-5 w-5" /> : <FileText className="h-5 w-5" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold">{s.study_type}</div>
                    <div className="text-sm text-muted-foreground">
                      {s.patient_name} · {new Date(s.created_at).toLocaleDateString()}
                    </div>
                    {s.notes && <p className="text-sm mt-2 text-foreground/80">{s.notes}</p>}
                    <div className="text-xs text-muted-foreground mt-1 truncate">{s.file_name}</div>
                  </div>
                  {s.url && (
                    <div className="flex flex-col gap-2 shrink-0">
                      <Button size="sm" variant="outline" onClick={() => openPreview(s)}>
                        <Eye className="h-4 w-4 mr-1" /> Vista previa
                      </Button>
                      <a href={s.url} target="_blank" rel="noreferrer" download={s.file_name}>
                        <Button size="sm" variant="ghost" className="w-full">
                          <Download className="h-4 w-4 mr-1" /> Descargar
                        </Button>
                      </a>
                    </div>
                  )}
                </div>
              </Card>
            ))}
          </section>
        )}
      </main>

      <Dialog open={!!preview} onOpenChange={(o) => !o && closePreview()}>
        <DialogContent className="max-w-6xl w-[95vw] h-[90vh] flex flex-col p-4">
          <DialogHeader>
            <DialogTitle className="truncate pr-8">
              {preview?.study_type} — {preview?.file_name}
            </DialogTitle>
          </DialogHeader>

          {/* ZIP viewer */}
          {preview && isZip(preview.file_name) ? (
            <div className="flex-1 min-h-0 grid grid-cols-[260px,1fr] gap-3">
              <div className="border rounded-md overflow-y-auto bg-background">
                {zipLoading && <div className="p-4 text-sm text-muted-foreground flex items-center gap-2"><Loader2 className="h-4 w-4 animate-spin" /> Abriendo ZIP...</div>}
                {zipEntries?.map((e) => (
                  <button key={e.name} onClick={() => setZipSelected(e)}
                    className={`w-full text-left px-3 py-2 text-xs border-b hover:bg-accent flex items-center gap-2 ${zipSelected?.name === e.name ? "bg-accent" : ""}`}>
                    {e.isImage ? <FileImage className="h-4 w-4 shrink-0 text-primary" /> : <FileText className="h-4 w-4 shrink-0 text-primary" />}
                    <span className="truncate">{e.name}</span>
                  </button>
                ))}
                {zipEntries?.length === 0 && <p className="p-4 text-sm text-muted-foreground">ZIP vacío</p>}
              </div>
              <div className="bg-muted rounded-md overflow-auto flex items-center justify-center">
                {zipSelected?.isImage && <img src={zipSelected.url} alt={zipSelected.name} className="max-w-full max-h-full object-contain" />}
                {zipSelected?.isPdf && <iframe src={zipSelected.url} title={zipSelected.name} className="w-full h-full border-0" />}
                {zipSelected && !zipSelected.isImage && !zipSelected.isPdf && (
                  <div className="text-sm text-muted-foreground p-6 text-center">
                    No se puede previsualizar este archivo.{" "}
                    <a href={zipSelected.url} download={zipSelected.name} className="text-primary underline">Descargar</a>
                  </div>
                )}
                {!zipSelected && !zipLoading && <p className="text-sm text-muted-foreground">Selecciona un archivo de la lista</p>}
              </div>
            </div>
          ) : (
            <div className="flex-1 min-h-0 bg-muted rounded-md overflow-auto flex items-center justify-center">
              {preview?.url && isImage(preview.file_name) && (
                <img src={preview.url} alt={preview.file_name} className="max-w-full max-h-full object-contain" />
              )}
              {preview?.url && isPdf(preview.file_name) && (
                <iframe src={preview.url} title={preview.file_name} className="w-full h-full border-0" />
              )}
              {preview?.url && isDicom(preview.file_name) && (
                <div className="text-sm text-muted-foreground p-6 text-center max-w-md">
                  <FileText className="h-12 w-12 mx-auto mb-3 text-primary" />
                  Este es un archivo DICOM (.dcm). Para visualizarlo necesitas un visor DICOM como{" "}
                  <a href="https://www.radiantviewer.com/" target="_blank" rel="noreferrer" className="text-primary underline">RadiAnt</a>{" "}
                  o{" "}
                  <a href="https://www.microdicom.com/" target="_blank" rel="noreferrer" className="text-primary underline">MicroDicom</a>.
                  <div className="mt-4">
                    <a href={preview.url} download={preview.file_name}>
                      <Button className="bg-gradient-hero"><Download className="h-4 w-4 mr-1" /> Descargar archivo DICOM</Button>
                    </a>
                  </div>
                </div>
              )}
              {preview?.url && !isImage(preview.file_name) && !isPdf(preview.file_name) && !isDicom(preview.file_name) && (
                <div className="text-sm text-muted-foreground p-6 text-center">
                  No se puede previsualizar este formato.{" "}
                  <a href={preview.url} target="_blank" rel="noreferrer" className="text-primary underline">Descargar archivo</a>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </PageBackground>
  );
};

export default Lookup;

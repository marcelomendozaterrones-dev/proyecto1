import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export const SUPER_ADMIN_EMAIL = "marlonmend.na@hotmail.com";
const SUPER_ADMIN_EMAILS = ["marlonmend.na@hotmail.com", "cedix.sistema@gmail.com"];
const FLAG_KEY = "cedix.editorMode";

export const useEditorMode = () => {
  const [email, setEmail] = useState<string | null>(null);
  const [editor, setEditor] = useState<boolean>(() => localStorage.getItem(FLAG_KEY) === "1");

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setEmail(data.user?.email ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setEmail(session?.user?.email ?? null);
    });
    const onStorage = () => setEditor(localStorage.getItem(FLAG_KEY) === "1");
    window.addEventListener("storage", onStorage);
    window.addEventListener("cedix-editor-mode", onStorage);
    return () => {
      sub.subscription.unsubscribe();
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("cedix-editor-mode", onStorage);
    };
  }, []);

  const isSuperAdmin = !!email && SUPER_ADMIN_EMAILS.includes(email.toLowerCase());
  const editorMode = isSuperAdmin && editor;

  const setEditorMode = (v: boolean) => {
    if (v) localStorage.setItem(FLAG_KEY, "1");
    else localStorage.removeItem(FLAG_KEY);
    setEditor(v);
    window.dispatchEvent(new Event("cedix-editor-mode"));
  };

  return { email, isSuperAdmin, editorMode, setEditorMode };
};

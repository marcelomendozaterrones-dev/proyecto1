import { useEffect, useState } from "react";
import type { SedeId } from "@/data/sedes";

const KEY = "cedix.sede";
const EVT = "cedix-sede-changed";

export const getCurrentSede = (): SedeId | "" => (localStorage.getItem(KEY) as SedeId) || "";
export const setCurrentSede = (id: SedeId | "") => {
  if (id) localStorage.setItem(KEY, id);
  else localStorage.removeItem(KEY);
  window.dispatchEvent(new Event(EVT));
};

export const useCurrentSede = () => {
  const [sede, setSede] = useState<SedeId | "">(() => getCurrentSede());
  useEffect(() => {
    const on = () => setSede(getCurrentSede());
    window.addEventListener(EVT, on);
    window.addEventListener("storage", on);
    return () => {
      window.removeEventListener(EVT, on);
      window.removeEventListener("storage", on);
    };
  }, []);
  return { sede, setSede: (id: SedeId | "") => { setCurrentSede(id); setSede(id); } };
};

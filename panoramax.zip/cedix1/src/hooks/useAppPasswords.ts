import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

export type AppPasswordKey =
  | "edit_ticket_number"
  | "edit_registration_date"
  | "delete_registration"
  | "manual_ticket";

export type AppPasswordRow = {
  key: string;
  label: string;
  description: string | null;
  value: string;
  updated_at: string;
};

// Fallbacks por si aún no se cargan desde la BD
const FALLBACKS: Record<string, string> = {
  edit_ticket_number: "DEBOREGISTRARBIEN",
  edit_registration_date: "DEBOREGISTRARBIEN",
  delete_registration: "CEDIX12345",
  manual_ticket: "NEWTALON",
};

const CACHE_KEY = "cedix.appPasswords";
let cache: Record<string, string> = {};
try {
  cache = JSON.parse(localStorage.getItem(CACHE_KEY) || "{}");
} catch { cache = {}; }

const listeners = new Set<() => void>();
const notify = () => listeners.forEach((fn) => fn());

export const getAppPassword = (key: AppPasswordKey): string =>
  cache[key] ?? FALLBACKS[key] ?? "";

export const loadAppPasswords = async () => {
  const { data, error } = await supabase
    .from("app_passwords")
    .select("key,value");
  if (error || !data) return;
  const next: Record<string, string> = {};
  data.forEach((r: any) => { next[r.key] = r.value; });
  cache = next;
  localStorage.setItem(CACHE_KEY, JSON.stringify(cache));
  notify();
};

export const useAppPasswords = () => {
  const [rows, setRows] = useState<AppPasswordRow[]>([]);
  const [loading, setLoading] = useState(false);

  const refresh = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("app_passwords")
      .select("*")
      .order("label");
    setLoading(false);
    if (error) return;
    setRows((data as AppPasswordRow[]) ?? []);
    const next: Record<string, string> = {};
    (data ?? []).forEach((r: any) => { next[r.key] = r.value; });
    cache = next;
    localStorage.setItem(CACHE_KEY, JSON.stringify(cache));
    notify();
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const update = useCallback(async (key: string, value: string) => {
    const { error } = await supabase
      .from("app_passwords")
      .update({ value })
      .eq("key", key);
    if (error) throw error;
    await refresh();
  }, [refresh]);

  return { rows, loading, refresh, update };
};

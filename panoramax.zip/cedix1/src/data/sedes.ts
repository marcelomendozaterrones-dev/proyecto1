export const SEDES = [
  {
    id: "ica",
    name: "Sede Ica",
    short: "Ica",
    whatsapp: "whatsapp://send?phone=51956764523",
    phone: "956 764 523",
    address: "Calle Lima N°488 - 2do Piso (Al costado de la Farmacia QF Magistral), Ica, Perú",
    email: "rxpanoramax@gmail.com",
  },
] as const;

export type SedeId = typeof SEDES[number]["id"];

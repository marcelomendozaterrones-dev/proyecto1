export interface TarifaItem {
  code: string;
  name: string;
  price: number;
  category: string;
}

export const TARIFARIO: TarifaItem[] = [
  // Radiografías intra/extra orales
  { code: "C001", name: "Panorámica", price: 80, category: "Radiografías" },
  { code: "C002", name: "Cefalométrica", price: 70, category: "Radiografías" },
  { code: "C003", name: "ATM + Panorámica", price: 140, category: "Radiografías" },
  { code: "C004", name: "Póstero anterior sin análisis", price: 70, category: "Radiografías" },
  { code: "C005", name: "Carpal sin análisis", price: 60, category: "Radiografías" },
  { code: "C006", name: "Pano + fotos extra-intraorales", price: 130, category: "Radiografías" },
  { code: "C007", name: "Localización de diente Impactado Rx", price: 90, category: "Radiografías" },
  { code: "C008", name: "Oclusal", price: 50, category: "Radiografías" },
  { code: "C009", name: "Bitewing", price: 35, category: "Radiografías" },
  { code: "C010", name: "Seriada", price: 220, category: "Radiografías" },
  { code: "C011", name: "Seriada + Panorámica", price: 250, category: "Radiografías" },
  { code: "C012", name: "Periapical", price: 25, category: "Radiografías" },
  { code: "C013", name: "Periapical RVG", price: 30, category: "Radiografías" },
  // Ortodoncia
  { code: "C014", name: "Análisis 1: Pano + Cef + 2 análisis + Fotos extra", price: 160, category: "Ortodoncia" },
  { code: "C015", name: "Análisis 2: Pano + Cef + 2 análisis + Fotos extra/intra", price: 200, category: "Ortodoncia" },
  { code: "C016", name: "Frontal con análisis", price: 100, category: "Ortodoncia" },
  { code: "C017", name: "Cefalométrica con análisis", price: 130, category: "Ortodoncia" },
  { code: "C018", name: "Carpal con análisis", price: 80, category: "Ortodoncia" },
  { code: "C019", name: "Fotos extraorales", price: 40, category: "Ortodoncia" },
  { code: "C020", name: "Fotos extraorales + intraorales", price: 60, category: "Ortodoncia" },
  // Tomografía
  { code: "C021", name: "Tomografía campo pequeño/mediano USB", price: 180, category: "Tomografía" },
  { code: "C022", name: "Tomografía campo amplio con USB", price: 250, category: "Tomografía" },
  { code: "C023", name: "Tomografía sin análisis BA/BC con USB", price: 330, category: "Tomografía" },
  { code: "C024", name: "Tomografía con análisis (1 maxilar) USB", price: 350, category: "Tomografía" },
  { code: "C025", name: "Tomografía con análisis (2 maxilares) USB", price: 390, category: "Tomografía" },
  { code: "C026", name: "Tomografía para ortodoncia c/análisis USB", price: 510, category: "Tomografía" },
  { code: "C027", name: "ATM con análisis BA/BC con USB", price: 510, category: "Tomografía" },
  // Adicionales
  { code: "A001", name: "Duplicado USB", price: 50, category: "Adicionales" },
  { code: "A002", name: "Duplicado CD", price: 30, category: "Adicionales" },
  { code: "A003", name: "Duplicado Placa", price: 40, category: "Adicionales" },
  { code: "A004", name: "Análisis adicional", price: 30, category: "Adicionales" },
  { code: "A005", name: "Duplicado estudio orto placas + documentación", price: 100, category: "Adicionales" },
  // Digital
  { code: "C028", name: "Panorámica DIGITAL", price: 60, category: "Entrega Digital" },
  { code: "C029", name: "Cefalométrica DIGITAL", price: 60, category: "Entrega Digital" },
  { code: "C030", name: "Análisis 1 DIGITAL", price: 140, category: "Entrega Digital" },
  { code: "C031", name: "Análisis 2 DIGITAL", price: 180, category: "Entrega Digital" },
  { code: "C032", name: "Tomografía DIGITAL campo amplio", price: 200, category: "Entrega Digital" },
  { code: "C033", name: "Tomografía DIGITAL campo mediano", price: 120, category: "Entrega Digital" },
  // Flujo digital
  { code: "F001", name: "Escáner intraoral", price: 180, category: "Flujo Digital" },
  { code: "F002", name: "Escáner intraoral - Delivery", price: 180, category: "Flujo Digital" },
  { code: "F003", name: "Escáner de yeso - por arcada", price: 50, category: "Flujo Digital" },
  { code: "F004", name: "Escáner + impresión 1 maxilar", price: 300, category: "Flujo Digital" },
  { code: "F005", name: "Escáner + impresión 2 maxilares", price: 420, category: "Flujo Digital" },
  { code: "F006", name: "Sólo impresión 1 maxilar", price: 200, category: "Flujo Digital" },
  { code: "F007", name: "Sólo impresión 2 maxilares", price: 350, category: "Flujo Digital" },
  { code: "F008", name: "Alineadores - Protocolo", price: 400, category: "Flujo Digital" },
  { code: "F009", name: "Alineadores - Planificación", price: 600, category: "Flujo Digital" },
  { code: "F010", name: "Alineadores - Impresión", price: 130, category: "Flujo Digital" },
  { code: "F011", name: "Alineadores - Duplicado", price: 130, category: "Flujo Digital" },
  { code: "F012", name: "Alineadores - Contención", price: 130, category: "Flujo Digital" },
  { code: "F013", name: "Análisis ortodóntico - Todos los análisis", price: 150, category: "Flujo Digital" },
  { code: "F014", name: "Guías quirúrgicas - Protocolo", price: 300, category: "Flujo Digital" },
  { code: "F015", name: "Guías quirúrgicas - Planificación", price: 500, category: "Flujo Digital" },
  { code: "F016", name: "Guías quirúrgicas - Impresión", price: 200, category: "Flujo Digital" },
];

export const PAYMENT_METHODS = ["EFECTIVO", "YAPE", "PLIN", "TRANSFERENCIA", "TARJETA"] as const;
export type PaymentMethod = typeof PAYMENT_METHODS[number];

import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";
import Lookup from "./pages/Lookup.tsx";
import Auth from "./pages/Auth.tsx";
import Admin from "./pages/Admin.tsx";
import Survey from "./pages/Survey.tsx";
import DoctorAuth from "./pages/DoctorAuth.tsx";
import DoctorChangePassword from "./pages/DoctorChangePassword.tsx";
import DoctorPortal from "./pages/DoctorPortal.tsx";
import StudyShareView from "./pages/StudyShareView.tsx";
import Unsubscribe from "./pages/Unsubscribe.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/buscar" element={<Lookup />} />
          <Route path="/auth" element={<Auth />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/encuesta" element={<Survey />} />
          <Route path="/doctor" element={<DoctorAuth />} />
          <Route path="/doctor/cambiar-clave" element={<DoctorChangePassword />} />
          <Route path="/doctor/portal" element={<DoctorPortal />} />
          <Route path="/v/:slug" element={<StudyShareView />} />
          <Route path="/unsubscribe" element={<Unsubscribe />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;

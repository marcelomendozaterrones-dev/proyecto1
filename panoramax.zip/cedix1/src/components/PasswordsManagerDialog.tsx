import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { KeyRound, Eye, EyeOff, Save } from "lucide-react";
import { useAppPasswords } from "@/hooks/useAppPasswords";
import { toast } from "sonner";

export const PasswordsManagerDialog = () => {
  const [open, setOpen] = useState(false);
  const { rows, loading, update } = useAppPasswords();
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [reveal, setReveal] = useState<Record<string, boolean>>({});
  const [saving, setSaving] = useState<string | null>(null);

  const onSave = async (key: string) => {
    const v = (drafts[key] ?? "").trim();
    if (v.length < 4) { toast.error("Mínimo 4 caracteres"); return; }
    setSaving(key);
    try {
      await update(key, v);
      toast.success("Contraseña actualizada");
      setDrafts((d) => ({ ...d, [key]: "" }));
    } catch (e: any) {
      toast.error(e?.message || "Error al actualizar");
    } finally {
      setSaving(null);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <KeyRound className="h-4 w-4 mr-1" /> Administrador de contraseñas
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Administrador de contraseñas</DialogTitle>
          <DialogDescription>
            Contraseñas usadas en la aplicación. Puedes cambiarlas en cualquier momento.
          </DialogDescription>
        </DialogHeader>

        {loading && <p className="text-sm text-muted-foreground">Cargando...</p>}

        <div className="space-y-4 pt-2">
          {rows.map((r) => {
            const shown = reveal[r.key];
            const draft = drafts[r.key] ?? "";
            return (
              <div key={r.key} className="border rounded-lg p-3 space-y-2">
                <div>
                  <p className="font-semibold text-sm">{r.label}</p>
                  {r.description && (
                    <p className="text-xs text-muted-foreground">{r.description}</p>
                  )}
                </div>
                <div>
                  <Label className="text-xs">Contraseña actual</Label>
                  <div className="flex gap-2 items-center">
                    <Input
                      readOnly
                      type={shown ? "text" : "password"}
                      value={r.value}
                      className="font-mono"
                    />
                    <Button
                      type="button"
                      size="icon"
                      variant="ghost"
                      onClick={() => setReveal((s) => ({ ...s, [r.key]: !s[r.key] }))}
                      title={shown ? "Ocultar" : "Mostrar"}
                    >
                      {shown ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
                <div>
                  <Label className="text-xs">Nueva contraseña</Label>
                  <div className="flex gap-2">
                    <Input
                      type="text"
                      placeholder="Escribe la nueva contraseña"
                      value={draft}
                      onChange={(e) => setDrafts((d) => ({ ...d, [r.key]: e.target.value }))}
                      className="font-mono"
                    />
                    <Button
                      type="button"
                      onClick={() => onSave(r.key)}
                      disabled={saving === r.key || draft.length < 4}
                    >
                      <Save className="h-4 w-4 mr-1" />
                      Guardar
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
          {!loading && rows.length === 0 && (
            <p className="text-sm text-muted-foreground">No hay contraseñas configuradas.</p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default PasswordsManagerDialog;

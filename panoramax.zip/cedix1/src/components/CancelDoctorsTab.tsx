import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Ban, Plus, Trash2, Loader2 } from "lucide-react";
import { toast } from "sonner";

interface Row { id: string; name: string; created_at: string; }

export const CancelDoctorsTab = () => {
  const [rows, setRows] = useState<Row[]>([]);
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("cancel_doctors")
      .select("*")
      .order("name", { ascending: true });
    setLoading(false);
    if (error) return toast.error(error.message);
    setRows((data ?? []) as Row[]);
  };

  useEffect(() => { load(); }, []);

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = name.trim().toUpperCase();
    if (clean.length < 3) return toast.error("Nombre muy corto");
    setSaving(true);
    const { data: { user } } = await supabase.auth.getUser();
    const { error } = await supabase
      .from("cancel_doctors")
      .insert({ name: clean, created_by: user?.id ?? null });
    setSaving(false);
    if (error) {
      if (error.code === "23505") return toast.error("Ese doctor ya está en la lista");
      return toast.error(error.message);
    }
    toast.success("Doctor agregado");
    setName("");
    load();
  };

  const remove = async (row: Row) => {
    if (!confirm(`¿Quitar a "${row.name}" del listado?`)) return;
    const { error } = await supabase.from("cancel_doctors").delete().eq("id", row.id);
    if (error) return toast.error(error.message);
    toast.success("Eliminado");
    load();
  };

  return (
    <Card className="p-6 shadow-soft space-y-5">
      <div>
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Ban className="h-5 w-5 text-primary" /> Doctores con botón CANCELADO
        </h2>
        <p className="text-sm text-muted-foreground mt-1">
          Cuando se elija a uno de estos doctores en el registro de paciente, aparecerá el
          botón <strong>Activar CANCELADO</strong>. Se compara por coincidencia del nombre.
        </p>
      </div>

      <form onSubmit={add} className="flex flex-wrap items-end gap-3">
        <div className="flex-1 min-w-[240px]">
          <Label>Nombre del doctor</Label>
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ej: SONRISA SEGURA"
            autoCapitalize="characters"
          />
        </div>
        <Button type="submit" disabled={saving} className="bg-gradient-hero">
          {saving ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Plus className="h-4 w-4 mr-1" />}
          Agregar
        </Button>
      </form>

      <div className="space-y-2">
        {loading && (
          <div className="flex justify-center py-10">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        )}
        {!loading && rows.length === 0 && (
          <p className="text-sm text-muted-foreground py-6 text-center">Aún no hay doctores en el listado.</p>
        )}
        {!loading && rows.map((r) => (
          <div key={r.id} className="flex items-center justify-between gap-3 p-3 rounded-lg border border-border bg-background">
            <div>
              <div className="font-medium">{r.name}</div>
              <div className="text-xs text-muted-foreground">Agregado el {new Date(r.created_at).toLocaleDateString()}</div>
            </div>
            <Button size="icon" variant="ghost" onClick={() => remove(r)}>
              <Trash2 className="h-4 w-4 text-destructive" />
            </Button>
          </div>
        ))}
      </div>
    </Card>
  );
};

export default CancelDoctorsTab;

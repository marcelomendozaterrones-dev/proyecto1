import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import BrandLogo from "./BrandLogo";
import { User, Stethoscope } from "lucide-react";
import dentalBg from "@/assets/dental-bg.png";
import panoramaxIcon from "@/assets/panoramax-icon.png";

export type Role = "paciente" | "doctor" | "clinica" | "institucion";
const KEY = "cedix.role";

export const getRole = (): Role | null => (localStorage.getItem(KEY) as Role) || null;
export const setRole = (r: Role) => localStorage.setItem(KEY, r);
export const clearRole = () => localStorage.removeItem(KEY);

interface CardOption {
  id: Role;
  label: string;
  desc: string;
  icon: React.ElementType;
  style: "patient" | "doctor";
}

const OPTIONS: CardOption[] = [
  {
    id: "paciente",
    label: "Soy paciente",
    desc: "Consultar mis estudios y encuesta",
    icon: User,
    style: "patient",
  },
  {
    id: "doctor",
    label: "Soy doctor",
    desc: "Acceder a estudios de mis pacientes",
    icon: Stethoscope,
    style: "doctor",
  },
];

export const RoleGate = ({ onSelected }: { onSelected: (r: Role) => void }) => {
  const navigate = useNavigate();
  const [selected, setSelected] = useState<Role | null>(getRole());
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 40);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (selected) onSelected(selected);
  }, [selected, onSelected]);

  const handle = (r: Role) => {
    if (r === "doctor") { setRole(r); navigate("/doctor"); return; }
    setRole(r); setSelected(r);
  };

  if (selected) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{
        backgroundImage: `url(${dentalBg})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      {/* Blur + dim overlay */}
      <div
        className="absolute inset-0"
        style={{ backdropFilter: "blur(8px)", background: "rgba(255,255,255,0.18)" }}
      />

      {/* Admin button — logo circular */}
      <button
        onClick={() => navigate("/auth")}
        title="Acceso administrador"
        aria-label="Acceso administrador"
        className="fixed top-4 right-4 z-20 p-0 rounded-full overflow-hidden
          shadow-lg hover:shadow-xl transition-all duration-200
          hover:scale-110 active:scale-95 border-2 border-white/80"
        style={{ width: 52, height: 52 }}
      >
        <img
          src={panoramaxIcon}
          alt="Admin"
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            objectPosition: "center",
            display: "block",
            mixBlendMode: "multiply",
          }}
        />
      </button>

      {/* Main card */}
      <div
        className={`
          relative z-10 w-full max-w-lg
          transition-all duration-700 ease-out
          ${mounted ? "opacity-100 translate-y-0 scale-100" : "opacity-0 translate-y-6 scale-95"}
        `}
      >
        {/* Glass card */}
        <div
          className="rounded-3xl border border-white/60 shadow-2xl overflow-hidden"
          style={{
            background: "rgba(255, 255, 255, 0.72)",
            backdropFilter: "blur(24px)",
            WebkitBackdropFilter: "blur(24px)",
            boxShadow: "0 25px 60px -10px rgba(0,0,0,0.22), 0 0 0 1px rgba(255,255,255,0.7) inset",
          }}
        >
          <div className="px-8 pt-8 pb-7 flex flex-col items-center">

            {/* Logo — blend-mode multiply elimina el fondo blanco de la imagen */}
            <div className="mb-5">
              <BrandLogo
                className="h-20 w-auto"
                style={{ mixBlendMode: "multiply" }}
              />
            </div>


            {/* Headline */}
            <h1 className="text-2xl md:text-3xl font-bold text-slate-800 text-center mb-1 tracking-tight">
              ¡Bienvenido a Panoramax 3D!
            </h1>
            <p className="text-slate-500 text-sm text-center mb-7">
              ¿Cómo deseas ingresar hoy?
            </p>

            {/* Role cards */}
            <div className="grid grid-cols-2 gap-4 w-full mb-6">
              {OPTIONS.map((o, i) => {
                const isDoctor = o.style === "doctor";
                const Icon = o.icon;
                return (
                  <button
                    key={o.id}
                    onClick={() => handle(o.id)}
                    style={{ animationDelay: `${i * 100 + 200}ms` }}
                    className={`
                      role-card-welcome group relative overflow-hidden
                      rounded-2xl p-5 flex flex-col items-center text-center
                      border-2 transition-all duration-300 cursor-pointer
                      hover:-translate-y-1 active:scale-[0.97]
                      ${isDoctor
                        ? "bg-gradient-to-br from-teal-500 to-teal-700 border-teal-400/60 hover:shadow-[0_8px_30px_-6px_rgba(13,148,136,0.6)] text-white"
                        : "bg-white/60 border-slate-200 hover:border-teal-300 hover:shadow-[0_8px_24px_-6px_rgba(0,0,0,0.12)] text-slate-700"
                      }
                    `}
                  >
                    {/* Icon */}
                    <div
                      className={`
                        h-14 w-14 rounded-2xl flex items-center justify-center mb-3
                        transition-transform duration-300 group-hover:scale-110
                        ${isDoctor
                          ? "bg-white/20"
                          : "bg-sky-100"
                        }
                      `}
                    >
                      <Icon
                        className={`h-7 w-7 ${isDoctor ? "text-white" : "text-sky-500"}`}
                        strokeWidth={1.8}
                      />
                    </div>
                    <div className={`font-semibold text-base mb-0.5 ${isDoctor ? "text-white" : "text-slate-800"}`}>
                      {o.label}
                    </div>
                    <div className={`text-xs leading-snug ${isDoctor ? "text-teal-100" : "text-slate-400"}`}>
                      {o.desc}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Footer */}
            <p className="text-center text-xs text-slate-400">
              Panoramax 3D - Tomografía y Radiología Odontológica
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export const RoleBadge = () => {
  const role = getRole();
  if (!role) return null;
  return (
    <button
      onClick={() => { clearRole(); localStorage.removeItem("cedix.sede"); location.reload(); }}
      className="inline-flex items-center gap-1.5 text-xs bg-white/70 backdrop-blur border border-slate-200 text-slate-600 rounded-full px-3 py-1 hover:bg-white hover:shadow transition-all"
      title="Cambiar"
    >
      {role === "paciente" ? "Paciente" : role === "doctor" ? "Doctor" : role === "clinica" ? "Clínica" : "Institución"}
    </button>
  );
};

export default RoleGate;

import { useEffect, useMemo, useState } from "react";
import { DOCTORS } from "@/data/doctors";
import { Input } from "./ui/input";
import { Check, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const DoctorSelect = ({ value, onChange }: { value: string; onChange: (v: string) => void }) => {
  const [q, setQ] = useState(value);
  const [open, setOpen] = useState(false);
  const [extra, setExtra] = useState<string[]>([]);

  useEffect(() => {
    (async () => {
      const merged = new Set<string>();
      const { data: regs } = await supabase.rpc("doctor_all_known_names");
      regs?.forEach((r: any) => r.full_name && merged.add(String(r.full_name).toUpperCase()));
      const { data: cds } = await supabase.from("custom_doctors").select("full_name");
      cds?.forEach((r: any) => r.full_name && merged.add(String(r.full_name).toUpperCase()));
      setExtra([...merged]);
    })();
  }, []);

  const all = useMemo(() => Array.from(new Set([...DOCTORS, ...extra])).sort(), [extra]);

  const results = useMemo(() => {
    const term = q.trim().toUpperCase();
    if (!term) return [];
    return all.filter((d) => d.includes(term)).slice(0, 10);
  }, [q, all]);

  return (
    <div className="relative">
      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          className="pl-8"
          value={q}
          placeholder="Buscar doctor o clínica..."
          onChange={(e) => { setQ(e.target.value.toUpperCase()); onChange(e.target.value.toUpperCase()); setOpen(true); }}
          onFocus={() => setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 150)}
        />
      </div>
      {open && results.length > 0 && (
        <div className="absolute z-20 mt-1 w-full bg-popover border border-border rounded-lg shadow-elevated max-h-64 overflow-auto">
          {results.map((d) => (
            <button
              key={d}
              type="button"
              onMouseDown={(e) => { e.preventDefault(); setQ(d); onChange(d); setOpen(false); }}
              className="w-full text-left px-3 py-2 text-sm hover:bg-accent flex items-center gap-2"
            >
              {value === d && <Check className="h-3.5 w-3.5 text-primary" />}
              <span className="truncate">{d}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default DoctorSelect;

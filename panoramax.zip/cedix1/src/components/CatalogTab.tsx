import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus, Trash2, Save, Loader2, FileText } from "lucide-react";
import { toast } from "sonner";

interface Item { id: string; code: string; name: string; price: number; category: string; sort_order: number; }

export const CatalogTab = () => {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("");
  const [open, setOpen] = useState(false);
  const [nCode, setNCode] = useState("");
  const [nName, setNName] = useState("");
  const [nPrice, setNPrice] = useState<string>("");
  const [nCategory, setNCategory] = useState("");

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase.from("tarifario_items").select("*").order("sort_order", { ascending: true });
    if (error) toast.error(error.message);
    setItems((data as Item[]) ?? []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const update = async (it: Item, patch: Partial<Item>) => {
    const newIt = { ...it, ...patch };
    setItems((prev) => prev.map((x) => (x.id === it.id ? newIt : x)));
  };

  const save = async (it: Item) => {
    const { error } = await supabase.from("tarifario_items").update({
      name: it.name, price: it.price, category: it.category, code: it.code,
    }).eq("id", it.id);
    if (error) return toast.error(error.message);
    toast.success("Guardado");
  };

  const remove = async (it: Item) => {
    const { error } = await supabase.from("tarifario_items").delete().eq("id", it.id);
    if (error) return toast.error(error.message);
    setItems((p) => p.filter((x) => x.id !== it.id));
  };

  const create = async () => {
    if (!nCode.trim() || !nName.trim()) return toast.error("Código y nombre requeridos");
    const maxSort = items.reduce((m, x) => Math.max(m, x.sort_order), 0);
    const { data, error } = await supabase.from("tarifario_items").insert({
      code: nCode.trim().toUpperCase(),
      name: nName.trim(),
      price: Number(nPrice) || 0,
      category: nCategory.trim() || "General",
      sort_order: maxSort + 1,
    }).select().single();
    if (error) return toast.error(error.message);
    setItems((p) => [...p, data as Item]);
    setNCode(""); setNName(""); setNPrice(""); setNCategory(""); setOpen(false);
    toast.success("Estudio agregado");
  };

  const filtered = items.filter((i) => {
    const q = filter.trim().toUpperCase();
    if (!q) return true;
    return i.code.includes(q) || i.name.toUpperCase().includes(q) || i.category.toUpperCase().includes(q);
  });

  const grouped = filtered.reduce<Record<string, Item[]>>((acc, it) => {
    (acc[it.category] ||= []).push(it);
    return acc;
  }, {});

  return (
    <Card className="p-6 shadow-soft space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h2 className="text-xl font-bold flex items-center gap-2"><FileText className="h-5 w-5 text-primary" /> Catálogo de estudios</h2>
        <div className="flex gap-2 items-center">
          <Input placeholder="Buscar..." value={filter} onChange={(e) => setFilter(e.target.value)} className="w-56" />
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-hero"><Plus className="h-4 w-4 mr-1" /> Agregar estudio</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Nuevo estudio</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Código</Label><Input value={nCode} onChange={(e) => setNCode(e.target.value.toUpperCase())} placeholder="Ej. C100" /></div>
                <div><Label>Nombre</Label><Input value={nName} onChange={(e) => setNName(e.target.value)} /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Precio (S/.)</Label><Input type="number" value={nPrice} onChange={(e) => setNPrice(e.target.value)} /></div>
                  <div><Label>Categoría</Label><Input value={nCategory} onChange={(e) => setNCategory(e.target.value)} placeholder="Ej. Radiografías" /></div>
                </div>
              </div>
              <DialogFooter><Button onClick={create}>Guardar</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {loading && <div className="flex justify-center py-10"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>}

      {!loading && Object.entries(grouped).map(([cat, list]) => (
        <div key={cat} className="space-y-2">
          <h3 className="font-semibold text-sm text-primary uppercase tracking-wider">{cat}</h3>
          <div className="space-y-2">
            {list.map((it) => (
              <div key={it.id} className="grid grid-cols-12 gap-2 items-center p-2 rounded-lg border border-border bg-background">
                <Input className="col-span-2" value={it.code} onChange={(e) => update(it, { code: e.target.value.toUpperCase() })} />
                <Input className="col-span-5" value={it.name} onChange={(e) => update(it, { name: e.target.value })} />
                <Input className="col-span-2" type="number" value={it.price} onChange={(e) => update(it, { price: Number(e.target.value) || 0 })} />
                <Input className="col-span-2" value={it.category} onChange={(e) => update(it, { category: e.target.value })} />
                <div className="col-span-1 flex gap-1 justify-end">
                  <Button size="icon" variant="ghost" onClick={() => save(it)}><Save className="h-4 w-4 text-primary" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => remove(it)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </Card>
  );
};

export default CatalogTab;

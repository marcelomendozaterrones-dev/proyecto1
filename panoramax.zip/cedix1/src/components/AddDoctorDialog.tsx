import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const AddDoctorDialog = ({ onAdded }: { onAdded: (name: string) => void }) => {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [specialty, setSpecialty] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [cop, setCop] = useState("");
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!name.trim()) return toast.error("Nombre requerido");
    setSaving(true);
    const fullName = name.trim().toUpperCase();
    const { data: { user } } = await supabase.auth.getUser();
    const { error } = await supabase.from("custom_doctors").insert({
      full_name: fullName,
      specialty: specialty.trim() || null,
      phone: phone.trim() || null,
      email: email.trim() || null,
      cop: cop.trim() || null,
      created_by: user?.id ?? null,
    } as any);
    // También sincronizar al directorio principal de doctores
    const { data: existing } = await supabase.from("doctors_directory").select("id").eq("full_name", fullName).maybeSingle();
    if (!existing) {
      await supabase.from("doctors_directory").insert({
        full_name: fullName,
        specialty: specialty.trim() || null,
        phone: phone.trim() || null,
        email: email.trim() || null,
      });
    }
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Doctor registrado");
    onAdded(fullName);
    setName(""); setSpecialty(""); setPhone(""); setEmail(""); setCop(""); setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button type="button" variant="outline" size="icon" title="Agregar doctor"><Plus className="h-4 w-4" /></Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Registrar nuevo doctor</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>Nombre completo</Label><Input value={name} onChange={(e) => setName(e.target.value.toUpperCase())} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Especialidad</Label><Input value={specialty} onChange={(e) => setSpecialty(e.target.value)} /></div>
            <div><Label>COP</Label><Input value={cop} onChange={(e) => setCop(e.target.value)} /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Teléfono</Label><Input value={phone} onChange={(e) => setPhone(e.target.value)} /></div>
            <div><Label>Email</Label><Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
          </div>
        </div>
        <DialogFooter>
          <Button onClick={save} disabled={saving}>Guardar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AddDoctorDialog;

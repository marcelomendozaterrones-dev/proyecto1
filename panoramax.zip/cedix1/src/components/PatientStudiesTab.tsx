import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Search, Upload, Loader2, FileText, FolderArchive, Trash2, Save, UserSearch, Pencil, Check, X, Share2, Mail, MessageCircle, Copy, Printer, FileDown } from "lucide-react";
import { generateAndDownloadInformeDocx, buildInformeDocx, fetchPanoramicBlob } from "@/lib/generateInformeDocx";

function printPatientSticker(p: { first_names: string; last_names: string; ticket_code: string; created_at?: string | null }) {
  const fullName = `${p.first_names ?? ""} ${p.last_names ?? ""}`.trim().toUpperCase();
  const hc = p.ticket_code ?? "";
  const fecha = new Date(p.created_at ?? Date.now()).toLocaleDateString("es-PE");
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>Sticker ${hc}</title>
<style>
@page { size: A4 portrait; margin: 0; }
* { box-sizing: border-box; }
body { font-family: Arial, sans-serif; margin: 0; padding: 7mm 0 0 0; }
.sticker { width: 90mm; height: 22mm; margin: 0 auto; border: 2.25pt solid #9bbb59; border-radius: 5mm; padding: 2.5mm 4mm; display: flex; flex-direction: column; justify-content: center; }
.row { display: flex; font-size: 11pt; font-weight: bold; line-height: 1.25; margin: 0.3mm 0; white-space: nowrap; }
.label { width: 22mm; flex-shrink: 0; }
.val { flex: 1; word-break: break-word; }
@media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
</style></head><body>
<div class="sticker">
  <div class="row"><span class="label">PACIENTE</span><span>: ${fullName}</span></div>
  <div class="row"><span class="label">HC</span><span>: ${hc}</span></div>
  <div class="row"><span class="label">FECHA</span><span>: ${fecha}</span></div>
</div>
<script>window.addEventListener('load', () => { setTimeout(() => { window.print(); }, 150); });<\/script>
</body></html>`;
  const w = window.open("", "_blank", "width=480,height=300");
  if (!w) return;
  w.document.open(); w.document.write(html); w.document.close();
}
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { getDisplayDoctorName } from "@/components/PatientRegistrationTab";
import DoctorSelect from "@/components/DoctorSelect";
import { SEDES } from "@/data/sedes";
import { useEditorMode } from "@/hooks/useEditorMode";
import { useCurrentSede } from "@/hooks/useCurrentSede";
import { closePendingExternalTab, getPeruWhatsAppPhone, openPendingExternalTab, renderWhatsAppShareTab } from "@/lib/whatsapp";

interface Patient {
  id: string;
  ticket_code: string;
  ticket_number: number;
  sede: string;
  doc_type: string;
  doc_number: string | null;
  first_names: string;
  last_names: string;
  phone: string | null;
  doctor_name: string | null;
  age: number | null;
  birth_date: string | null;
  items: any;
  created_at: string;
}

interface StudyRow {
  id: string;
  file_name: string;
  file_path: string;
  study_type: string;
  created_at: string;
  notes: string | null;
}

const isValidIsoDate = (value: string | null | undefined) => /^\d{4}-\d{2}-\d{2}$/.test(value ?? "");

export default function PatientStudiesTab() {
  const { editorMode } = useEditorMode();
  const { sede: currentSede } = useCurrentSede();
  const [query, setQuery] = useState("");
  const [sedeFilter, setSedeFilter] = useState<string>("");
  const [searching, setSearching] = useState(false);
  const [results, setResults] = useState<Patient[]>([]);
  const [selected, setSelected] = useState<Patient | null>(null);
  const [studies, setStudies] = useState<StudyRow[]>([]);

  const [phone, setPhone] = useState("");
  const [doctor, setDoctor] = useState("");
  const [doctorEmail, setDoctorEmail] = useState("");
  const [doctorPhone, setDoctorPhone] = useState("");
  const [savingPatient, setSavingPatient] = useState(false);
  const [sharingId, setSharingId] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [generatingShare, setGeneratingShare] = useState(false);

  const [studyType, setStudyType] = useState("");
  const [notes, setNotes] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const [converting, setConverting] = useState(false);
  const [sendingInforme, setSendingInforme] = useState(false);
  const [generatingDocx, setGeneratingDocx] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState("");

  const sendInformeRequest = async () => {
    if (!selected) return;
    if (!notes.trim()) return toast.error("Escribe el motivo de consulta en Notas");
    setSendingInforme(true);
    try {
      const patientName = `${selected.first_names} ${selected.last_names}`.trim();
      const baseKey = `informe-${selected.ticket_code}`;

      // 1) Generar Word + obtener radiografía panorámica
      const docxData = {
        patientName,
        age: selected.age ?? "",
        ticketCode: selected.ticket_code,
        doctorName: selected.doctor_name ?? "",
        motivo: notes.trim(),
        studies,
      };
      const [{ blob: docxBlob, fileName: docxName }, pano] = await Promise.all([
        buildInformeDocx(docxData),
        fetchPanoramicBlob(docxData),
      ]);

      // 2) Subir adjuntos y obtener enlaces firmados (7 días)
      const form = new FormData();
      form.append("ticket_code", selected.ticket_code);
      form.append(
        "docx",
        new File([docxBlob], docxName, {
          type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        }),
      );
      if (pano) {
        form.append("pano", new File([pano.blob], pano.fileName, { type: pano.blob.type || "image/jpeg" }));
      }
      const { data: upData, error: upErr } = await supabase.functions.invoke("upload-informe-attachment", {
        body: form,
      });
      if (upErr) throw upErr;
      if ((upData as any)?.error) throw new Error((upData as any).error);
      const docxUrl = (upData as any)?.files?.docx?.url ?? "";
      const panoUrl = (upData as any)?.files?.pano?.url ?? "";

      const templateData = {
        patientName,
        age: selected.age ?? "",
        ticketCode: selected.ticket_code,
        doctorName: selected.doctor_name ?? "",
        date: new Date().toLocaleDateString("es-PE"),
        motivo: notes.trim(),
        sedeName: SEDES.find((s) => s.id === selected.sede)?.name ?? selected.sede,
        docxUrl,
        panoUrl,
      };

      const [res1, res2] = await Promise.all([
        supabase.functions.invoke("send-transactional-email", {
          body: {
            templateName: "informe-radiografico",
            recipientEmail: "rx.informes.dent@gmail.com",
            idempotencyKey: `${baseKey}-rx-${Date.now()}`,
            templateData,
          },
        }),
        supabase.functions.invoke("send-transactional-email", {
          body: {
            templateName: "informe-radiografico",
            recipientEmail: "marlonmend.na@hotmail.com",
            idempotencyKey: `${baseKey}-mm-${Date.now()}`,
            templateData,
          },
        }),
      ]);
      if (res1.error) throw res1.error;
      if (res2.error) throw res2.error;
      toast.success(
        pano
          ? "Informe + radiografía enviados por correo"
          : "Informe enviado (no se encontró radiografía panorámica)",
      );
    } catch (err: any) {
      toast.error(err.message ?? "Error al enviar informe");
    } finally {
      setSendingInforme(false);
    }
  };


  const isHeic = (f: File) =>
    /heic|heif/i.test(f.type) || /\.(heic|heif)$/i.test(f.name);

  const convertHeicFile = async (f: File): Promise<File> => {
    try {
      const heic2any = (await import("heic2any")).default;
      const blob = (await heic2any({
        blob: f,
        toType: "image/jpeg",
        quality: 0.88,
      })) as Blob | Blob[];
      const out = Array.isArray(blob) ? blob[0] : blob;
      const newName = f.name.replace(/\.(heic|heif)$/i, ".jpg");
      return new File([out], newName, { type: "image/jpeg", lastModified: Date.now() });
    } catch (err: any) {
      console.error("HEIC conversion failed", err);
      toast.error(`No se pudo convertir ${f.name}`);
      throw err;
    }
  };

  const handleFilesSelected = async (selectedFiles: File[]) => {
    const needsConversion = selectedFiles.some(isHeic);
    if (!needsConversion) {
      setFiles(selectedFiles);
      return;
    }
    setConverting(true);
    try {
      const processed = await Promise.all(
        selectedFiles.map((f) => (isHeic(f) ? convertHeicFile(f) : Promise.resolve(f)))
      );
      setFiles(processed);
      toast.success("Imagen(es) HEIC convertida(s) a JPG");
    } catch {
      // error already toasted
    } finally {
      setConverting(false);
    }
  };

  const search = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const q = query.trim();
    if (!q) return;
    setSearching(true);
    setSelected(null);
    const digits = q.replace(/\D/g, "");
    let req = supabase.from("patient_registrations").select("*").order("created_at", { ascending: false }).limit(25);
    if (sedeFilter) req = req.eq("sede", sedeFilter);
    else if (!editorMode && currentSede) req = req.eq("sede", currentSede);
    // Build OR filter: doc_number, last_names, first_names, ticket_code, ticket_number
    const ors = [
      `doc_number.ilike.%${q}%`,
      `last_names.ilike.%${q}%`,
      `first_names.ilike.%${q}%`,
      `ticket_code.ilike.%${q}%`,
    ];
    if (digits) ors.push(`ticket_number.eq.${digits}`);
    req = req.or(ors.join(","));
    const { data, error } = await req;
    setSearching(false);
    if (error) return toast.error(error.message);
    setResults((data ?? []) as Patient[]);
    if ((data?.length ?? 0) === 0) toast.info("Sin resultados");
  };

  const loadDoctorContacts = async (name: string) => {
    const n = name.trim();
    if (!n) { setDoctorEmail(""); setDoctorPhone(""); return; }
    const { data } = await supabase
      .from("doctors_directory")
      .select("email,phone")
      .ilike("full_name", n)
      .maybeSingle();
    setDoctorEmail(data?.email ?? "");
    setDoctorPhone(data?.phone ?? "");
  };

  const selectPatient = async (p: Patient) => {
    setSelected(p);
    setPhone(p.phone ?? "");
    setDoctor(p.doctor_name ?? "");
    setSelectedIds(new Set());
    loadDoctorContacts(p.doctor_name ?? "");
    // load studies by patient_code (use ticket_code)
    const { data } = await supabase
      .from("studies")
      .select("id,file_name,file_path,study_type,created_at,notes")
      .eq("patient_code", p.ticket_code)
      .order("created_at", { ascending: false });
    setStudies((data ?? []) as StudyRow[]);
  };

  const savePatient = async () => {
    if (!selected) return;
    setSavingPatient(true);
    const docName = doctor.trim();
    const { error } = await supabase
      .from("patient_registrations")
      .update({ phone: phone.trim() || null, doctor_name: docName || null })
      .eq("id", selected.id);
    if (error) { setSavingPatient(false); return toast.error(error.message); }

    // Guardar correo/teléfono del doctor en el directorio
    if (docName) {
      const { data: existing } = await supabase
        .from("doctors_directory")
        .select("id")
        .ilike("full_name", docName)
        .maybeSingle();
      const payload = {
        full_name: docName.toUpperCase(),
        email: doctorEmail.trim() || null,
        phone: doctorPhone.trim() || null,
      };
      if (existing?.id) {
        await supabase.from("doctors_directory").update(payload).eq("id", existing.id);
      } else {
        await supabase.from("doctors_directory").insert(payload);
      }
    }

    setSavingPatient(false);
    toast.success("Datos guardados");
    setSelected({ ...selected, phone: phone.trim() || null, doctor_name: docName || null });
  };

  const uploadStudies = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selected) return;
    if (files.length === 0) return toast.error("Selecciona al menos un archivo");
    if (!studyType.trim()) return toast.error("Indica el tipo de estudio/informe");
    if (!isValidIsoDate(selected.birth_date)) return toast.error("Este paciente no tiene fecha de nacimiento registrada. Corrígela antes de subir estudios.");
    setUploading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      for (const f of files) {
        const ext = f.name.split(".").pop();
        const path = `${selected.ticket_code}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
        // Upload directly to Cloudflare R2 (no Supabase Storage)
        const { data: signed, error: signErr } = await supabase.functions.invoke("r2-sign-upload", {
          body: { key: path, content_type: f.type || "application/octet-stream" },
        });
        if (signErr) throw signErr;
        if ((signed as any)?.error) throw new Error((signed as any).error);
        const putRes = await fetch((signed as any).url, {
          method: "PUT",
          headers: f.type ? { "Content-Type": f.type } : undefined,
          body: f,
        });
        if (!putRes.ok) throw new Error(`Error subiendo a R2 (${putRes.status})`);
        const { error: insErr } = await supabase.from("studies").insert({
          patient_name: `${selected.first_names} ${selected.last_names}`.trim(),
          patient_code: selected.ticket_code,
          birth_date: selected.birth_date,
          study_type: studyType.trim(),
          notes: notes.trim() || null,
          sede: selected.sede,
          referring_doctor: selected.doctor_name,
          file_path: path,
          file_name: f.name,
          storage_provider: "r2",
          r2_key: path,
          created_by: user?.id ?? null,
        } as any);
        if (insErr) throw insErr;
      }
      toast.success(`${files.length} archivo(s) subido(s)`);
      setFiles([]); setStudyType(""); setNotes("");
      const fi = document.getElementById("patient-file-input") as HTMLInputElement | null;
      if (fi) fi.value = "";
      selectPatient(selected);
    } catch (err: any) {
      toast.error(err.message ?? "Error al subir");
    } finally {
      setUploading(false);
    }
  };

  const deleteStudy = async (s: StudyRow) => {
    const editorMode = localStorage.getItem("cedix.editorMode") === "1";
    if (!editorMode && !confirm(`¿Eliminar archivo ${s.file_name}?`)) return;
    const { error } = await supabase.functions.invoke("sign-study-url", {
      body: { study_id: s.id, action: "delete" },
    });
    if (error) return toast.error(error.message);
    if (selected) selectPatient(selected);
  };

  const openFile = async (s: StudyRow) => {
    const { data, error } = await supabase.functions.invoke("sign-study-url", {
      body: { study_id: s.id, action: "sign" },
    });
    if (error || !data?.url) return toast.error(error?.message ?? "No se pudo abrir el archivo");
    window.open(data.url, "_blank");
  };

  const startRename = (s: StudyRow) => {
    setEditingId(s.id);
    setEditingName(s.study_type);
  };

  const cancelRename = () => {
    setEditingId(null);
    setEditingName("");
  };

  const saveRename = async (s: StudyRow) => {
    const newName = editingName.trim();
    if (!newName) return toast.error("El nombre no puede estar vacío");
    const { error } = await supabase.from("studies").update({ study_type: newName }).eq("id", s.id);
    if (error) return toast.error(error.message);
    toast.success("Nombre actualizado");
    setStudies((prev) => prev.map((x) => (x.id === s.id ? { ...x, study_type: newName } : x)));
    cancelRename();
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };
  const toggleSelectAll = () => {
    if (selectedIds.size === studies.length) setSelectedIds(new Set());
    else setSelectedIds(new Set(studies.map((s) => s.id)));
  };

  const makeSlug = () => {
    // 8 caracteres legibles (sin 0/O/1/I)
    const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    const bytes = new Uint8Array(8);
    crypto.getRandomValues(bytes);
    return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("");
  };

  const buildShortShareLink = async (): Promise<string | null> => {
    if (!selected) return null;
    if (selectedIds.size === 0) { toast.error("Selecciona al menos un estudio"); return null; }
    setGeneratingShare(true);
    try {
      const slug = makeSlug();
      const expires = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
      const { error } = await supabase.from("study_shares").insert({
        slug,
        patient_code: selected.ticket_code,
        patient_name: `${selected.first_names} ${selected.last_names}`.trim(),
        doctor_name: doctor.trim() || null,
        study_ids: Array.from(selectedIds),
        expires_at: expires,
      });
      if (error) { toast.error(error.message); return null; }
      return `https://panoramax3d.app/v/${slug}`;
    } finally {
      setGeneratingShare(false);
    }
  };

  const buildSpeech = (url: string) => {
    const patientName = selected ? `${selected.first_names} ${selected.last_names}`.trim() : "";
    const selectedStudies = studies.filter((s) => selectedIds.has(s.id));
    const studyNames = Array.from(new Set(selectedStudies.map((s) => (s.study_type || s.file_name || "").toUpperCase()).filter(Boolean)));
    let studiesText = "";
    if (studyNames.length === 1) studiesText = studyNames[0];
    else if (studyNames.length === 2) studiesText = `${studyNames[0]} Y ${studyNames[1]}`;
    else if (studyNames.length > 2)
      studiesText = `${studyNames.slice(0, -1).join(", ")} Y ${studyNames[studyNames.length - 1]}`;

    const displayDoctor = getDisplayDoctorName(doctor);
    const drLine = displayDoctor ? `BUEN DÍA Dr(a). *${displayDoctor}* 😊✨\n\n` : `BUEN DÍA 😊✨\n\n`;
    return (
      drLine +
      `*LE SALUDAMOS, DE PANORAMAX 3D ☢☢ SAN JUAN DE LURIGANCHO ☢☢*\n\n` +
      `Le enviamos de manera virtual 📲 el/los estudio(s) del paciente *${patientName}* (Talón ${selected?.ticket_code}):\n\n` +
      (studiesText ? `🦷 ${studiesText}\n\n` : "") +
      `🔗 Ver/Descargar: ${url}\n` +
      `(Enlace válido por 30 días)\n\n` +
      `GRACIAS POR CONFIAR EN NOSOTROS 🤗 QUE TENGA UN EXCELENTE DÍA — PANORAMAX 3D`
    );
  };

  const shareSelectedWhatsApp = async () => {
    const pendingTab = openPendingExternalTab();
    const url = await buildShortShareLink();
    if (!url) { closePendingExternalTab(pendingTab); return; }
    const msg = buildSpeech(url);
    try {
      await navigator.clipboard.writeText(msg);
      toast.success("Mensaje copiado; se abrirá WhatsApp");
    } catch {
      window.prompt("Mensaje de WhatsApp:", msg);
    }
    renderWhatsAppShareTab(pendingTab, { phone: getPeruWhatsAppPhone(doctorPhone), message: msg });
  };

  const sendSelectedEmail = async () => {
    if (selectedIds.size === 0) { toast.error("Selecciona al menos un estudio"); return; }
    const defaultEmail = doctorEmail.trim();
    const recipient = window.prompt(
      "Correo del destinatario (paciente o doctor):",
      defaultEmail
    );
    if (!recipient) return;
    const email = recipient.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { toast.error("Correo inválido"); return; }
    const url = await buildShortShareLink();
    if (!url) return;
    const selectedStudies = studies.filter((s) => selectedIds.has(s.id));
    const studyNames = Array.from(new Set(
      selectedStudies.map((s) => (s.study_type || s.file_name || "").toUpperCase()).filter(Boolean)
    ));
    const isDoctor = email.toLowerCase() === defaultEmail.toLowerCase() && !!defaultEmail;
    const sedeName = SEDES.find((s) => s.id === selected?.sede)?.name || "PANORAMAX 3D";
    toast.loading("Enviando correo…", { id: "email-send" });
    const { error } = await supabase.functions.invoke("send-transactional-email", {
      body: {
        templateName: "study-share",
        recipientEmail: email,
        idempotencyKey: `study-share-${url.split("/").pop()}-${email}`,
        templateData: {
          recipientName: isDoctor ? getDisplayDoctorName(doctor) : `${selected?.first_names ?? ""} ${selected?.last_names ?? ""}`.trim(),
          patientName: `${selected?.first_names ?? ""} ${selected?.last_names ?? ""}`.trim(),
          ticketCode: selected?.ticket_code,
          studies: studyNames,
          shareUrl: url,
          daysValid: 30,
          sedeName,
          isDoctor,
        },
      },
    });
    toast.dismiss("email-send");
    if (error) { toast.error("No se pudo enviar: " + error.message); return; }
    toast.success(`Correo enviado a ${email}`);
  };


  const copySelectedLink = async () => {
    const url = await buildShortShareLink();
    if (!url) return;
    const msg = buildSpeech(url);
    try {
      await navigator.clipboard.writeText(msg);
      toast.success("Mensaje y enlace copiados (válido 30 días)");
    } catch {
      toast.info(msg);
    }
  };



  const sedeName = (id: string) => SEDES.find((s) => s.id === id)?.name ?? id;


  return (
    <div className="space-y-6">
      <Card className="p-6 shadow-soft">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
          <UserSearch className="h-5 w-5 text-primary" /> Buscar paciente
        </h2>
        <form onSubmit={search} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              className="pl-9"
              placeholder="DNI / Apellidos / Nº de talón"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          <Select value={sedeFilter || "all"} onValueChange={(v) => setSedeFilter(v === "all" ? "" : v)}>
            <SelectTrigger className="sm:w-56">
              <SelectValue placeholder="Sede" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas las sedes</SelectItem>
              {SEDES.map((s) => (
                <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button type="submit" disabled={searching} className="bg-gradient-hero">
            {searching ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Search className="h-4 w-4 mr-1" />}
            Buscar
          </Button>
        </form>

        {results.length > 0 && (
          <div className="mt-4 space-y-2 max-h-72 overflow-y-auto">
            {results.map((p) => (
              <div
                key={p.id}
                className={`w-full p-3 rounded-lg border transition-colors ${
                  selected?.id === p.id ? "border-primary bg-accent" : "border-border bg-background hover:bg-accent/50"
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <button onClick={() => selectPatient(p)} className="flex-1 text-left min-w-0">
                    <div className="flex items-center justify-between gap-3 flex-wrap">
                      <div className="font-medium">
                        {p.last_names}, {p.first_names}
                      </div>
                      <div className="text-xs text-muted-foreground">{sedeName(p.sede)}</div>
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      Talón: <span className="font-mono">{p.ticket_code}</span> · {p.doc_type.toUpperCase()}: {p.doc_number ?? "—"}
                      {p.phone && <> · 📞 {p.phone}</>}
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      📅 Toma: {new Date(p.created_at).toLocaleDateString()} {new Date(p.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} · 🩺 Dr(a). {getDisplayDoctorName(p.doctor_name) ?? "Particular"}
                    </div>
                  </button>
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    onClick={(e) => { e.stopPropagation(); printPatientSticker(p); }}
                    title="Imprimir sticker del paciente"
                  >
                    <Printer className="h-4 w-4 mr-1" /> Sticker
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {selected && (
        <div className="grid lg:grid-cols-2 gap-6">
          <Card className="p-6 shadow-soft">
            <div className="flex items-start justify-between gap-3 mb-1">
              <h3 className="font-bold text-lg">{selected.first_names} {selected.last_names}</h3>
              <Button size="sm" variant="outline" onClick={() => printPatientSticker(selected)}>
                <Printer className="h-4 w-4 mr-1" /> Imprimir sticker
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mb-4">
              Talón <span className="font-mono">{selected.ticket_code}</span> · {sedeName(selected.sede)} · {selected.doc_type.toUpperCase()} {selected.doc_number ?? ""}
            </p>

            <div className="space-y-3 mb-6 pb-6 border-b border-border">
              <h4 className="font-semibold text-sm">Editar datos del paciente</h4>
              <div>
                <Label>Teléfono</Label>
                <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="9XX XXX XXX" />
              </div>
              <div>
                <Label>Doctor referente</Label>
                <DoctorSelect value={doctor} onChange={(v) => { setDoctor(v); loadDoctorContacts(v); }} />
                <p className="text-xs text-muted-foreground mt-1">Deja vacío para "particular".</p>
              </div>
              <div className="grid sm:grid-cols-2 gap-3">
                <div>
                  <Label>Correo del doctor</Label>
                  <Input
                    type="email"
                    value={doctorEmail}
                    onChange={(e) => setDoctorEmail(e.target.value)}
                    placeholder="doctor@correo.com"
                    disabled={!doctor.trim()}
                  />
                </div>
                <div>
                  <Label>WhatsApp del doctor</Label>
                  <Input
                    value={doctorPhone}
                    onChange={(e) => setDoctorPhone(e.target.value)}
                    placeholder="9XX XXX XXX"
                    disabled={!doctor.trim()}
                  />
                </div>
              </div>
              <p className="text-xs text-muted-foreground">El correo y WhatsApp quedan guardados junto al doctor para reusarlos.</p>
              <Button onClick={savePatient} disabled={savingPatient} variant="outline" className="w-full">
                {savingPatient ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Save className="h-4 w-4 mr-1" />}
                Guardar cambios
              </Button>
            </div>

            <form onSubmit={uploadStudies} className="space-y-3">
              <h4 className="font-semibold text-sm flex items-center gap-2">
                <Upload className="h-4 w-4 text-primary" /> Subir estudios / informes
              </h4>
              <div>
                <Label>Tipo de estudio / informe</Label>
                <Input value={studyType} onChange={(e) => setStudyType(e.target.value)} placeholder="Tomografía, Informe, Rx..." />
              </div>
              <div>
                <Label>Notas</Label>
                <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} />
              </div>
              <div>
                <Label>Archivos (imagen, PDF, ZIP, DICOM, HEIC)</Label>
                <Input
                  id="patient-file-input"
                  type="file"
                  multiple
                  accept="image/*,application/pdf,.zip,.dcm,.heic,.heif,application/dicom,application/zip,image/heic,image/heif"
                  disabled={converting}
                  onChange={(e) => handleFilesSelected(Array.from(e.target.files ?? []))}
                />
                {converting && (
                  <p className="text-xs text-primary mt-1 flex items-center gap-1">
                    <Loader2 className="h-3 w-3 animate-spin" /> Procesando/Convertiendo imagen...
                  </p>
                )}
                {!converting && files.length > 0 && <p className="text-xs text-muted-foreground mt-1">{files.length} archivo(s) seleccionado(s)</p>}
              </div>
              <div className="flex gap-2 flex-wrap">
                <Button type="submit" disabled={uploading || converting} className="flex-1 bg-gradient-hero">
                  {uploading && <Loader2 className="h-4 w-4 animate-spin mr-2" />} Subir
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={async () => {
                    if (!selected) return;
                    if (!notes.trim()) return toast.error("Escribe el motivo de consulta en Notas");
                    setGeneratingDocx(true);
                    try {
                      const { panoCount } = await generateAndDownloadInformeDocx({
                        patientName: `${selected.first_names} ${selected.last_names}`.trim().toUpperCase(),
                        age: selected.age ?? "",
                        ticketCode: selected.ticket_code,
                        doctorName: getDisplayDoctorName(doctor || selected.doctor_name) || "",
                        motivo: notes.trim(),
                        studies: studies.map((s) => ({ id: s.id, study_type: s.study_type, file_name: s.file_name })),
                      });
                      if (panoCount > 0) toast.success(`Informe Word + ${panoCount} radiografía(s) panorámica(s) descargadas`);
                      else toast.success("Informe Word descargado (no se encontró radiografía panorámica cargada)");
                    } catch (err: any) {
                      toast.error(err?.message || "No se pudo generar el informe");
                    } finally {
                      setGeneratingDocx(false);
                    }
                  }}
                  disabled={!notes.trim() || generatingDocx}
                  title="Genera el informe en Word (editable) y descarga aparte la radiografía panorámica si está cargada"
                >
                  {generatingDocx ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <FileDown className="h-4 w-4 mr-1" />}
                  Informe Word
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={sendInformeRequest}
                  disabled={sendingInforme || !notes.trim()}
                  title="Enviar plantilla de informe por correo"
                >
                  {sendingInforme ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Mail className="h-4 w-4 mr-1" />}
                  Enviar informe
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                "Informe Word" descarga el documento editable (.docx) con los datos del paciente y el motivo. La radiografía panorámica se descarga por separado como imagen para que la puedas adjuntar.
              </p>
            </form>
          </Card>

          <Card className="p-6 shadow-soft">
            <div className="flex items-center justify-between mb-3 gap-2 flex-wrap">
              <h3 className="font-bold text-lg">Estudios del paciente ({studies.length})</h3>
              {studies.length > 0 && (
                <label className="flex items-center gap-2 text-sm cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={selectedIds.size === studies.length && studies.length > 0}
                    onChange={toggleSelectAll}
                    className="h-4 w-4 accent-primary"
                  />
                  Seleccionar todos
                </label>
              )}
            </div>

            {studies.length > 0 && (
              <div className="mb-4 p-3 rounded-lg border border-border bg-muted/30">
                <div className="text-xs text-muted-foreground mb-2">
                  {selectedIds.size === 0
                    ? "Selecciona estudios para compartir con un solo enlace corto."
                    : `${selectedIds.size} estudio(s) seleccionado(s) — se generará un enlace corto válido por 30 días.`}
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={shareSelectedWhatsApp}
                    disabled={selectedIds.size === 0 || generatingShare}
                  >
                    {generatingShare ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <MessageCircle className="h-4 w-4 mr-1 text-emerald-600" />}
                    WhatsApp
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={sendSelectedEmail}
                    disabled={selectedIds.size === 0 || generatingShare}
                  >
                    <Mail className="h-4 w-4 mr-1 text-sky-600" /> Correo
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={copySelectedLink}
                    disabled={selectedIds.size === 0 || generatingShare}
                  >
                    <Copy className="h-4 w-4 mr-1" /> Copiar enlace
                  </Button>
                </div>
              </div>
            )}

            <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
              {studies.length === 0 && <p className="text-sm text-muted-foreground">Este paciente aún no tiene estudios cargados.</p>}
              {studies.map((s) => (
                <div key={s.id} className="flex items-start gap-3 p-3 rounded-lg border border-border bg-background">
                  <input
                    type="checkbox"
                    checked={selectedIds.has(s.id)}
                    onChange={() => toggleSelect(s.id)}
                    className="mt-1 h-4 w-4 accent-primary shrink-0"
                  />
                  {/\.zip$/i.test(s.file_name) ? (
                    <FolderArchive className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                  ) : (
                    <FileText className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                  )}
                  {editingId === s.id ? (
                    <div className="flex-1 min-w-0 flex items-center gap-2">
                      <Input
                        autoFocus
                        value={editingName}
                        onChange={(e) => setEditingName(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") saveRename(s);
                          if (e.key === "Escape") cancelRename();
                        }}
                        className="h-8"
                      />
                      <Button size="icon" variant="ghost" onClick={() => saveRename(s)}>
                        <Check className="h-4 w-4 text-primary" />
                      </Button>
                      <Button size="icon" variant="ghost" onClick={cancelRename}>
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ) : (
                    <>
                      <button onClick={() => openFile(s)} className="flex-1 min-w-0 text-left">
                        <div className="font-medium truncate">{s.study_type}</div>
                        <div className="text-xs text-muted-foreground truncate">{s.file_name}</div>
                        <div className="text-xs text-muted-foreground">{new Date(s.created_at).toLocaleString()}</div>
                      </button>
                      <div className="flex items-center gap-0.5 shrink-0">
                        <Button size="icon" variant="ghost" onClick={() => startRename(s)} title="Renombrar">
                          <Pencil className="h-4 w-4 text-muted-foreground" />
                        </Button>
                        <Button size="icon" variant="ghost" onClick={() => deleteStudy(s)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>
          </Card>

        </div>
      )}
    </div>
  );
}

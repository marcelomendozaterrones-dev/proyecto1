import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Trash2, Save, Building2, Loader2, ChevronDown, ChevronRight } from "lucide-react";
import { toast } from "sonner";

interface Inst { id: string; name: string; contact: string | null; phone: string | null; notes: string | null; }
interface Tarifa { id: string; code: string; name: string; price: number; }
interface Camp { id?: string; institution_id: string; tarifario_item_id: string; special_price: number; valid_from: string | null; valid_to: string | null; active: boolean; }

export const InstitutionsTab = () => {
  const [items, setItems] = useState<Inst[]>([]);
  const [tarifas, setTarifas] = useState<Tarifa[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [n, setN] = useState({ name: "", contact: "", phone: "" });
  const [expanded, setExpanded] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    const [{ data: is }, { data: ts }] = await Promise.all([
      supabase.from("institutions").select("*").order("name"),
      supabase.from("tarifario_items").select("id,code,name,price").order("sort_order"),
    ]);
    setItems((is as Inst[]) ?? []);
    setTarifas((ts as Tarifa[]) ?? []);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const create = async () => {
    if (!n.name.trim()) return toast.error("Nombre requerido");
    const { data, error } = await supabase.from("institutions").insert({
      name: n.name.trim(), contact: n.contact.trim() || null, phone: n.phone.trim() || null,
    }).select().single();
    if (error) return toast.error(error.message);
    setItems((p) => [...p, data as Inst]);
    setN({ name: "", contact: "", phone: "" });
    setOpen(false);
    setExpanded((data as Inst).id);
  };

  const remove = async (i: Inst) => {
    const { error } = await supabase.from("institutions").delete().eq("id", i.id);
    if (error) return toast.error(error.message);
    setItems((p) => p.filter((x) => x.id !== i.id));
  };

  return (
    <Card className="p-6 shadow-soft">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <h2 className="text-xl font-bold flex items-center gap-2"><Building2 className="h-5 w-5 text-primary" /> Instituciones</h2>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button className="bg-gradient-hero"><Plus className="h-4 w-4 mr-1" /> Agregar institución</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Nueva institución</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label>Nombre</Label><Input value={n.name} onChange={(e) => setN({ ...n, name: e.target.value })} /></div>
              <div><Label>Contacto</Label><Input value={n.contact} onChange={(e) => setN({ ...n, contact: e.target.value })} /></div>
              <div><Label>Teléfono</Label><Input value={n.phone} onChange={(e) => setN({ ...n, phone: e.target.value })} /></div>
            </div>
            <DialogFooter><Button onClick={create}>Guardar</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {loading && <div className="flex justify-center py-10"><Loader2 className="h-6 w-6 animate-spin" /></div>}
      {!loading && items.length === 0 && <p className="text-sm text-muted-foreground py-6 text-center">Aún no hay instituciones. Agrega una para empezar.</p>}

      <div className="space-y-3">
        {items.map((i) => (
          <div key={i.id} className="rounded-lg border border-border">
            <div className="flex items-center gap-2 p-3">
              <button type="button" onClick={() => setExpanded(expanded === i.id ? null : i.id)} className="p-1">
                {expanded === i.id ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              </button>
              <div className="flex-1">
                <div className="font-medium">{i.name}</div>
                {(i.contact || i.phone) && <div className="text-xs text-muted-foreground">{[i.contact, i.phone].filter(Boolean).join(" · ")}</div>}
              </div>
              <Button size="icon" variant="ghost" onClick={() => remove(i)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
            </div>
            {expanded === i.id && <CampaignsEditor institution={i} tarifas={tarifas} />}
          </div>
        ))}
      </div>
    </Card>
  );
};

const CampaignsEditor = ({ institution, tarifas }: { institution: Inst; tarifas: Tarifa[] }) => {
  const [camps, setCamps] = useState<Camp[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      const { data } = await supabase.from("institution_campaigns").select("*").eq("institution_id", institution.id);
      setCamps((data as Camp[]) ?? []);
      setLoading(false);
    })();
  }, [institution.id]);

  const addRow = () => {
    if (tarifas.length === 0) return toast.error("No hay estudios en el catálogo");
    setCamps((p) => [...p, { institution_id: institution.id, tarifario_item_id: tarifas[0].id, special_price: 0, valid_from: null, valid_to: null, active: true }]);
  };

  const update = (idx: number, p: Partial<Camp>) => setCamps((prev) => prev.map((c, i) => i === idx ? { ...c, ...p } : c));

  const save = async (idx: number) => {
    const c = camps[idx];
    const payload = { institution_id: c.institution_id, tarifario_item_id: c.tarifario_item_id, special_price: Number(c.special_price) || 0, valid_from: c.valid_from || null, valid_to: c.valid_to || null, active: c.active };
    if (c.id) {
      const { error } = await supabase.from("institution_campaigns").update(payload).eq("id", c.id);
      if (error) return toast.error(error.message);
    } else {
      const { data, error } = await supabase.from("institution_campaigns").insert(payload).select().single();
      if (error) return toast.error(error.message);
      setCamps((prev) => prev.map((x, i) => i === idx ? (data as Camp) : x));
    }
    toast.success("Campaña guardada");
  };

  const remove = async (idx: number) => {
    const c = camps[idx];
    if (c.id) {
      const { error } = await supabase.from("institution_campaigns").delete().eq("id", c.id);
      if (error) return toast.error(error.message);
    }
    setCamps((p) => p.filter((_, i) => i !== idx));
  };

  return (
    <div className="border-t border-border p-3 bg-muted/20 space-y-2">
      <div className="flex items-center justify-between">
        <div className="text-sm font-semibold">Campañas con precio especial</div>
        <Button size="sm" variant="outline" onClick={addRow}><Plus className="h-3.5 w-3.5 mr-1" /> Añadir</Button>
      </div>
      {loading && <Loader2 className="h-4 w-4 animate-spin mx-auto my-3" />}
      {!loading && camps.length === 0 && <p className="text-xs text-muted-foreground">Sin campañas.</p>}
      <div className="space-y-2">
        {camps.map((c, i) => (
          <div key={i} className="grid grid-cols-12 gap-2 items-end p-2 rounded-md border border-border bg-background">
            <div className="col-span-4">
              <Label className="text-xs">Estudio</Label>
              <Select value={c.tarifario_item_id} onValueChange={(v) => update(i, { tarifario_item_id: v })}>
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>{tarifas.map((t) => <SelectItem key={t.id} value={t.id}>{t.code} · {t.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="col-span-2"><Label className="text-xs">Precio (S/)</Label><Input type="number" className="h-8" value={c.special_price} onChange={(e) => update(i, { special_price: Number(e.target.value) || 0 })} /></div>
            <div className="col-span-2"><Label className="text-xs">Desde</Label><Input type="date" className="h-8" value={c.valid_from ?? ""} onChange={(e) => update(i, { valid_from: e.target.value || null })} /></div>
            <div className="col-span-2"><Label className="text-xs">Hasta</Label><Input type="date" className="h-8" value={c.valid_to ?? ""} onChange={(e) => update(i, { valid_to: e.target.value || null })} /></div>
            <div className="col-span-1 flex items-center gap-1"><Switch checked={c.active} onCheckedChange={(v) => update(i, { active: v })} /></div>
            <div className="col-span-1 flex gap-1 justify-end">
              <Button size="icon" variant="ghost" onClick={() => save(i)}><Save className="h-4 w-4 text-primary" /></Button>
              <Button size="icon" variant="ghost" onClick={() => remove(i)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default InstitutionsTab;

import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { SEDES } from "@/data/sedes";
import { getAppPassword } from "@/hooks/useAppPasswords";
import { DOCTORS } from "@/data/doctors";
import { TARIFARIO as TARIFARIO_FALLBACK, PAYMENT_METHODS, type PaymentMethod, type TarifaItem } from "@/data/tarifario";
import AddDoctorDialog from "@/components/AddDoctorDialog";
import { useEditorMode } from "@/hooks/useEditorMode";
import { toast } from "sonner";
import { Plus, Trash2, Search, Loader2, Printer, UserPlus, Lock, Unlock, AlertTriangle, Wallet } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

interface Item { code: string; name: string; price: number; }
interface Payment { method: PaymentMethod; amount: number; }

export const TOP_DENT_DOCTORS = new Set([
  "MELISA SANCHEZ LOPEZ",
  "MIGUEL ANGEL ELIAS GARCIA GUILLEN",
  "JUNIOR HUAMAN VERGARA",
]);
export const TOP_DENT_NAME = "CLINICA TOP DENT";

export function getDisplayDoctorName(doctorName?: string | null): string | null {
  const d = (doctorName ?? "").trim().toUpperCase();
  if (TOP_DENT_DOCTORS.has(d)) return TOP_DENT_NAME;
  return doctorName || null;
}


const parseBirthDateParts = (d: string) => {
  const match = d.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) return null;
  return { year: Number(match[1]), month: Number(match[2]), day: Number(match[3]) };
};

const calcAge = (d: string) => {
  const b = parseBirthDateParts(d);
  if (!b) return 0;
  const t = new Date();
  let a = t.getFullYear() - b.year;
  const currentMonth = t.getMonth() + 1;
  if (currentMonth < b.month || (currentMonth === b.month && t.getDate() < b.day)) a--;
  return a;
};

export const PatientRegistrationTab = ({ defaultSede, onSaved }: { defaultSede: string; onSaved: () => void }) => {
  const { editorMode } = useEditorMode();
  const [TARIFARIO, setTarifario] = useState<TarifaItem[]>(TARIFARIO_FALLBACK);
  useEffect(() => {
    supabase.from("tarifario_items").select("code,name,price,category,sort_order").order("sort_order", { ascending: true }).then(({ data }) => {
      if (data && data.length) setTarifario(data.map((d: any) => ({ code: d.code, name: d.name, price: Number(d.price), category: d.category })));
    });
  }, []);
  const [sede, setSede] = useState(defaultSede || "sjl");
  const [docType, setDocType] = useState("dni");
  const [docNumber, setDocNumber] = useState("");
  const [firstNames, setFirstNames] = useState("");
  const [lastNames, setLastNames] = useState("");
  const [birthDate, setBirthDate] = useState("");
  const [phone, setPhone] = useState("");
  const [doctorQuery, setDoctorQuery] = useState("");
  const [doctorOpen, setDoctorOpen] = useState(false);
  const [customDoctors, setCustomDoctors] = useState<string[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [studyQuery, setStudyQuery] = useState("");
  const [studyOpen, setStudyOpen] = useState(false);
  const [special, setSpecial] = useState(false);
  const [specialReason, setSpecialReason] = useState("");
  const [manualTotal, setManualTotal] = useState<string>("");
  const [payments, setPayments] = useState<Payment[]>([{ method: "EFECTIVO", amount: 0 }]);
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const [lastTicket, setLastTicket] = useState<any>(null);
  const todayStr = () => {
    const d = new Date(); const off = d.getTimezoneOffset();
    return new Date(d.getTime() - off * 60000).toISOString().slice(0, 16);
  };
  const [regDate, setRegDate] = useState<string>(todayStr());
  const [dateUnlocked, setDateUnlocked] = useState(false);
  const [ticketUnlocked, setTicketUnlocked] = useState(false);
  const [manualTicket, setManualTicket] = useState<string>("");
  const [cancelled, setCancelled] = useState(false);
  const [institutions, setInstitutions] = useState<{ id: string; name: string }[]>([]);
  const [institutionId, setInstitutionId] = useState<string>("");
  const [campaigns, setCampaigns] = useState<{ institution_id: string; tarifario_item_id: string; special_price: number; valid_from: string | null; valid_to: string | null; active: boolean; tarif_code?: string; tarif_name?: string }[]>([]);
  const [tarifaIndex, setTarifaIndex] = useState<Record<string, { id: string; code: string; name: string }>>({});
  const [pendingRegs, setPendingRegs] = useState<any[]>([]);
  const [payDialogReg, setPayDialogReg] = useState<any | null>(null);
  const [payAmount, setPayAmount] = useState<string>("");
  const [payMethod, setPayMethod] = useState<PaymentMethod>("EFECTIVO");
  const [paySaving, setPaySaving] = useState(false);

  const sumPayments = (pays: any) => {
    if (!Array.isArray(pays)) return 0;
    return pays.reduce((a: number, p: any) => {
      if (p?.method === "CANCELADO") return a;
      return a + Number(p?.amount || 0);
    }, 0);
  };
  const regBalance = (r: any) => Math.max(0, Number(r.total || 0) - sumPayments(r.payments));

  const lookupByDoc = async (num: string) => {
    const n = num.trim();
    if (!n || n.length < 6) { setPendingRegs([]); return; }
    const { data } = await supabase.from("patient_registrations")
      .select("id,first_names,last_names,birth_date,phone,doctor_name,doc_type,doc_number,total,payments,items,ticket_code,sede,created_at")
      .eq("doc_number", n).order("created_at", { ascending: false }).limit(20);
    const list = (data ?? []) as any[];
    if (list.length === 0) { setPendingRegs([]); return; }
    // Autocompletar con el último registro (solo si los campos están vacíos)
    const latest = list[0];
    setFirstNames((prev) => prev || latest.first_names || "");
    setLastNames((prev) => prev || latest.last_names || "");
    setBirthDate((prev) => prev || latest.birth_date || "");
    setPhone((prev) => prev || latest.phone || "");
    if (latest.doc_type) setDocType(latest.doc_type);
    const pend = list.filter((r) => regBalance(r) > 0.01);
    setPendingRegs(pend);
    if (pend.length > 0) {
      const totalPend = pend.reduce((a, r) => a + regBalance(r), 0);
      toast.warning(`⚠ Paciente con saldo pendiente: S/ ${totalPend.toFixed(2)} en ${pend.length} ticket(s)`, { duration: 6000 });
    }
  };

  useEffect(() => {
    if (docType === "sin") { setPendingRegs([]); return; }
    const id = setTimeout(() => lookupByDoc(docNumber), 500);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [docNumber, docType]);

  const payPendingBalance = async () => {
    if (!payDialogReg) return;
    const amt = parseFloat(payAmount);
    if (!amt || amt <= 0) return toast.error("Monto inválido");
    const bal = regBalance(payDialogReg);
    if (amt - bal > 0.01) return toast.error(`Monto excede el saldo (S/ ${bal.toFixed(2)})`);
    setPaySaving(true);
    try {
      const newPayments = [...(Array.isArray(payDialogReg.payments) ? payDialogReg.payments : []), { method: payMethod, amount: amt, paid_at: new Date().toISOString() }];
      const { error } = await supabase.from("patient_registrations")
        .update({ payments: newPayments as any })
        .eq("id", payDialogReg.id);
      if (error) throw error;
      toast.success(`Pago de S/ ${amt.toFixed(2)} registrado en ticket ${payDialogReg.ticket_code}`);
      setPayDialogReg(null); setPayAmount("");
      await lookupByDoc(docNumber);
      onSaved();
    } catch (e: any) { toast.error(e.message); }
    finally { setPaySaving(false); }
  };


  useEffect(() => {
    (async () => {
      const [{ data: insts }, { data: camps }, { data: ts }] = await Promise.all([
        supabase.from("institutions").select("id,name").order("name"),
        supabase.from("institution_campaigns").select("*"),
        supabase.from("tarifario_items").select("id,code,name"),
      ]);
      setInstitutions((insts as any) ?? []);
      const idx: Record<string, { id: string; code: string; name: string }> = {};
      (ts ?? []).forEach((t: any) => { idx[t.id] = { id: t.id, code: t.code, name: t.name }; });
      setTarifaIndex(idx);
      setCampaigns(((camps ?? []) as any[]).map((c) => ({ ...c, tarif_code: idx[c.tarifario_item_id]?.code, tarif_name: idx[c.tarifario_item_id]?.name })));
    })();
  }, []);

  const isCampaignActive = (c: typeof campaigns[number]) => {
    if (!c.active) return false;
    const today = new Date().toISOString().slice(0, 10);
    if (c.valid_from && today < c.valid_from) return false;
    if (c.valid_to && today > c.valid_to) return false;
    return true;
  };

  const findCampaignFor = (item: { code: string; name: string }) => {
    if (!institutionId) return null;
    return campaigns.find((c) => c.institution_id === institutionId && isCampaignActive(c) && (c.tarif_code === item.code || c.tarif_name === item.name)) ?? null;
  };

  // Editor libre: desbloqueo automático de fecha y nº de talón
  useEffect(() => {
    if (editorMode) { setDateUnlocked(true); setTicketUnlocked(true); }
  }, [editorMode]);

  const [cancelDoctors, setCancelDoctors] = useState<string[]>(["SONRISA SEGURA", "MI ORTODONCISTA", "BRANDON MELLADO"]);
  useEffect(() => {
    supabase.from("cancel_doctors").select("name").then(({ data }) => {
      if (data && data.length) setCancelDoctors(data.map((d: any) => String(d.name).toUpperCase()));
    });
  }, []);
  const doctorAllowsCancel = cancelDoctors.some((d) => doctorQuery.toUpperCase().includes(d));
  useEffect(() => { if (!doctorAllowsCancel && cancelled) setCancelled(false); }, [doctorAllowsCancel, cancelled]);

  useEffect(() => { setSede(defaultSede || "sjl"); }, [defaultSede]);
  useEffect(() => { (async () => {
    const { data } = await supabase.from("custom_doctors").select("full_name").order("created_at", { ascending: false });
    setCustomDoctors((data ?? []).map((d: any) => d.full_name));
  })(); }, []);

  const allDoctors = useMemo(() => [...customDoctors, ...DOCTORS], [customDoctors]);
  const doctorResults = useMemo(() => {
    const q = doctorQuery.trim().toUpperCase(); if (!q) return [];
    return allDoctors.filter((d) => d.includes(q)).slice(0, 8);
  }, [doctorQuery, allDoctors]);

  const studyResults = useMemo(() => {
    const q = studyQuery.trim().toUpperCase(); if (!q) return [];
    return TARIFARIO.filter((t) => t.name.toUpperCase().includes(q) || t.code.includes(q)).slice(0, 10);
  }, [studyQuery]);

  const rawSubtotal = items.reduce((a, b) => a + Number(b.price || 0), 0);
  const subtotal = cancelled ? 0 : rawSubtotal;
  const total = cancelled ? 0 : (special && manualTotal !== "" ? Number(manualTotal) : rawSubtotal);
  const paid = payments.reduce((a, b) => a + Number(b.amount || 0), 0);
  const age = calcAge(birthDate);

  const addItem = (it: Item) => {
    const camp = findCampaignFor(it);
    const finalPrice = camp ? Number(camp.special_price) : it.price;
    setItems([...items, { ...it, price: finalPrice }]);
    setStudyQuery(""); setStudyOpen(false);
    if (camp) {
      const inst = institutions.find((x) => x.id === institutionId);
      toast.success(`Precio especial aplicado: campaña ${inst?.name}`);
    }
  };
  const updateItemPrice = (i: number, v: string) => {
    const copy = [...items]; copy[i] = { ...copy[i], price: Number(v) || 0 }; setItems(copy);
  };
  const removeItem = (i: number) => setItems(items.filter((_, idx) => idx !== i));

  const addPayment = () => setPayments([...payments, { method: "EFECTIVO", amount: 0 }]);
  const updatePayment = (i: number, p: Partial<Payment>) => {
    const c = [...payments]; c[i] = { ...c[i], ...p }; setPayments(c);
  };
  const removePayment = (i: number) => setPayments(payments.filter((_, idx) => idx !== i));

  const reset = () => {
    setDocNumber(""); setFirstNames(""); setLastNames(""); setBirthDate(""); setPhone("");
    setDoctorQuery(""); setItems([]); setSpecial(false); setSpecialReason(""); setManualTotal("");
    setPayments([{ method: "EFECTIVO", amount: 0 }]); setNotes("");
    setRegDate(todayStr()); setDateUnlocked(false);
    setTicketUnlocked(false); setManualTicket("");
    setCancelled(false); setInstitutionId("");
  };

  const submit = async () => {
    if (!firstNames || !lastNames) return toast.error("Nombres y apellidos requeridos");
    if (docType !== "sin" && !docNumber) return toast.error("Número de documento requerido");
    if (!birthDate || !parseBirthDateParts(birthDate)) return toast.error("Fecha de nacimiento requerida");
    if (items.length === 0) return toast.error("Agrega al menos un estudio");
    if (!cancelled && paid - total > 0.01) return toast.error(`Pago (S/ ${paid.toFixed(2)}) excede el total (S/ ${total.toFixed(2)})`);

    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      let num: number;
      if (ticketUnlocked && manualTicket.trim()) {
        const parsed = parseInt(manualTicket.trim().replace(/\D/g, ""), 10);
        if (!parsed || parsed <= 0) throw new Error("Número de talón manual inválido");
        num = parsed;
      } else {
        // Auto: get next, and skip any numbers already used (safety against duplicates)
        let safety = 0;
        while (true) {
          const { data: numData, error: numErr } = await supabase.rpc("next_ticket_number", { _sede: sede });
          if (numErr) throw numErr;
          num = numData as number;
          const { data: dup } = await supabase.from("patient_registrations")
            .select("id").eq("sede", sede).eq("ticket_number", num).maybeSingle();
          if (!dup) break;
          if (++safety > 50) throw new Error("No se pudo asignar un talón libre, revisa el contador");
        }
      }
      // Duplicate check (covers manual entry)
      const { data: existing } = await supabase.from("patient_registrations")
        .select("first_names,last_names,doc_number,ticket_code,created_at")
        .eq("sede", sede).eq("ticket_number", num).maybeSingle();
      if (existing) {
        const who = `${existing.first_names ?? ""} ${existing.last_names ?? ""}`.trim();
        const dni = existing.doc_number ? ` (DNI ${existing.doc_number})` : "";
        const fecha = existing.created_at ? new Date(existing.created_at).toLocaleDateString("es-PE") : "";
        toast.error(`El talón N° ${num} de la sede ${sede.toUpperCase()} ya pertenece a: ${who}${dni}${fecha ? ` — registrado el ${fecha}` : ""}. No se generó.`, { duration: 8000 });
        setSaving(false);
        return;
      }
      const code = `01 - ${String(num).padStart(2, "0")}`;
      const doctorUpper = (doctorQuery || "").trim().toUpperCase();
      let effectiveInstitutionId = institutionId || null;
      if (!effectiveInstitutionId && TOP_DENT_DOCTORS.has(doctorUpper)) {
        const topDent = institutions.find((x) => x.name.toUpperCase() === TOP_DENT_NAME);
        if (topDent) effectiveInstitutionId = topDent.id;
      }
      const { data, error } = await supabase.from("patient_registrations").insert({
        ticket_number: num, ticket_code: code, sede, doc_type: docType,
        doc_number: docNumber || null, first_names: firstNames.toUpperCase(), last_names: lastNames.toUpperCase(),
        birth_date: birthDate, age, phone: phone || null,
        doctor_name: doctorQuery || null, institution_id: effectiveInstitutionId, items: items as any, subtotal, total,
        special_price: cancelled ? false : special, special_reason: cancelled ? "CANCELADO" : (specialReason || null),
        payments: (cancelled ? [{ method: "CANCELADO", amount: total }] : payments) as any, notes: notes || null, created_by: user?.id ?? null,
        ...(dateUnlocked && regDate ? { created_at: new Date(regDate).toISOString() } : {}),
      }).select().single();
      if (error) throw error;
      const instName = effectiveInstitutionId ? (institutions.find((x) => x.id === effectiveInstitutionId)?.name ?? null) : null;
      setLastTicket({ ...data, institution_name: instName });
      toast.success(`Ticket ${code} generado`);
      reset();
      onSaved();
    } catch (e: any) { toast.error(e.message); }
    finally { setSaving(false); }
  };

  const printTicket = () => {
    const ticket = document.getElementById("ticket-print");
    if (!ticket) return window.print();

    document.getElementById("ticket-print-frame")?.remove();

    const frame = document.createElement("iframe");
    frame.id = "ticket-print-frame";
    frame.setAttribute("aria-hidden", "true");
    frame.style.position = "fixed";
    frame.style.right = "0";
    frame.style.bottom = "0";
    frame.style.width = "0";
    frame.style.height = "0";
    frame.style.border = "0";
    frame.style.opacity = "0";
    document.body.appendChild(frame);

    const printWindow = frame.contentWindow;
    const printDocument = printWindow?.document;
    if (!printWindow || !printDocument) return window.print();

    const inheritedStyles = Array.from(document.head.querySelectorAll('style, link[rel="stylesheet"]'))
      .map((node) => node.outerHTML)
      .join("\n");

    printDocument.open();
    printDocument.write(`<!doctype html>
      <html>
        <head>
          <meta charset="utf-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          ${inheritedStyles}
          <style>
            @page { size: 80mm auto; margin: 0; }
            html, body {
              width: 80mm !important;
              min-width: 80mm !important;
              height: auto !important;
              min-height: 0 !important;
              margin: 0 !important;
              padding: 0 !important;
              background: #fff !important;
              overflow: visible !important;
            }
            body.printing-ticket {
              position: relative !important;
              display: block !important;
            }
            body.printing-ticket #ticket-print-root {
              position: absolute !important;
              top: 0 !important;
              left: 0 !important;
              width: 80mm !important;
              margin: 0 !important;
              padding: 0 !important;
              background: #fff !important;
              overflow: visible !important;
            }
            body.printing-ticket #ticket-print-copy {
              position: absolute !important;
              top: 0 !important;
              left: 0 !important;
              width: 76mm !important;
              max-width: 76mm !important;
              margin: 0 !important;
              padding: 2mm !important;
              border: 0 !important;
              box-shadow: none !important;
              border-radius: 0 !important;
              break-inside: avoid !important;
              page-break-inside: avoid !important;
            }
          </style>
        </head>
        <body class="printing-ticket"><div id="ticket-print-root"></div></body>
      </html>`);
    printDocument.close();

    const ticketCopy = ticket.cloneNode(true) as HTMLElement;
    ticketCopy.id = "ticket-print-copy";
    printDocument.getElementById("ticket-print-root")?.appendChild(ticketCopy);

    const cleanup = () => {
      frame.remove();
      printWindow.removeEventListener("afterprint", cleanup);
    };

    const launchPrint = () => {
      printWindow.focus();
      printWindow.print();
      window.setTimeout(cleanup, 1000);
    };

    printWindow.addEventListener("afterprint", cleanup, { once: true });
    if (printDocument.fonts?.ready) {
      printDocument.fonts.ready.then(() => printWindow.requestAnimationFrame(launchPrint));
    } else {
      printWindow.requestAnimationFrame(launchPrint);
    }
  };

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      <Card className="p-6 shadow-soft lg:col-span-2 space-y-4">
        <h2 className="text-xl font-bold flex items-center gap-2"><UserPlus className="h-5 w-5 text-primary" /> Registro de paciente</h2>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          <div>
            <Label>Sede</Label>
            <Select value={sede} onValueChange={setSede} disabled={!editorMode}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{SEDES.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <Label>Tipo de documento</Label>
            <Select value={docType} onValueChange={setDocType}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="dni">DNI</SelectItem>
                <SelectItem value="ce">Carnet de Extranjería</SelectItem>
                <SelectItem value="sin">Sin documento</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>N° Documento</Label>
            <Input value={docNumber} onChange={(e) => setDocNumber(e.target.value)} disabled={docType === "sin"} />
          </div>
        </div>

        {pendingRegs.length > 0 && (
          <div className="rounded-lg border-2 border-amber-500 bg-amber-50 dark:bg-amber-950/30 p-3 space-y-2">
            <div className="flex items-center gap-2 text-amber-700 dark:text-amber-400 font-bold">
              <AlertTriangle className="h-5 w-5" />
              Saldo pendiente — este paciente tiene {pendingRegs.length} ticket(s) sin cancelar
            </div>
            <div className="space-y-1">
              {pendingRegs.map((r) => (
                <div key={r.id} className="flex items-center justify-between gap-2 bg-background rounded p-2 text-sm">
                  <div className="flex-1 min-w-0">
                    <div className="font-mono text-xs">{r.ticket_code}</div>
                    <div className="text-xs text-muted-foreground truncate">
                      {new Date(r.created_at).toLocaleDateString("es-PE")} · Total S/ {Number(r.total).toFixed(2)} · Pagado S/ {sumPayments(r.payments).toFixed(2)}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-amber-600">S/ {regBalance(r).toFixed(2)}</div>
                  </div>
                  <Button size="sm" type="button" onClick={() => { setPayDialogReg(r); setPayAmount(regBalance(r).toFixed(2)); setPayMethod("EFECTIVO"); }}>
                    <Wallet className="h-4 w-4 mr-1" /> Pagar saldo
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}


        <div className="grid grid-cols-2 gap-3">
          <div><Label>Nombres</Label><Input value={firstNames} onChange={(e) => setFirstNames(e.target.value)} /></div>
          <div><Label>Apellidos</Label><Input value={lastNames} onChange={(e) => setLastNames(e.target.value)} /></div>
          <div><Label>Fecha de nacimiento</Label><Input type="date" value={birthDate} onChange={(e) => setBirthDate(e.target.value)} /></div>
          <div><Label>Edad</Label><Input value={birthDate ? `${age} años` : ""} readOnly className="bg-muted" /></div>
          <div className="col-span-2"><Label>Teléfono</Label><Input value={phone} onChange={(e) => setPhone(e.target.value)} /></div>
        </div>

        {/* Fecha de registro (bloqueada por defecto) */}
        <div className="rounded-lg border border-dashed border-primary/40 p-3">
          <div className="flex items-center justify-between gap-3">
            <div className="flex-1">
              <Label className="flex items-center gap-2">
                {dateUnlocked ? <Unlock className="h-3.5 w-3.5 text-primary" /> : <Lock className="h-3.5 w-3.5 text-muted-foreground" />}
                Fecha y hora de registro
              </Label>
              <Input
                type="datetime-local"
                value={regDate}
                onChange={(e) => setRegDate(e.target.value)}
                disabled={!dateUnlocked}
                className={!dateUnlocked ? "bg-muted cursor-not-allowed" : ""}
              />
        </div>

        {/* N° de talón manual (bloqueado por defecto) */}
        <div className="rounded-lg border border-dashed border-primary/40 p-3">
          <div className="flex items-center justify-between gap-3">
            <div className="flex-1">
              <Label className="flex items-center gap-2">
                {ticketUnlocked ? <Unlock className="h-3.5 w-3.5 text-primary" /> : <Lock className="h-3.5 w-3.5 text-muted-foreground" />}
                N° de talón (manual)
              </Label>
              <Input
                type="number"
                inputMode="numeric"
                placeholder={ticketUnlocked ? "Ej. 123" : "Se generará automáticamente"}
                value={manualTicket}
                onChange={(e) => setManualTicket(e.target.value)}
                onWheel={(e) => (e.currentTarget as HTMLInputElement).blur()}
                disabled={!ticketUnlocked}
                className={!ticketUnlocked ? "bg-muted cursor-not-allowed" : ""}
              />
            </div>
            <Button
              type="button"
              size="sm"
              variant={ticketUnlocked ? "default" : "outline"}
              onClick={() => {
                if (ticketUnlocked) { setTicketUnlocked(false); setManualTicket(""); return; }
                if (editorMode) { setTicketUnlocked(true); return; }
                const pwd = window.prompt("Ingresa la contraseña para habilitar el talón manual:");
                if (pwd === null) return;
                if (pwd === getAppPassword("manual_ticket")) { setTicketUnlocked(true); toast.success("Talón manual habilitado"); }
                else toast.error("Contraseña incorrecta");
              }}
              className="mt-5"
            >
              {ticketUnlocked ? <><Lock className="h-4 w-4 mr-1" /> Bloquear</> : <><Unlock className="h-4 w-4 mr-1" /> Habilitar</>}
            </Button>
          </div>
          {!ticketUnlocked && <p className="text-xs text-muted-foreground mt-1">Por defecto el N° de talón se genera automáticamente. Requiere contraseña para ingresarlo manualmente.</p>}
          {ticketUnlocked && manualTicket && <p className="text-xs text-primary mt-1">Se registrará como: <strong>01 - {String(parseInt(manualTicket.replace(/\D/g, ""), 10) || 0).padStart(2, "0")}</strong></p>}
        </div>
            <Button
              type="button"
              size="sm"
              variant={dateUnlocked ? "default" : "outline"}
              onClick={() => {
                if (dateUnlocked) { setDateUnlocked(false); setRegDate(todayStr()); }
                else { setDateUnlocked(true); }
              }}
              className="mt-5"
            >
              {dateUnlocked ? <><Lock className="h-4 w-4 mr-1" /> Bloquear</> : <><Unlock className="h-4 w-4 mr-1" /> Modificar</>}
            </Button>
          </div>
          {!dateUnlocked && <p className="text-xs text-muted-foreground mt-1">Por defecto se usa la fecha y hora actual. Haz clic en "Modificar" para cambiarla.</p>}
        </div>

        {/* Institución (opcional) */}
        <div>
          <Label>Institución / Campaña (opcional)</Label>
          <Select value={institutionId || "none"} onValueChange={(v) => setInstitutionId(v === "none" ? "" : v)}>
            <SelectTrigger><SelectValue placeholder="Ninguna" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="none">— Ninguna —</SelectItem>
              {institutions.map((i) => <SelectItem key={i.id} value={i.id}>{i.name}</SelectItem>)}
            </SelectContent>
          </Select>
          {institutionId && (
            <p className="text-xs text-primary mt-1">
              Al añadir un estudio con campaña activa, se aplicará el precio especial automáticamente.
            </p>
          )}
        </div>

        {/* Doctor */}
        <div>
          <Label>Doctor solicitante</Label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input className="pl-8" value={doctorQuery} placeholder="Buscar doctor..."
                onChange={(e) => { setDoctorQuery(e.target.value.toUpperCase()); setDoctorOpen(true); }}
                onFocus={() => setDoctorOpen(true)} onBlur={() => setTimeout(() => setDoctorOpen(false), 150)} />
              {doctorOpen && doctorResults.length > 0 && (
                <div className="absolute z-20 mt-1 w-full bg-popover border border-border rounded-lg shadow-elevated max-h-64 overflow-auto">
                  {doctorResults.map((d) => (
                    <button key={d} type="button" onMouseDown={(e) => { e.preventDefault(); setDoctorQuery(d); setDoctorOpen(false); }}
                      className="w-full text-left px-3 py-2 text-sm hover:bg-accent">{d}</button>
                  ))}
                </div>
              )}
            </div>
            <AddDoctorDialog onAdded={(n) => { setCustomDoctors([n, ...customDoctors]); setDoctorQuery(n); }} />
          </div>
          {doctorAllowsCancel && (
            <div className="mt-2">
              <Button
                type="button"
                size="sm"
                variant={cancelled ? "default" : "outline"}
                onClick={() => setCancelled(!cancelled)}
                className={cancelled ? "bg-primary text-primary-foreground" : ""}
              >
                {cancelled ? "✓ CANCELADO activado" : "Activar CANCELADO"}
              </Button>
              {cancelled && <p className="text-xs text-primary mt-1">Precio especial y métodos de pago bloqueados. El ticket mostrará "CANCELADO".</p>}
            </div>
          )}
        </div>

        {/* Estudios */}
        <div>
          <Label>Estudio solicitado</Label>
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input className="pl-8" value={studyQuery} placeholder="Buscar estudio (ej. panorámica)..."
              onChange={(e) => { setStudyQuery(e.target.value.toUpperCase()); setStudyOpen(true); }}
              onFocus={() => setStudyOpen(true)} onBlur={() => setTimeout(() => setStudyOpen(false), 150)} />
            {studyOpen && studyResults.length > 0 && (
              <div className="absolute z-20 mt-1 w-full bg-popover border border-border rounded-lg shadow-elevated max-h-72 overflow-auto">
                {studyResults.map((t) => (
                  <button key={t.code} type="button" onMouseDown={(e) => { e.preventDefault(); addItem({ code: t.code, name: t.name, price: t.price }); }}
                    className="w-full text-left px-3 py-2 text-sm hover:bg-accent flex justify-between gap-2">
                    <span className="truncate">{t.code} · {t.name}</span>
                    <span className="font-semibold text-primary">S/ {t.price.toFixed(2)}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {items.length > 0 && (
            <div className="mt-3 space-y-2">
              {items.map((it, i) => (
                <div key={i} className="flex items-center gap-2 p-2 rounded-lg border border-border bg-muted/30">
                  <span className="text-xs font-mono text-muted-foreground">{it.code}</span>
                  <span className="flex-1 text-sm truncate">{it.name}</span>
                  <Input type="number" inputMode="decimal" step="0.01" value={it.price} onWheel={(e) => (e.currentTarget as HTMLInputElement).blur()} onChange={(e) => updateItemPrice(i, e.target.value)} className="w-24 h-8" />
                  <Button size="icon" variant="ghost" onClick={() => removeItem(i)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                </div>
              ))}
              <div className="text-right text-sm">Subtotal: <strong>S/ {subtotal.toFixed(2)}</strong></div>
            </div>
          )}
        </div>

        {/* Precio especial */}
        <div className={`rounded-lg border border-dashed border-primary/40 p-3 space-y-2 ${cancelled ? "opacity-50 pointer-events-none" : ""}`}>
          <label className="flex items-center gap-2 text-sm cursor-pointer">
            <Checkbox checked={special} onCheckedChange={(v) => setSpecial(!!v)} disabled={cancelled} />
            Precio especial (campaña / autorización de jefatura)
          </label>
          {special && (
            <div className="grid grid-cols-2 gap-2">
              <div><Label className="text-xs">Nuevo total (S/)</Label><Input type="number" inputMode="decimal" step="0.01" value={manualTotal} onWheel={(e) => (e.currentTarget as HTMLInputElement).blur()} onChange={(e) => setManualTotal(e.target.value)} /></div>
              <div><Label className="text-xs">Motivo / autorización</Label><Input value={specialReason} onChange={(e) => setSpecialReason(e.target.value)} /></div>
            </div>
          )}
        </div>

        {/* Pagos */}
        <div className={`rounded-lg border border-border p-3 space-y-2 ${cancelled ? "opacity-50 pointer-events-none" : ""}`}>
          <div className="flex items-center justify-between">
            <Label>Métodos de pago {cancelled && <span className="text-primary font-bold">— CANCELADO</span>}</Label>
            <Button type="button" size="sm" variant="outline" onClick={addPayment} disabled={cancelled}><Plus className="h-4 w-4 mr-1" /> Añadir</Button>
          </div>
          {payments.map((p, i) => (
            <div key={i} className="flex gap-2">
              <Select value={p.method} onValueChange={(v) => updatePayment(i, { method: v as PaymentMethod })} disabled={cancelled}>
                <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                <SelectContent>{PAYMENT_METHODS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
              </Select>
              <Input type="number" inputMode="decimal" step="0.01" placeholder="Monto" value={p.amount || ""} disabled={cancelled} onWheel={(e) => (e.currentTarget as HTMLInputElement).blur()} onChange={(e) => updatePayment(i, { amount: e.target.value === "" ? 0 : parseFloat(e.target.value) || 0 })} />
              {payments.length > 1 && <Button size="icon" variant="ghost" onClick={() => removePayment(i)} disabled={cancelled}><Trash2 className="h-4 w-4 text-destructive" /></Button>}
            </div>
          ))}
          <div className="flex justify-between text-sm pt-1 border-t">
            <span>Pagado: <strong>{cancelled ? "CANCELADO" : `S/ ${paid.toFixed(2)}`}</strong></span>
            <span className={!cancelled && Math.abs(paid - total) > 0.01 ? "text-amber-600" : "text-primary"}>
              Total: <strong>S/ {total.toFixed(2)}</strong>
            </span>
          </div>
          {!cancelled && total - paid > 0.01 && (
            <div className="text-right text-xs text-amber-600 font-semibold">Saldo pendiente: S/ {(total - paid).toFixed(2)}</div>
          )}
        </div>

        <div><Label>Observaciones</Label><Textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} /></div>

        <Button onClick={submit} disabled={saving} className="w-full bg-gradient-hero">
          {saving && <Loader2 className="h-4 w-4 animate-spin mr-2" />} Registrar y generar ticket
        </Button>
      </Card>

      {/* Ticket preview */}
      <Card className="p-4 shadow-soft h-fit sticky top-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-bold">Último ticket</h3>
          {lastTicket && <Button size="sm" variant="outline" onClick={printTicket}><Printer className="h-4 w-4 mr-1" /> Imprimir</Button>}
        </div>
        {!lastTicket && <p className="text-sm text-muted-foreground">El ticket aparecerá aquí tras guardar.</p>}
        {lastTicket && <TicketView t={lastTicket} />}
      </Card>

      <Dialog open={!!payDialogReg} onOpenChange={(o) => { if (!o) { setPayDialogReg(null); setPayAmount(""); } }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Wallet className="h-5 w-5 text-primary" /> Pagar saldo pendiente</DialogTitle>
          </DialogHeader>
          {payDialogReg && (
            <div className="space-y-3">
              <div className="rounded-lg border p-3 bg-muted/30 text-sm space-y-1">
                <div><strong>Ticket:</strong> {payDialogReg.ticket_code}</div>
                <div><strong>Paciente:</strong> {payDialogReg.first_names} {payDialogReg.last_names}</div>
                <div><strong>Fecha:</strong> {new Date(payDialogReg.created_at).toLocaleString("es-PE")}</div>
                <div className="flex justify-between pt-1 border-t mt-1">
                  <span>Total:</span><strong>S/ {Number(payDialogReg.total).toFixed(2)}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Pagado:</span><strong>S/ {sumPayments(payDialogReg.payments).toFixed(2)}</strong>
                </div>
                <div className="flex justify-between text-amber-600 font-bold">
                  <span>Saldo:</span><span>S/ {regBalance(payDialogReg).toFixed(2)}</span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-xs">Método</Label>
                  <Select value={payMethod} onValueChange={(v) => setPayMethod(v as PaymentMethod)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{PAYMENT_METHODS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Monto a pagar (S/)</Label>
                  <Input type="number" inputMode="decimal" step="0.01" value={payAmount} onChange={(e) => setPayAmount(e.target.value)} />
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setPayDialogReg(null)} disabled={paySaving}>Cancelar</Button>
            <Button onClick={payPendingBalance} disabled={paySaving}>
              {paySaving && <Loader2 className="h-4 w-4 animate-spin mr-2" />} Registrar pago
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export const TicketView = ({ t }: { t: any }) => {
  const sede = SEDES.find((s) => s.id === t.sede);
  return (
    <div id="ticket-print" className="ticket-paper font-mono text-[13px] font-bold leading-tight border-2 border-black p-3 bg-white text-black w-[300px] mx-auto" style={{ fontWeight: 700 }}>
      <div className="text-center font-bold border-b border-black pb-1">PANORAMAX 3D</div>
      <div className="mt-2"><strong>Sede:</strong> {sede?.short ?? t.sede}</div>
      <div><strong>Dirección:</strong> Panoramax 3D</div>
      <div className="text-center text-lg font-bold my-2">{t.ticket_code}</div>
      <div><strong>Paciente:</strong> {t.first_names} {t.last_names}</div>
      {t.doc_number && <div><strong>Doc:</strong> {t.doc_type.toUpperCase()} {t.doc_number}</div>}
      {(() => {
        const displayDoctor = getDisplayDoctorName(t.doctor_name);
        return (
          <>
            {displayDoctor && <div><strong>Doctor:</strong> {displayDoctor}</div>}
            {t.institution_name && displayDoctor !== TOP_DENT_NAME && <div><strong>Institución:</strong> {t.institution_name}</div>}
          </>
        );
      })()}
      <div className="my-1">{new Date(t.created_at).toLocaleString("es-PE")}</div>
      <div className="border-t border-black pt-1 mt-1">
        <div className="flex justify-between font-bold"><span>Concepto</span><span>Monto S/.</span></div>
        {(t.items as any[]).map((it, i) => (
          <div key={i} className="flex justify-between"><span className="truncate pr-2">{it.name}</span><span>{Number(it.price).toFixed(2)}</span></div>
        ))}
      </div>
      <div className="border-t border-black mt-1 pt-1">
        <div className="flex justify-between font-bold"><span>TOTAL:</span><span>{Number(t.total).toFixed(2)}</span></div>
        {(t.payments as any[]).some((p) => p.method === "CANCELADO") ? (
          <div className="text-center font-bold text-base mt-1 border border-black py-1">CANCELADO</div>
        ) : (
          (t.payments as any[]).map((p, i) => (
            <div key={i} className="flex justify-between"><span>{p.method}:</span><span>{Number(p.amount).toFixed(2)}</span></div>
          ))
        )}
      </div>
      <div className="mt-2 border border-black p-1 text-center">
        Sírvase recoger su radiografía<br />
        Día: {new Date(t.created_at).toLocaleDateString("es-PE")}
      </div>
      <div className="mt-3 text-center">
        <div className="text-[11px] font-bold mb-1">Puedes ver tu estudio escaneando aquí</div>
        <div className="flex justify-center">
          <QRCodeSVG
            value={`${window.location.origin}/buscar?code=${encodeURIComponent(t.ticket_code)}`}
            size={110}
            level="M"
            includeMargin
          />
        </div>
        <div className="text-[10px] mt-1 leading-tight">
          Solo coloca tu fecha de nacimiento{t.birth_date ? <> : <strong>"{(() => { const [y,m,d] = String(t.birth_date).split("-"); return `${d}/${m}/${y}`; })()}"</strong></> : null}
        </div>
      </div>
      <div className="text-center text-[10px] mt-2">
        Lunes a Viernes 09:00 - 21:00<br />Sábados 09:00 - 20:00<br />Domingos previa cita
      </div>
    </div>
  );
};

export default PatientRegistrationTab;

import { useEffect } from "react";
import { SEDES, type SedeId } from "@/data/sedes";
import { MapPin } from "lucide-react";

const KEY = "cedix.sede";

// Auto-select the only sede on first load
const DEFAULT_SEDE = SEDES[0].id;

export const getSede = (): SedeId => (localStorage.getItem(KEY) as SedeId) || DEFAULT_SEDE;
export const setSede = (id: SedeId) => localStorage.setItem(KEY, id);
export const getSedeName = () => SEDES.find((s) => s.id === getSede())?.name ?? "";

/** No longer shows a selection screen — sede is set automatically */
export const SedeGate = ({ onSelected }: { onSelected?: (id: SedeId) => void }) => {
  useEffect(() => {
    setSede(DEFAULT_SEDE);
    onSelected?.(DEFAULT_SEDE);
  }, [onSelected]);

  // Never blocks rendering
  return null;
};

export const SedeBadge = () => {
  const name = getSedeName();
  if (!name) return null;
  return (
    <span
      className="inline-flex items-center gap-1.5 text-xs bg-accent text-accent-foreground rounded-full px-3 py-1"
    >
      <MapPin className="h-3 w-3" /> {name}
    </span>
  );
};

export default SedeGate;

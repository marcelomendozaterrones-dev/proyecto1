import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SEDES } from "@/data/sedes";
import { Download, Building2, TrendingUp, Trash2, Printer, Pencil, Plus, Calendar as CalendarIcon, UserCog } from "lucide-react";
import { toast } from "sonner";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { TicketView, getDisplayDoctorName } from "@/components/PatientRegistrationTab";
import { useEditorMode } from "@/hooks/useEditorMode";
import { useCurrentSede } from "@/hooks/useCurrentSede";
import { getAppPassword } from "@/hooks/useAppPasswords";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { PAYMENT_METHODS, type PaymentMethod } from "@/data/tarifario";

// Peru timezone anchor — todas las fechas se interpretan en hora de Lima,
// sin importar la zona horaria del dispositivo del usuario.
const PE_TZ = "America/Lima";
const PE_OFFSET = "-05:00"; // Perú no aplica horario de verano

// YYYY-MM-DD del día actual en Perú
const today = () => new Date().toLocaleDateString("en-CA", { timeZone: PE_TZ });

// Inicio/fin del día (en Perú) convertidos a ISO UTC para consultar timestamptz
const localDayStart = (ymd: string) => new Date(`${ymd}T00:00:00${PE_OFFSET}`).toISOString();
const localDayEnd = (ymd: string) => new Date(`${ymd}T23:59:59.999${PE_OFFSET}`).toISOString();
// Format YYYY-MM-DD as D/M/YYYY without UTC shift
const fmtYMD = (ymd: string) => { const [y,m,d] = ymd.split("-"); return `${parseInt(d,10)}/${parseInt(m,10)}/${y}`; };

function printPatientSticker(p: { first_names: string; last_names: string; ticket_code: string; created_at?: string | null }) {
  const fullName = `${p.first_names ?? ""} ${p.last_names ?? ""}`.trim().toUpperCase();
  const hc = p.ticket_code ?? "";
  const fecha = new Date(p.created_at ?? Date.now()).toLocaleDateString("es-PE");
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>Sticker ${hc}</title>
<style>
@page { size: A4 portrait; margin: 0; }
* { box-sizing: border-box; }
body { font-family: Arial, sans-serif; margin: 0; padding: 7mm 0 0 0; }
.sticker { width: 90mm; height: 22mm; margin: 0 auto; border: 2.25pt solid #9bbb59; border-radius: 5mm; padding: 2.5mm 4mm; display: flex; flex-direction: column; justify-content: center; }
.row { display: flex; font-size: 11pt; font-weight: bold; line-height: 1.25; margin: 0.3mm 0; white-space: nowrap; }
.label { width: 22mm; flex-shrink: 0; }
.val { flex: 1; word-break: break-word; }
@media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
</style></head><body>
<div class="sticker">
  <div class="row"><span class="label">PACIENTE</span><span>: ${fullName}</span></div>
  <div class="row"><span class="label">HC</span><span>: ${hc}</span></div>
  <div class="row"><span class="label">FECHA</span><span>: ${fecha}</span></div>
</div>
<script>window.addEventListener('load', () => { setTimeout(() => { window.print(); }, 150); });<\/script>
</body></html>`;
  const w = window.open("", "_blank", "width=480,height=300");
  if (!w) return;
  w.document.open(); w.document.write(html); w.document.close();
}

function cleanTicket(code: string) {
  const m = code.match(/^(\d+)\s*-\s*0*(\d+)$/);
  if (m) return `${m[1]} - ${m[2]}`;
  return code;
}

export const SedeAdminTab = () => {
  const { editorMode } = useEditorMode();
  const { sede: currentSede } = useCurrentSede();
  const [sede, setSede] = useState<string>(editorMode ? "all" : (currentSede || "all"));
  useEffect(() => { if (!editorMode) setSede(currentSede || "all"); }, [currentSede, editorMode]);
  const [from, setFrom] = useState(today());
  const [to, setTo] = useState(today());
  const [rows, setRows] = useState<any[]>([]);
  const [selected, setSelected] = useState<any | null>(null);
  const [editing, setEditing] = useState<any | null>(null);
  const [editPayments, setEditPayments] = useState<{ method: PaymentMethod; amount: number }[]>([]);
  const [savingPay, setSavingPay] = useState(false);
  const [cashClose, setCashClose] = useState(false);
  const [reportDate, setReportDate] = useState(today());
  const [closed, setClosed] = useState(false);

  const openEdit = (row: any) => {
    setEditing(row);
    const ps = (row.payments as any[]) ?? [];
    setEditPayments(ps.length ? ps.map((p) => ({ method: p.method, amount: Number(p.amount) || 0 })) : [{ method: "EFECTIVO" as PaymentMethod, amount: Number(row.total) || 0 }]);
  };

  const savePayments = async () => {
    if (!editing) return;
    const total = Number(editing.total) || 0;
    const paid = editPayments.reduce((a, b) => a + Number(b.amount || 0), 0);
    if (Math.abs(paid - total) > 0.01) {
      toast.error(`Pagos (S/. ${paid.toFixed(2)}) no coinciden con total (S/. ${total.toFixed(2)})`);
      return;
    }
    setSavingPay(true);
    const { error } = await supabase.from("patient_registrations").update({ payments: editPayments as any }).eq("id", editing.id);
    setSavingPay(false);
    if (error) { toast.error("Error: " + error.message); return; }
    toast.success("Medio de pago actualizado");
    setEditing(null);
    load();
  };

  const load = async () => {
    let q = supabase.from("patient_registrations").select("*")
      .gte("created_at", localDayStart(from)).lte("created_at", localDayEnd(to))
      .order("ticket_number", { ascending: true });
    if (sede !== "all") q = q.eq("sede", sede);
    const { data } = await q;
    const numOf = (r: any) => {
      const m = String(r.ticket_code ?? "").match(/(\d+)\s*$/);
      return m ? parseInt(m[1], 10) : (r.ticket_number ?? 0);
    };
    const sorted = (data ?? []).slice().sort((a, b) => numOf(a) - numOf(b));
    setRows(sorted);
  };

  useEffect(() => { load(); }, [sede, from, to]);

  const handleEditTicket = async (row: any) => {
    if (!editorMode) {
      const pwd = window.prompt(`Ingrese contraseña para editar el N° de talón ${row.ticket_code}:`);
      if (pwd === null) return;
      if (pwd !== getAppPassword("edit_ticket_number")) { toast.error("Contraseña incorrecta"); return; }
    }
    const next = window.prompt("Nuevo número de talón:", row.ticket_code);
    if (next === null) return;
    const newCode = next.trim();
    if (!newCode) { toast.error("El talón no puede estar vacío"); return; }
    if (newCode === row.ticket_code) return;
    const { error } = await supabase.from("patient_registrations").update({ ticket_code: newCode }).eq("id", row.id);
    if (error) { toast.error("Error: " + error.message); return; }
    toast.success("Talón actualizado");
    load();
  };

  const handleEditDate = async (row: any) => {
    if (!editorMode) {
      const pwd = window.prompt(`Ingrese contraseña para editar la fecha de registro de ${row.ticket_code}:`);
      if (pwd === null) return;
      if (pwd !== getAppPassword("edit_registration_date")) { toast.error("Contraseña incorrecta"); return; }
    }
    // Fecha actual en Perú (YYYY-MM-DD)
    const currentYMD = new Date(row.created_at).toLocaleDateString("en-CA", { timeZone: PE_TZ });
    const next = window.prompt("Nueva fecha de registro (YYYY-MM-DD):", currentYMD);
    if (next === null) return;
    const newYMD = next.trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(newYMD)) { toast.error("Formato inválido. Use YYYY-MM-DD"); return; }
    if (newYMD === currentYMD) return;
    // Conserva la hora original pero cambia el día (interpretado en hora de Lima)
    const hhmmss = new Date(row.created_at).toLocaleTimeString("en-GB", { timeZone: PE_TZ, hour12: false });
    const newISO = new Date(`${newYMD}T${hhmmss}${PE_OFFSET}`).toISOString();
    const { error } = await supabase.from("patient_registrations").update({ created_at: newISO }).eq("id", row.id);
    if (error) { toast.error("Error: " + error.message); return; }
    toast.success("Fecha de registro actualizada");
    load();
  };

  const handleEditName = async (row: any) => {
    if (!editorMode) return;
    const currentFirst = row.first_names ?? "";
    const currentLast = row.last_names ?? "";
    const nextFirst = window.prompt("Nombres del paciente:", currentFirst);
    if (nextFirst === null) return;
    const nextLast = window.prompt("Apellidos del paciente:", currentLast);
    if (nextLast === null) return;
    const fn = nextFirst.trim();
    const ln = nextLast.trim();
    if (!fn || !ln) { toast.error("Nombres y apellidos no pueden estar vacíos"); return; }
    if (fn === currentFirst && ln === currentLast) return;
    const { error } = await supabase.from("patient_registrations").update({ first_names: fn, last_names: ln }).eq("id", row.id);
    if (error) { toast.error("Error: " + error.message); return; }
    toast.success("Nombre del paciente actualizado");
    load();
  };

  const handleDelete = async (row: any) => {
    if (!editorMode) {
      const pwd = window.prompt(`Ingrese contraseña para eliminar el talón ${row.ticket_code}:`);
      if (pwd === null) return;
      if (pwd !== getAppPassword("delete_registration")) { toast.error("Contraseña incorrecta"); return; }
      if (!window.confirm(`¿Eliminar definitivamente el registro ${row.ticket_code}?`)) return;
    } else {
      if (!window.confirm(`¿Eliminar definitivamente el talón ${row.ticket_code}?`)) return;
    }
    const { error } = await supabase.from("patient_registrations").delete().eq("id", row.id);
    if (error) { toast.error("Error al eliminar: " + error.message); return; }
    toast.success("Registro eliminado");
    load();
  };

  const totals = useMemo(() => {
    const byMethod: Record<string, number> = {};
    const bySede: Record<string, { count: number; total: number }> = {};
    let total = 0;
    rows.forEach((r) => {
      total += Number(r.total);
      bySede[r.sede] ||= { count: 0, total: 0 };
      bySede[r.sede].count++; bySede[r.sede].total += Number(r.total);
      (r.payments as any[]).forEach((p) => { byMethod[p.method] = (byMethod[p.method] || 0) + Number(p.amount); });
    });
    return { total, byMethod, bySede, count: rows.length };
  }, [rows]);

  const exportExcel = () => {
    const data = rows.map((r) => ({
      "Número de Talón": r.ticket_code,
      "Nombre del Paciente": `${r.first_names} ${r.last_names}`,
      "Edad": r.age ?? "",
      "Estudio Realizado": (r.items as any[]).map((i) => i.name).join(" + "),
      "Fecha": new Date(r.created_at).toLocaleString("es-PE"),
      "Doctor Solicitante": getDisplayDoctorName(r.doctor_name) ?? "",
      "Costo del Estudio": Number(r.total).toFixed(2),
      "Método de Pago": (r.payments as any[]).map((p) => `${p.method} S/${Number(p.amount).toFixed(2)}`).join(" + "),
      "Sede": SEDES.find((s) => s.id === r.sede)?.name ?? r.sede,
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Reporte");
    XLSX.writeFile(wb, `reporte_${from}_a_${to}.xlsx`);
  };

  const downloadPDF = async () => {
    const el = document.getElementById("cash-close-print");
    if (!el) return;
    try {
      const canvas = await html2canvas(el, { scale: 2, backgroundColor: "#ffffff", useCORS: true });
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
      const pageW = pdf.internal.pageSize.getWidth();
      const pageH = pdf.internal.pageSize.getHeight();
      const margin = 8;
      const imgW = pageW - margin * 2;
      const imgH = (canvas.height * imgW) / canvas.width;
      let heightLeft = imgH;
      let position = margin;
      pdf.addImage(imgData, "PNG", margin, position, imgW, imgH);
      heightLeft -= (pageH - margin * 2);
      while (heightLeft > 0) {
        position = margin - (imgH - heightLeft);
        pdf.addPage();
        pdf.addImage(imgData, "PNG", margin, position, imgW, imgH);
        heightLeft -= (pageH - margin * 2);
      }
      pdf.save(`reporte_${reportDate}.pdf`);
      toast.success("PDF descargado");
    } catch (e: any) {
      toast.error("Error al generar PDF: " + e.message);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="p-4 shadow-soft flex flex-wrap items-end gap-3">
        <div>
          <Label>Sede</Label>
          <Select value={sede} onValueChange={setSede} disabled={!editorMode}>
            <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
            <SelectContent>
              {editorMode && <SelectItem value="all">Todas las sedes</SelectItem>}
              {SEDES.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div><Label>Desde</Label><Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></div>
        <div><Label>Hasta</Label><Input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></div>
        <Button onClick={exportExcel} className="bg-gradient-hero"><Download className="h-4 w-4 mr-1" /> Exportar Excel</Button>
        <Button onClick={() => { const d = today(); setReportDate(d); setFrom(d); setTo(d); setClosed(false); setCashClose(true); }} variant="outline"><Printer className="h-4 w-4 mr-1" /> Reporte diario</Button>
      </Card>

      {editorMode && (
        <div className="grid md:grid-cols-4 gap-4">
          <Card className="p-5 shadow-soft">
            <div className="text-xs text-muted-foreground flex items-center gap-1"><TrendingUp className="h-3 w-3" /> Atenciones</div>
            <div className="text-3xl font-bold text-primary">{totals.count}</div>
          </Card>
          <Card className="p-5 shadow-soft">
            <div className="text-xs text-muted-foreground">Ingresos totales</div>
            <div className="text-3xl font-bold text-primary">S/ {totals.total.toFixed(2)}</div>
          </Card>
          {Object.entries(totals.byMethod).slice(0, 2).map(([m, v]) => (
            <Card key={m} className="p-5 shadow-soft">
              <div className="text-xs text-muted-foreground">{m}</div>
              <div className="text-3xl font-bold text-primary">S/ {v.toFixed(2)}</div>
            </Card>
          ))}
        </div>
      )}


      <Card className="p-5 shadow-soft">
        <h3 className="font-bold mb-3 flex items-center gap-2"><Building2 className="h-4 w-4 text-primary" /> Por sede</h3>
        <div className="space-y-2">
          {Object.entries(totals.bySede).map(([id, v]) => (
            <div key={id} className="flex items-center justify-between p-2 rounded bg-muted/30">
              <span>{SEDES.find((s) => s.id === id)?.name ?? id}</span>
              <span className="text-sm">{v.count} atenciones · <strong>S/ {v.total.toFixed(2)}</strong></span>
            </div>
          ))}
          {Object.keys(totals.bySede).length === 0 && <p className="text-sm text-muted-foreground">Sin registros en este rango.</p>}
        </div>
      </Card>

      <Card className="p-5 shadow-soft">
        <h3 className="font-bold mb-3">Reporte detallado</h3>
        <div className="overflow-auto">
          <table className="w-full text-xs">
            <thead className="bg-muted">
              <tr className="text-left">
                <th className="px-1.5 py-1">Talón</th>
                <th className="px-1.5 py-1">Paciente</th>
                <th className="px-1.5 py-1 text-center">Edad</th>
                <th className="px-1.5 py-1">Estudio</th>
                <th className="px-1.5 py-1">Doctor</th>
                <th className="px-1.5 py-1 text-right">Total</th>
                <th className="px-1.5 py-1">Pago</th>
                <th className="px-1.5 py-1 text-right">Acciones</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id} className="border-b border-border hover:bg-accent/40">
                  <td className="px-1.5 py-1 font-mono whitespace-nowrap">{cleanTicket(r.ticket_code)}</td>
                  <td className="px-1.5 py-1">{r.first_names} {r.last_names}</td>
                  <td className="px-1.5 py-1 text-center">{r.age ?? "-"}</td>
                  <td className="px-1.5 py-1">{(r.items as any[]).map((i) => i.name).join(" + ")}</td>
                  <td className="px-1.5 py-1">{getDisplayDoctorName(r.doctor_name) ?? "-"}</td>
                  <td className="px-1.5 py-1 text-right font-semibold">S/ {Number(r.total).toFixed(2)}</td>
                  <td className="px-1.5 py-1">{(r.payments as any[]).map((p) => `${p.method} S/${Number(p.amount).toFixed(2)}`).join(" + ")}</td>
                  <td className="px-1.5 py-1 whitespace-nowrap text-right">
                    <Button size="sm" variant="ghost" onClick={() => setSelected(r)}>Ver</Button>
                    <Button size="sm" variant="ghost" title="Editar N° de talón" onClick={() => handleEditTicket(r)} className="font-mono">N°</Button>
                    {editorMode && (
                      <Button size="sm" variant="ghost" title="Editar nombre del paciente" onClick={() => handleEditName(r)}><UserCog className="h-4 w-4" /></Button>
                    )}
                    <Button size="sm" variant="ghost" title="Editar fecha de registro" onClick={() => handleEditDate(r)}><CalendarIcon className="h-4 w-4" /></Button>
                    <Button size="sm" variant="ghost" title="Editar medio de pago" onClick={() => openEdit(r)}><Pencil className="h-4 w-4" /></Button>
                    <Button size="sm" variant="ghost" title="Imprimir sticker" onClick={() => printPatientSticker(r)}><Printer className="h-4 w-4" /></Button>
                    <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive" onClick={() => handleDelete(r)}><Trash2 className="h-4 w-4" /></Button>
                  </td>
                </tr>
              ))}
              {rows.length === 0 && <tr><td colSpan={8} className="p-4 text-center text-muted-foreground">Sin registros.</td></tr>}
            </tbody>
            <tfoot>
              <tr className="font-bold bg-muted/40"><td colSpan={5} className="px-1.5 py-1 text-right">Total general:</td><td className="px-1.5 py-1 text-right">S/ {totals.total.toFixed(2)}</td><td colSpan={2}></td></tr>
            </tfoot>
          </table>
        </div>
      </Card>

      {selected && (
        <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur flex items-center justify-center p-4" onClick={() => setSelected(null)}>
          <div onClick={(e) => e.stopPropagation()}>
            <TicketView t={selected} />
            <div className="text-center mt-2"><Button onClick={() => window.print()}>Imprimir</Button></div>
          </div>
        </div>
      )}

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Editar medio de pago — {editing?.ticket_code}</DialogTitle></DialogHeader>
          <div className="space-y-2">
            <div className="text-sm text-muted-foreground">Total del talón: <strong>S/ {Number(editing?.total ?? 0).toFixed(2)}</strong></div>
            {editPayments.map((p, i) => (
              <div key={i} className="flex gap-2">
                <Select value={p.method} onValueChange={(v) => { const c = [...editPayments]; c[i] = { ...c[i], method: v as PaymentMethod }; setEditPayments(c); }}>
                  <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                  <SelectContent>{PAYMENT_METHODS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
                </Select>
                <Input type="number" step="0.01" value={p.amount || ""} onChange={(e) => { const c = [...editPayments]; c[i] = { ...c[i], amount: parseFloat(e.target.value) || 0 }; setEditPayments(c); }} />
                {editPayments.length > 1 && <Button size="icon" variant="ghost" onClick={() => setEditPayments(editPayments.filter((_, idx) => idx !== i))}><Trash2 className="h-4 w-4 text-destructive" /></Button>}
              </div>
            ))}
            <Button type="button" size="sm" variant="outline" onClick={() => setEditPayments([...editPayments, { method: "EFECTIVO" as PaymentMethod, amount: 0 }])}><Plus className="h-4 w-4 mr-1" /> Añadir método</Button>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>Cancelar</Button>
            <Button onClick={savePayments} disabled={savingPay}>Guardar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {cashClose && (
        <div className="fixed inset-0 z-50 bg-background/90 backdrop-blur overflow-auto p-4 print:bg-white print:p-0" onClick={() => setCashClose(false)}>
          <div onClick={(e) => e.stopPropagation()} className="max-w-4xl mx-auto bg-white text-black rounded-lg shadow-lg p-8 print:shadow-none print:rounded-none print:max-w-full" id="cash-close-print">
            <div className="mb-4 print:hidden flex flex-wrap items-end gap-3 border-b pb-3">
              <div>
                <Label className="text-black">Fecha del reporte</Label>
                <Input type="date" value={reportDate} onChange={(e) => { setReportDate(e.target.value); setFrom(e.target.value); setTo(e.target.value); setClosed(false); }} className="text-black" />
              </div>
              <div className="text-xs text-gray-600">Por defecto se muestra el día de hoy. Cambia la fecha para consultar otro día.</div>
            </div>
            <div className="flex justify-between items-start mb-4 print:mb-2">
              <div>
                <div className="text-xs">Fecha desde: <strong>{fmtYMD(reportDate)}</strong> hasta <strong>{fmtYMD(reportDate)}</strong></div>
                <h2 className="text-xl font-bold mt-1">{closed ? "CIERRE DE CAJA" : "REPORTE DIARIO"}</h2>
              </div>
              <div className="text-right text-xs">
                <div>Sede:</div>
                <div className="font-bold text-base uppercase">{sede === "all" ? "TODAS" : (SEDES.find((s) => s.id === sede)?.name ?? sede)}</div>
              </div>
            </div>

            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="border-y-2 border-black">
                  <th className="p-1 text-left">Número de Talón</th>
                  <th className="p-1 text-left">Nombre del Paciente</th>
                  <th className="p-1 text-left">Doctor</th>
                  <th className="p-1 text-left">Estudio Realizado</th>
                  <th className="p-1 text-right">Monto Pagado</th>
                  <th className="p-1 text-left">Forma de Pago</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} className="border-b border-dotted border-gray-400">
                    <td className="p-1 font-mono">{r.ticket_code}</td>
                    <td className="p-1 uppercase">{r.first_names} {r.last_names}</td>
                    <td className="p-1 uppercase">{getDisplayDoctorName(r.doctor_name) ?? "-"}</td>
                    <td className="p-1">{(r.items as any[]).map((i) => i.name).join(" + ")}</td>
                    <td className="p-1 text-right">S/ {Number(r.total).toFixed(2)}</td>
                    <td className="p-1 uppercase">{(r.payments as any[]).map((p) => p.method).join(" + ")}</td>
                  </tr>
                ))}
                {rows.length === 0 && <tr><td colSpan={6} className="p-3 text-center">Sin atenciones el día de hoy.</td></tr>}
              </tbody>
              <tfoot>
                <tr className="border-t-2 border-black font-bold">
                  <td colSpan={4} className="p-1 text-right">Total (A):</td>
                  <td className="p-1 text-right">S/ {totals.total.toFixed(2)}</td>
                  <td></td>
                </tr>
              </tfoot>
            </table>



            <div className="mt-6 border border-black p-4 max-w-sm ml-auto">
              <div className="font-bold mb-2 text-center">RESUMEN POR FORMA DE PAGO</div>
              {Object.entries(totals.byMethod).map(([m, v]) => (
                <div key={m} className="flex justify-between border-b border-dotted border-gray-400 py-1">
                  <span className="uppercase">{m}</span>
                  <span>S/ {v.toFixed(2)}</span>
                </div>
              ))}
              {Object.keys(totals.byMethod).length === 0 && <div className="text-center text-gray-500 text-xs">Sin pagos</div>}
              <div className="flex justify-between border-t-2 border-black mt-2 pt-2 font-bold text-base">
                <span>TOTAL GENERAL:</span>
                <span>S/ {totals.total.toFixed(2)}</span>
              </div>
            </div>

            <div className="mt-8 grid grid-cols-2 gap-8 text-xs">
              <div className="text-center"><div className="border-t border-black pt-1 mt-12">Entregado por</div></div>
              <div className="text-center"><div className="border-t border-black pt-1 mt-12">Recibido por</div></div>
            </div>

            <div className="text-center mt-4 print:hidden flex gap-2 justify-center flex-wrap">
              <Button onClick={() => window.print()}><Printer className="h-4 w-4 mr-1" /> Imprimir</Button>
              {!closed && <Button variant="default" className="bg-gradient-hero" onClick={() => { setClosed(true); toast.success("Caja cerrada para " + fmtYMD(reportDate)); }}>Cierre de caja</Button>}
              <Button variant="outline" onClick={downloadPDF}><Download className="h-4 w-4 mr-1" /> Descargar PDF</Button>
              {closed && <span className="text-xs text-green-700 font-semibold self-center">✓ Caja cerrada</span>}
              <Button variant="outline" onClick={() => setCashClose(false)}>Cerrar</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SedeAdminTab;

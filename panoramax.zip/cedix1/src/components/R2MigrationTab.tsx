import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, CloudUpload, CheckCircle2, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

interface BatchResult {
  id: string;
  key: string;
  status: string;
  error?: string;
  bytes?: number;
}

const FROM = "2026-05-01T00:00:00Z";
const TO = "2026-06-01T00:00:00Z";

export default function R2MigrationTab() {
  const [pending, setPending] = useState<number | null>(null);
  const [migrated, setMigrated] = useState<number>(0);
  const [failed, setFailed] = useState<number>(0);
  const [total, setTotal] = useState<number | null>(null);
  const [running, setRunning] = useState(false);
  const [stopRequested, setStopRequested] = useState(false);
  const [adminKey, setAdminKey] = useState("");
  const [batchSize, setBatchSize] = useState(5);
  const [log, setLog] = useState<BatchResult[]>([]);

  const refreshCounts = async () => {
    const { count: pendingCount } = await supabase
      .from("studies")
      .select("id", { count: "exact", head: true })
      .eq("storage_provider", "supabase");
    const { count: totalCount } = await supabase
      .from("studies")
      .select("id", { count: "exact", head: true });
    setPending(pendingCount ?? 0);
    setTotal(totalCount ?? 0);
    setMigrated((totalCount ?? 0) - (pendingCount ?? 0));
  };

  useEffect(() => { refreshCounts(); }, []);

  const runOnce = async () => {
    const { data, error } = await supabase.functions.invoke("migrate-studies-to-r2", {
      body: { admin_key: adminKey, limit: batchSize },
    });
    if (error) throw new Error(error.message);
    if ((data as any)?.error) throw new Error((data as any).error);
    return data as { total: number; migrated: number; failed: number; results: BatchResult[] };
  };

  const startMigration = async () => {
    if (!adminKey) { toast.error("Ingresa la clave maestra"); return; }
    setRunning(true);
    setStopRequested(false);
    setFailed(0);
    setLog([]);
    try {
      while (true) {
        if (stopRequested) break;
        const res = await runOnce();
        setLog((prev) => [...res.results, ...prev].slice(0, 200));
        setFailed((f) => f + res.failed);
        await refreshCounts();
        if (res.total === 0) {
          toast.success("Migración completada");
          break;
        }
        // small breather between batches
        await new Promise((r) => setTimeout(r, 400));
      }
    } catch (e: any) {
      toast.error(e.message ?? "Error en la migración");
    } finally {
      setRunning(false);
      setStopRequested(false);
    }
  };

  const runSingleBatch = async () => {
    if (!adminKey) { toast.error("Ingresa la clave maestra"); return; }
    setRunning(true);
    try {
      const res = await runOnce();
      setLog((prev) => [...res.results, ...prev].slice(0, 200));
      setFailed((f) => f + res.failed);
      await refreshCounts();
      toast.success(`Lote: ${res.migrated} migrados, ${res.failed} fallidos`);
    } catch (e: any) {
      toast.error(e.message ?? "Error en el lote");
    } finally {
      setRunning(false);
    }
  };

  const pct = total && total > 0 ? Math.round((migrated / total) * 100) : 0;

  return (
    <div className="space-y-6">
      <Card className="p-6 shadow-soft">
        <div className="flex items-start gap-3 mb-4">
          <CloudUpload className="h-6 w-6 text-primary mt-0.5" />
          <div>
            <h3 className="font-bold text-lg">Migración a Cloudflare R2</h3>
            <p className="text-sm text-muted-foreground">
              Migra <strong>todos los estudios pendientes</strong> desde Supabase Storage hacia el bucket <code>cedix-pacientes</code> en R2. Cada archivo se copia, se verifica y se elimina del bucket original para liberar espacio.
            </p>
          </div>
        </div>

        <div className="grid sm:grid-cols-3 gap-4 mb-4">
          <Card className="p-4 bg-muted/40">
            <div className="text-xs text-muted-foreground">Total estudios</div>
            <div className="text-3xl font-bold">{total ?? "—"}</div>
          </Card>
          <Card className="p-4 bg-muted/40">
            <div className="text-xs text-muted-foreground">Migrados a R2</div>
            <div className="text-3xl font-bold text-primary">{migrated}</div>
          </Card>
          <Card className="p-4 bg-muted/40">
            <div className="text-xs text-muted-foreground">Pendientes</div>
            <div className="text-3xl font-bold">{pending ?? "—"}</div>
          </Card>
        </div>

        <div className="space-y-2 mb-4">
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Progreso</span>
            <span>{migrated} / {total ?? "—"} ({pct}%)</span>
          </div>
          <Progress value={pct} />
          {failed > 0 && (
            <div className="text-xs text-destructive flex items-center gap-1">
              <AlertTriangle className="h-3 w-3" /> {failed} fallido(s) en esta sesión
            </div>
          )}
        </div>

        <div className="grid sm:grid-cols-[1fr,140px] gap-3 mb-4">
          <div>
            <Label htmlFor="adminkey" className="text-xs">Clave maestra</Label>
            <Input id="adminkey" type="password" value={adminKey} onChange={(e) => setAdminKey(e.target.value)} placeholder="••••••••" disabled={running} />
          </div>
          <div>
            <Label htmlFor="bs" className="text-xs">Lote</Label>
            <Input id="bs" type="number" min={1} max={10} value={batchSize} onChange={(e) => setBatchSize(Number(e.target.value))} disabled={running} />
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button onClick={startMigration} disabled={running || !pending}>
            {running ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <CloudUpload className="h-4 w-4 mr-2" />}
            {running ? "Migrando..." : "Iniciar migración completa"}
          </Button>
          <Button variant="outline" onClick={runSingleBatch} disabled={running || !pending}>
            Migrar un lote
          </Button>
          {running && (
            <Button variant="destructive" onClick={() => setStopRequested(true)}>
              Detener al terminar lote
            </Button>
          )}
          <Button variant="ghost" onClick={refreshCounts} disabled={running}>
            Refrescar
          </Button>
        </div>
      </Card>

      {log.length > 0 && (
        <Card className="p-6 shadow-soft">
          <h4 className="font-semibold mb-3">Últimos resultados ({log.length})</h4>
          <div className="space-y-1 max-h-[400px] overflow-y-auto text-xs font-mono">
            {log.map((r, i) => (
              <div key={i} className="flex items-start gap-2 border-b border-border/50 py-1">
                {r.status === "migrated" ? (
                  <CheckCircle2 className="h-3.5 w-3.5 text-primary mt-0.5 flex-shrink-0" />
                ) : r.status === "failed" ? (
                  <AlertTriangle className="h-3.5 w-3.5 text-destructive mt-0.5 flex-shrink-0" />
                ) : (
                  <AlertTriangle className="h-3.5 w-3.5 text-yellow-600 mt-0.5 flex-shrink-0" />
                )}
                <div className="flex-1 min-w-0">
                  <div className="truncate">{r.key}</div>
                  {r.error && <div className="text-destructive">{r.error}</div>}
                </div>
                <div className="text-muted-foreground">{r.status}</div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

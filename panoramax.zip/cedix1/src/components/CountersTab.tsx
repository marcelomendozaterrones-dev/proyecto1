import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Hash, Save, Loader2 } from "lucide-react";
import { SEDES } from "@/data/sedes";
import { toast } from "sonner";

interface Counter { sede: string; last_number: number; }

export const CountersTab = () => {
  const [rows, setRows] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("ticket_counters").select("*");
    const map: Record<string, number> = {};
    SEDES.forEach((s) => { map[s.id] = 0; });
    (data as Counter[] | null)?.forEach((r) => { map[r.sede] = r.last_number; });
    setRows(map);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const save = async (sede: string) => {
    const value = Number(rows[sede]) || 0;
    const { data: existing } = await supabase.from("ticket_counters").select("sede").eq("sede", sede).maybeSingle();
    const { error } = existing
      ? await supabase.from("ticket_counters").update({ last_number: value }).eq("sede", sede)
      : await supabase.from("ticket_counters").insert({ sede, last_number: value });
    if (error) return toast.error(error.message);
    toast.success(`Talón actualizado para ${sede.toUpperCase()}`);
  };

  return (
    <Card className="p-6 shadow-soft space-y-4">
      <h2 className="text-xl font-bold flex items-center gap-2"><Hash className="h-5 w-5 text-primary" /> Modificar número de talones</h2>
      <p className="text-sm text-muted-foreground">El siguiente paciente registrado en cada sede recibirá este número + 1.</p>
      {loading && <div className="flex justify-center py-10"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>}
      {!loading && (
        <div className="space-y-3">
          {SEDES.map((s) => (
            <div key={s.id} className="grid grid-cols-12 gap-3 items-end p-3 rounded-lg border border-border bg-background">
              <div className="col-span-6">
                <Label>{s.name}</Label>
                <p className="text-xs text-muted-foreground">ID: {s.id}</p>
              </div>
              <div className="col-span-4">
                <Label>Último N° emitido</Label>
                <Input type="number" value={rows[s.id] ?? 0} onChange={(e) => setRows({ ...rows, [s.id]: Number(e.target.value) || 0 })} />
              </div>
              <div className="col-span-2">
                <Button onClick={() => save(s.id)} className="w-full"><Save className="h-4 w-4 mr-1" /> Guardar</Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
};

export default CountersTab;

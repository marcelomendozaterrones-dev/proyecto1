import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Trash2, Save, Search, FileSpreadsheet, Stethoscope, Loader2, Briefcase, PackageCheck, CalendarDays } from "lucide-react";
import { toast } from "sonner";
import * as XLSX from "xlsx";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

interface Doctor { id: string; full_name: string; specialty: string | null; phone: string | null; email: string | null; notes: string | null; cop?: string | null; district?: string | null; status?: string | null; }
interface Tarifa { id: string; code: string; name: string; price: number; }
interface Commission { id?: string; doctor_id: string; tarifario_item_id: string | null; commission_type: "percent" | "fixed"; commission_value: number; enabled: boolean; }
interface Reg { id: string; created_at: string; ticket_code: string; first_names: string; last_names: string; doctor_name: string | null; items: any; total: number; }
interface Delivery { id: string; doctor_name: string; delivery_date: string; quantity: number; notes: string | null; }

export const DoctorsTab = () => {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [tarifas, setTarifas] = useState<Tarifa[]>([]);
  const [filter, setFilter] = useState("");
  const [selected, setSelected] = useState<Doctor | null>(null);
  const [loading, setLoading] = useState(true);
  const [openNew, setOpenNew] = useState(false);
  const [n, setN] = useState({ full_name: "", specialty: "", phone: "", email: "" });

  const load = async () => {
    setLoading(true);
    // Solo sincroniza nombres desde custom_doctors hacia doctors_directory.
    // No re-agrega nombres históricos de patient_registrations para que la eliminación sea persistente.
    const [{ data: dirNow }, { data: cds }] = await Promise.all([
      supabase.from("doctors_directory").select("full_name"),
      supabase.from("custom_doctors").select("full_name,specialty,phone,email" as any),
    ]);
    const existing = new Set((dirNow ?? []).map((r: any) => String(r.full_name).trim().toUpperCase()));
    const toInsert: { full_name: string; specialty?: string | null; phone?: string | null; email?: string | null }[] = [];
    const seen = new Set<string>();
    (cds ?? []).forEach((r: any) => {
      const n = String(r.full_name ?? "").trim().toUpperCase();
      if (!n || existing.has(n) || seen.has(n)) return;
      seen.add(n);
      toInsert.push({ full_name: n, specialty: r.specialty ?? null, phone: r.phone ?? null, email: r.email ?? null });
    });
    if (toInsert.length) {
      await supabase.from("doctors_directory").insert(toInsert);
    }
    const [{ data: ds }, { data: ts }] = await Promise.all([
      supabase.from("doctors_directory").select("*").order("full_name"),
      supabase.from("tarifario_items").select("id,code,name,price").order("sort_order"),
    ]);
    setDoctors((ds as Doctor[]) ?? []);
    setTarifas((ts as Tarifa[]) ?? []);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const filtered = doctors.filter((d) => d.full_name.toUpperCase().includes(filter.toUpperCase()));

  const createDoctor = async () => {
    if (!n.full_name.trim()) return toast.error("Nombre requerido");
    const { data, error } = await supabase.from("doctors_directory").insert({
      full_name: n.full_name.trim().toUpperCase(),
      specialty: n.specialty.trim() || null,
      phone: n.phone.trim() || null,
      email: n.email.trim() || null,
    }).select().single();
    if (error) return toast.error(error.message);
    setDoctors((p) => [...p, data as Doctor].sort((a, b) => a.full_name.localeCompare(b.full_name)));
    setSelected(data as Doctor);
    setN({ full_name: "", specialty: "", phone: "", email: "" });
    setOpenNew(false);
    toast.success("Doctor agregado");
  };

  const removeDoctor = async (d: Doctor) => {
    if (!confirm(`¿Eliminar al doctor "${d.full_name}"? Esta acción no se puede deshacer.`)) return;
    const name = d.full_name.trim().toUpperCase();
    const { error } = await supabase.from("doctors_directory").delete().eq("id", d.id);
    if (error) return toast.error(error.message);
    // También eliminar de custom_doctors para evitar que se re-sincronice al recargar
    await supabase.from("custom_doctors").delete().ilike("full_name", name);
    setDoctors((p) => p.filter((x) => x.id !== d.id));
    if (selected?.id === d.id) setSelected(null);
    toast.success("Doctor eliminado");
  };

  return (
    <Card className="p-6 shadow-soft">
      <div className="flex items-center justify-between gap-3 flex-wrap mb-4">
        <h2 className="text-xl font-bold flex items-center gap-2"><Stethoscope className="h-5 w-5 text-primary" /> Doctores</h2>
        <Dialog open={openNew} onOpenChange={setOpenNew}>
          <DialogTrigger asChild><Button className="bg-gradient-hero"><Plus className="h-4 w-4 mr-1" /> Agregar doctor</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Nuevo doctor</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label>Nombre completo</Label><Input value={n.full_name} onChange={(e) => setN({ ...n, full_name: e.target.value.toUpperCase() })} /></div>
              <div><Label>Especialidad</Label><Input value={n.specialty} onChange={(e) => setN({ ...n, specialty: e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Teléfono</Label><Input value={n.phone} onChange={(e) => setN({ ...n, phone: e.target.value })} /></div>
                <div><Label>Email</Label><Input value={n.email} onChange={(e) => setN({ ...n, email: e.target.value })} /></div>
              </div>
            </div>
            <DialogFooter><Button onClick={createDoctor}>Guardar</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        {/* Lista */}
        <div className="space-y-2 md:col-span-1">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input className="pl-8" placeholder="Buscar..." value={filter} onChange={(e) => setFilter(e.target.value)} />
          </div>
          {loading && <div className="flex justify-center py-6"><Loader2 className="h-5 w-5 animate-spin" /></div>}
          <div className="max-h-[600px] overflow-auto space-y-1">
            {filtered.map((d) => (
              <div key={d.id} className={`flex items-center gap-1 rounded-lg border ${selected?.id === d.id ? "border-primary bg-primary/5" : "border-border"}`}>
                <button type="button" onClick={() => setSelected(d)} className="flex-1 text-left px-3 py-2 text-sm truncate">
                  <div className="font-medium truncate">{d.full_name}</div>
                  {d.specialty && <div className="text-xs text-muted-foreground truncate">{d.specialty}</div>}
                </button>
                <Button size="icon" variant="ghost" onClick={() => removeDoctor(d)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
              </div>
            ))}
            {filtered.length === 0 && !loading && <p className="text-sm text-muted-foreground p-3">Sin doctores.</p>}
          </div>
        </div>

        {/* Detalle */}
        <div className="md:col-span-2">
          {!selected && <p className="text-sm text-muted-foreground">Selecciona un doctor para editar sus datos, comisiones y ver sus pacientes.</p>}
          {selected && <DoctorDetail key={selected.id} doctor={selected} tarifas={tarifas} onUpdated={(d) => { setSelected(d); setDoctors((p) => p.map((x) => x.id === d.id ? d : x)); }} />}
        </div>
      </div>
    </Card>
  );
};

const DoctorDetail = ({ doctor, tarifas, onUpdated }: { doctor: Doctor; tarifas: Tarifa[]; onUpdated: (d: Doctor) => void }) => {
  const [data, setData] = useState<Doctor>(doctor);
  const [dateMode, setDateMode] = useState<"all" | "month" | "range">("all");
  const [monthValue, setMonthValue] = useState<string>(new Date().toISOString().slice(0, 7));
  const [dateFrom, setDateFrom] = useState<string>("");
  const [dateTo, setDateTo] = useState<string>("");
  const [commissions, setCommissions] = useState<Commission[]>([]);
  const [regs, setRegs] = useState<Reg[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      const target = doctor.full_name.trim().toUpperCase();
      const [{ data: cs }, { data: rs }] = await Promise.all([
        supabase.from("doctor_commissions").select("*").eq("doctor_id", doctor.id),
        supabase.from("patient_registrations").select("id,created_at,ticket_code,first_names,last_names,doctor_name,items,total").not("doctor_name", "is", null).order("created_at", { ascending: false }),
      ]);
      setCommissions((cs as Commission[]) ?? []);
      const filtered = ((rs as Reg[]) ?? []).filter((r) => String(r.doctor_name ?? "").trim().toUpperCase() === target);
      setRegs(filtered);
      setLoading(false);
    })();
  }, [doctor.id]);

  const saveDoctor = async () => {
    const { error } = await supabase.from("doctors_directory").update({
      full_name: data.full_name.trim().toUpperCase(),
      specialty: data.specialty, phone: data.phone, email: data.email, notes: data.notes,
      cop: data.cop ?? null, district: data.district ?? null,
    } as any).eq("id", doctor.id);
    if (error) return toast.error(error.message);
    onUpdated(data);
    toast.success("Datos guardados");
  };

  const getComm = (tarifa_id: string | null): Commission =>
    commissions.find((c) => c.tarifario_item_id === tarifa_id) ?? { doctor_id: doctor.id, tarifario_item_id: tarifa_id, commission_type: "percent", commission_value: 0, enabled: false };

  const updateLocal = (tarifa_id: string | null, patch: Partial<Commission>) => {
    setCommissions((prev) => {
      const idx = prev.findIndex((c) => c.tarifario_item_id === tarifa_id);
      if (idx >= 0) { const cp = [...prev]; cp[idx] = { ...cp[idx], ...patch }; return cp; }
      return [...prev, { doctor_id: doctor.id, tarifario_item_id: tarifa_id, commission_type: "percent", commission_value: 0, enabled: false, ...patch }];
    });
  };

  const saveComm = async (tarifa_id: string | null) => {
    const c = commissions.find((x) => x.tarifario_item_id === tarifa_id);
    if (!c) return;
    const payload = { doctor_id: doctor.id, tarifario_item_id: tarifa_id, commission_type: c.commission_type, commission_value: Number(c.commission_value) || 0, enabled: c.enabled };
    if (c.id) {
      const { error } = await supabase.from("doctor_commissions").update(payload).eq("id", c.id);
      if (error) return toast.error(error.message);
    } else {
      const { data: ins, error } = await supabase.from("doctor_commissions").insert(payload).select().single();
      if (error) return toast.error(error.message);
      setCommissions((p) => p.map((x) => x.tarifario_item_id === tarifa_id ? (ins as Commission) : x));
    }
    toast.success("Comisión guardada");
  };

  const defaultComm = getComm(null);

  const calcCommissionFor = (item: { code: string; name: string; price: number }): { applies: boolean; amount: number } => {
    const tarifa = tarifas.find((t) => t.code === item.code || t.name === item.name);
    const rule = tarifa ? commissions.find((c) => c.tarifario_item_id === tarifa.id) : undefined;
    const eff = rule ?? (defaultComm.enabled ? defaultComm : null);
    if (!eff || !eff.enabled) return { applies: false, amount: 0 };
    const amount = eff.commission_type === "percent" ? Number(item.price) * Number(eff.commission_value) / 100 : Number(eff.commission_value);
    return { applies: true, amount };
  };

  const filteredRegs = useMemo(() => {
    if (dateMode === "all") return regs;
    let from: Date | null = null;
    let to: Date | null = null;
    if (dateMode === "month" && monthValue) {
      const [y, m] = monthValue.split("-").map(Number);
      from = new Date(y, m - 1, 1);
      to = new Date(y, m, 1);
    } else if (dateMode === "range") {
      if (dateFrom) from = new Date(dateFrom + "T00:00:00");
      if (dateTo) { const t = new Date(dateTo + "T00:00:00"); t.setDate(t.getDate() + 1); to = t; }
    }
    return regs.filter((r) => {
      const d = new Date(r.created_at);
      if (from && d < from) return false;
      if (to && d >= to) return false;
      return true;
    });
  }, [regs, dateMode, monthValue, dateFrom, dateTo]);

  const rows = useMemo(() => {
    const out: { fecha: string; paciente: string; ticket: string; estudio: string; monto: number; aplica: boolean; comision: number }[] = [];
    for (const r of filteredRegs) {
      const its = Array.isArray(r.items) ? r.items : [];
      for (const it of its) {
        const { applies, amount } = calcCommissionFor(it);
        out.push({
          fecha: new Date(r.created_at).toLocaleDateString("es-PE"),
          paciente: `${r.first_names} ${r.last_names}`,
          ticket: r.ticket_code,
          estudio: it.name ?? it.code ?? "",
          monto: Number(it.price) || 0,
          aplica: applies,
          comision: amount,
        });
      }
    }
    return out;
  }, [filteredRegs, commissions, tarifas]);

  const totalComision = rows.reduce((a, b) => a + b.comision, 0);
  const totalMontos = rows.reduce((a, b) => a + b.monto, 0);

  const exportExcel = () => {
    const sheetData = rows.map((r) => ({
      Fecha: r.fecha, Ticket: r.ticket, Paciente: r.paciente, Estudio: r.estudio,
      "Monto pagado (S/.)": r.monto, "Aplica comisión": r.aplica ? "SÍ" : "NO", "Comisión (S/.)": r.comision,
    }));
    sheetData.push({ Fecha: "", Ticket: "", Paciente: "", Estudio: "TOTAL", "Monto pagado (S/.)": totalMontos, "Aplica comisión": "", "Comisión (S/.)": totalComision } as any);
    const ws = XLSX.utils.json_to_sheet(sheetData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Comisiones");
    const meta = XLSX.utils.aoa_to_sheet([
      ["Doctor", doctor.full_name], ["Especialidad", doctor.specialty ?? ""], ["Teléfono", doctor.phone ?? ""],
      ["Email", doctor.email ?? ""], ["Total pacientes", new Set(regs.map((r) => r.id)).size], ["Total estudios", rows.length],
      ["Monto total estudios (S/.)", totalMontos], ["Comisión total (S/.)", totalComision],
    ]);
    XLSX.utils.book_append_sheet(wb, meta, "Resumen");
    XLSX.writeFile(wb, `Comisiones_${doctor.full_name.replace(/\s+/g, "_")}.xlsx`);
  };

  return (
    <div className="space-y-3">
      <Tabs defaultValue="data">
        <TabsList>
          <TabsTrigger value="data">Datos</TabsTrigger>
          <TabsTrigger value="comm">Comisiones</TabsTrigger>
          <TabsTrigger value="patients">Pacientes ({regs.length})</TabsTrigger>
          <TabsTrigger value="commercial"><Briefcase className="h-3.5 w-3.5 mr-1" />Área comercial</TabsTrigger>
        </TabsList>

        <TabsContent value="data" className="space-y-3 pt-3">
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Nombre completo</Label><Input value={data.full_name} onChange={(e) => setData({ ...data, full_name: e.target.value.toUpperCase() })} /></div>
            <div><Label>Especialidad</Label><Input value={data.specialty ?? ""} onChange={(e) => setData({ ...data, specialty: e.target.value })} /></div>
            <div><Label>COP</Label><Input value={data.cop ?? ""} onChange={(e) => setData({ ...data, cop: e.target.value })} /></div>
            <div><Label>Distrito</Label><Input value={data.district ?? ""} onChange={(e) => setData({ ...data, district: e.target.value })} /></div>
            <div><Label>Teléfono</Label><Input value={data.phone ?? ""} onChange={(e) => setData({ ...data, phone: e.target.value })} /></div>
            <div><Label>Email</Label><Input value={data.email ?? ""} onChange={(e) => setData({ ...data, email: e.target.value })} /></div>
            <div className="col-span-2"><Label>Notas</Label><Input value={data.notes ?? ""} onChange={(e) => setData({ ...data, notes: e.target.value })} /></div>
          </div>
          <Button onClick={saveDoctor}><Save className="h-4 w-4 mr-1" /> Guardar datos</Button>
        </TabsContent>

        <TabsContent value="commercial" className="pt-3">
          <CommercialArea doctor={doctor} regs={regs} onUpdated={onUpdated} initialStatus={data.status ?? "nuevo"} onStatusChange={(s) => setData({ ...data, status: s })} />
        </TabsContent>


        <TabsContent value="comm" className="space-y-3 pt-3">
          <div className="rounded-lg border border-primary/40 p-3 bg-primary/5">
            <div className="text-xs font-semibold text-primary mb-1">Comisión por defecto (aplica a todos los estudios sin regla específica)</div>
            <CommissionRow c={defaultComm} onChange={(p) => updateLocal(null, p)} onSave={() => saveComm(null)} />
          </div>
          <div className="max-h-[420px] overflow-auto space-y-1">
            {tarifas.map((t) => {
              const c = getComm(t.id);
              return (
                <div key={t.id} className="rounded-lg border border-border p-2">
                  <div className="text-xs font-mono text-muted-foreground">{t.code} · S/ {Number(t.price).toFixed(2)}</div>
                  <div className="text-sm truncate mb-1">{t.name}</div>
                  <CommissionRow c={c} onChange={(p) => updateLocal(t.id, p)} onSave={() => saveComm(t.id)} />
                </div>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="patients" className="space-y-3 pt-3">
          <div className="flex items-end gap-2 flex-wrap rounded-lg border border-border p-2 bg-muted/30">
            <div className="flex items-center gap-1">
              <CalendarDays className="h-4 w-4 text-primary" />
              <span className="text-xs font-semibold">Filtrar:</span>
            </div>
            <Select value={dateMode} onValueChange={(v) => setDateMode(v as any)}>
              <SelectTrigger className="w-36 h-8 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todo el historial</SelectItem>
                <SelectItem value="month">Por mes</SelectItem>
                <SelectItem value="range">Rango de fechas</SelectItem>
              </SelectContent>
            </Select>
            {dateMode === "month" && (
              <Input type="month" value={monthValue} onChange={(e) => setMonthValue(e.target.value)} className="w-40 h-8 text-xs" />
            )}
            {dateMode === "range" && (
              <>
                <div className="flex items-center gap-1"><Label className="text-xs">Desde</Label><Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="w-36 h-8 text-xs" /></div>
                <div className="flex items-center gap-1"><Label className="text-xs">Hasta</Label><Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="w-36 h-8 text-xs" /></div>
              </>
            )}
          </div>
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">{rows.length} estudios · Total comisión: <strong className="text-primary">S/ {totalComision.toFixed(2)}</strong></div>
            <Button onClick={exportExcel} variant="outline"><FileSpreadsheet className="h-4 w-4 mr-1" /> Exportar Excel</Button>
          </div>
          <div className="overflow-auto max-h-[500px] border rounded-lg">
            <table className="w-full text-xs">
              <thead className="bg-muted sticky top-0">
                <tr className="text-left">
                  <th className="p-2">Fecha</th><th className="p-2">Talón</th><th className="p-2">Paciente</th><th className="p-2">Estudio</th>
                  <th className="p-2 text-right">Monto</th><th className="p-2 text-center">Comisión</th><th className="p-2 text-right">Importe</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r, i) => (
                  <tr key={i} className="border-t">
                    <td className="p-2 whitespace-nowrap">{r.fecha}</td>
                    <td className="p-2 font-mono text-[11px] whitespace-nowrap">{r.ticket}</td>
                    <td className="p-2">{r.paciente}</td>
                    <td className="p-2 truncate max-w-[200px]">{r.estudio}</td>
                    <td className="p-2 text-right">S/ {r.monto.toFixed(2)}</td>
                    <td className="p-2 text-center">{r.aplica ? "✓" : "—"}</td>
                    <td className="p-2 text-right font-medium">{r.aplica ? `S/ ${r.comision.toFixed(2)}` : "-"}</td>
                  </tr>
                ))}
                {rows.length === 0 && <tr><td colSpan={7} className="p-4 text-center text-muted-foreground">Sin pacientes registrados.</td></tr>}
              </tbody>
            </table>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

const CommissionRow = ({ c, onChange, onSave }: { c: Commission; onChange: (p: Partial<Commission>) => void; onSave: () => void }) => (
  <div className="flex items-center gap-2 flex-wrap">
    <div className="flex items-center gap-1">
      <Switch checked={c.enabled} onCheckedChange={(v) => onChange({ enabled: v })} />
      <span className="text-xs">{c.enabled ? "Activado" : "Desactivado"}</span>
    </div>
    <Select value={c.commission_type} onValueChange={(v) => onChange({ commission_type: v as any })}>
      <SelectTrigger className="w-28 h-8"><SelectValue /></SelectTrigger>
      <SelectContent>
        <SelectItem value="percent">% Porcentaje</SelectItem>
        <SelectItem value="fixed">S/. Fijo</SelectItem>
      </SelectContent>
    </Select>
    <Input type="number" value={c.commission_value} onChange={(e) => onChange({ commission_value: Number(e.target.value) || 0 })} className="w-24 h-8" />
    <Button size="sm" variant="outline" onClick={onSave}><Save className="h-3.5 w-3.5 mr-1" /> Guardar</Button>
  </div>
);

const CommercialArea = ({ doctor, regs, onUpdated, initialStatus, onStatusChange }: { doctor: Doctor; regs: Reg[]; onUpdated: (d: Doctor) => void; initialStatus: string; onStatusChange: (s: string) => void }) => {
  const [status, setStatus] = useState(initialStatus);
  const [deliveries, setDeliveries] = useState<Delivery[]>([]);
  const [qty, setQty] = useState<number>(1);
  const [date, setDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      const { data } = await supabase
        .from("doctor_order_deliveries")
        .select("id,doctor_name,delivery_date,quantity,notes")
        .eq("doctor_id", doctor.id)
        .order("delivery_date", { ascending: false });
      setDeliveries((data as Delivery[]) ?? []);
      setLoading(false);
    })();
  }, [doctor.id]);

  const saveStatus = async (newStatus: string) => {
    setStatus(newStatus);
    onStatusChange(newStatus);
    const { error } = await supabase.from("doctors_directory").update({ status: newStatus } as any).eq("id", doctor.id);
    if (error) toast.error(error.message);
    else { onUpdated({ ...doctor, status: newStatus }); toast.success("Estado actualizado"); }
  };

  const addDelivery = async () => {
    if (!qty || qty <= 0) return toast.error("Cantidad debe ser mayor a 0");
    const { data: { user } } = await supabase.auth.getUser();
    const { data, error } = await supabase.from("doctor_order_deliveries").insert({
      doctor_id: doctor.id, doctor_name: doctor.full_name, delivery_date: date,
      quantity: qty, notes: note.trim() || null, created_by: user?.id ?? null,
    }).select("id,doctor_name,delivery_date,quantity,notes").single();
    if (error) return toast.error(error.message);
    setDeliveries((p) => [data as Delivery, ...p]);
    setQty(1); setNote("");
    toast.success("Entrega registrada");
  };

  const removeDelivery = async (id: string) => {
    if (!confirm("¿Eliminar esta entrega?")) return;
    await supabase.from("doctor_order_deliveries").delete().eq("id", id);
    setDeliveries((p) => p.filter((d) => d.id !== id));
  };

  const totalOrders = deliveries.reduce((a, b) => a + (b.quantity || 0), 0);

  const monthly = useMemo(() => {
    const map = new Map<string, number>();
    for (const r of regs) {
      const d = new Date(r.created_at);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      map.set(key, (map.get(key) ?? 0) + 1);
    }
    return Array.from(map.entries()).sort((a, b) => a[0].localeCompare(b[0])).map(([mes, pacientes]) => ({ mes, pacientes }));
  }, [regs]);

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-primary/30 bg-primary/5 p-3">
        <Label className="text-xs font-semibold text-primary">Tipo de doctor</Label>
        <Select value={status} onValueChange={saveStatus}>
          <SelectTrigger className="mt-1 w-48"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="nuevo">🆕 Nuevo</SelectItem>
            <SelectItem value="continuador">🔁 Continuador</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-lg border border-border p-3">
        <h4 className="text-sm font-semibold flex items-center gap-1 mb-2"><PackageCheck className="h-4 w-4 text-primary" /> Entregas de órdenes</h4>
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 mb-2">
          <div><Label className="text-xs">Fecha</Label><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></div>
          <div><Label className="text-xs">Cantidad</Label><Input type="number" min={1} value={qty} onChange={(e) => setQty(Number(e.target.value) || 0)} /></div>
          <div className="sm:col-span-2"><Label className="text-xs">Notas</Label><Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Opcional" /></div>
        </div>
        <Button size="sm" onClick={addDelivery}><Plus className="h-3.5 w-3.5 mr-1" /> Registrar entrega</Button>
        <div className="text-xs text-muted-foreground mt-2">Total entregado: <strong className="text-primary">{totalOrders} órdenes</strong> en {deliveries.length} entregas</div>

        {loading ? <div className="flex justify-center py-2"><Loader2 className="h-4 w-4 animate-spin" /></div> : (
          <div className="mt-3 max-h-56 overflow-auto border rounded">
            <table className="w-full text-xs">
              <thead className="bg-muted sticky top-0"><tr><th className="p-2 text-left">Fecha</th><th className="p-2 text-right">Cant.</th><th className="p-2 text-left">Notas</th><th className="p-2"></th></tr></thead>
              <tbody>
                {deliveries.map((d) => (
                  <tr key={d.id} className="border-t">
                    <td className="p-2 whitespace-nowrap"><CalendarDays className="h-3 w-3 inline mr-1 text-muted-foreground" />{new Date(d.delivery_date).toLocaleDateString("es-PE")}</td>
                    <td className="p-2 text-right font-medium">{d.quantity}</td>
                    <td className="p-2 text-muted-foreground truncate max-w-[180px]">{d.notes || "—"}</td>
                    <td className="p-2"><Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => removeDelivery(d.id)}><Trash2 className="h-3 w-3 text-destructive" /></Button></td>
                  </tr>
                ))}
                {deliveries.length === 0 && <tr><td colSpan={4} className="p-3 text-center text-muted-foreground">Sin entregas registradas.</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="rounded-lg border border-border p-3">
        <h4 className="text-sm font-semibold mb-2">Pacientes enviados por mes</h4>
        {monthly.length === 0 ? <p className="text-xs text-muted-foreground">Sin pacientes aún.</p> : (
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthly}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="mes" fontSize={11} />
                <YAxis fontSize={11} allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="pacientes" fill="hsl(var(--primary))" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>
    </div>
  );
};

export default DoctorsTab;

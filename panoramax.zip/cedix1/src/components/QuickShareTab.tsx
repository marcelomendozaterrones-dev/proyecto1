import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Send, Upload, Loader2, FileText, Trash2, Mail, MessageCircle, Copy, Share2, Pencil, Check, X, Search } from "lucide-react";
import { toast } from "sonner";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SEDES } from "@/data/sedes";
import { closePendingExternalTab, getPeruWhatsAppPhone, openPendingExternalTab, renderWhatsAppShareTab } from "@/lib/whatsapp";

interface UploadedStudy {
  id: string;
  file_name: string;
  file_path: string;
  study_type: string;
}

const isHeic = (f: File) =>
  /heic|heif/i.test(f.type) || /\.(heic|heif)$/i.test(f.name);

const convertHeicFile = async (f: File): Promise<File> => {
  const heic2any = (await import("heic2any")).default;
  const blob = (await heic2any({ blob: f, toType: "image/jpeg", quality: 0.88 })) as Blob | Blob[];
  const out = Array.isArray(blob) ? blob[0] : blob;
  const newName = f.name.replace(/\.(heic|heif)$/i, ".jpg");
  return new File([out], newName, { type: "image/jpeg", lastModified: Date.now() });
};

const makeSlug = () => {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = new Uint8Array(8);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("");
};

const sameSet = (a: string[], b: string[]) => {
  if (a.length !== b.length) return false;
  const sa = new Set(a); for (const x of b) if (!sa.has(x)) return false;
  return true;
};

export default function QuickShareTab() {
  const [patientName, setPatientName] = useState("");
  const [ticketCode, setTicketCode] = useState("");
  const [doctorName, setDoctorName] = useState("");
  const [sede, setSede] = useState<string>("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [studyType, setStudyType] = useState("");
  const [notes, setNotes] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [converting, setConverting] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploaded, setUploaded] = useState<UploadedStudy[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");
  const [sharing, setSharing] = useState(false);
  const [searchTicket, setSearchTicket] = useState("");
  const [searching, setSearching] = useState(false);

  const toggleSelected = (id: string) => {
    setSelected((prev) => {
      const n = new Set(prev);
      if (n.has(id)) n.delete(id); else n.add(id);
      return n;
    });
  };

  const handleFilesSelected = async (selectedFiles: File[]) => {
    if (!selectedFiles.some(isHeic)) { setFiles(selectedFiles); return; }
    setConverting(true);
    try {
      const processed = await Promise.all(selectedFiles.map((f) => (isHeic(f) ? convertHeicFile(f) : Promise.resolve(f))));
      setFiles(processed);
      toast.success("Imagen(es) HEIC convertida(s) a JPG");
    } catch (e: any) { toast.error(e.message ?? "Error convirtiendo HEIC"); }
    finally { setConverting(false); }
  };

  const loadExistingByTicket = async (code: string) => {
    if (!code.trim()) return toast.error("Ingresa un número de talón");
    setSearching(true);
    try {
      const { data: studies, error } = await supabase
        .from("studies")
        .select("id,file_name,file_path,study_type,patient_name,patient_code,sede")
        .eq("patient_code", code.trim())
        .order("created_at", { ascending: false });
      if (error) throw error;
      if (!studies || studies.length === 0) { toast.info("No se encontraron estudios para ese talón"); return; }
      // Also try to load last quick_share metadata
      const { data: qs } = await supabase
        .from("quick_shares")
        .select("patient_name,doctor_name,email,phone,study_type,notes")
        .eq("ticket_code", code.trim())
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      const first: any = studies[0];
      setTicketCode(code.trim());
      setPatientName(qs?.patient_name || first.patient_name || "");
      if (first.sede) setSede(first.sede);
      if (qs) {
        setDoctorName((qs as any).doctor_name || "");
        setEmail(qs.email || "");
        setPhone(qs.phone || "");
        setStudyType(qs.study_type || "");
        setNotes(qs.notes || "");
      }
      const items = studies.map((s: any) => ({ id: s.id, file_name: s.file_name, file_path: s.file_path, study_type: s.study_type })) as UploadedStudy[];
      setUploaded(items);
      setSelected(new Set(items.map((i) => i.id)));
      toast.success(`${items.length} estudio(s) cargado(s)`);
    } catch (e: any) { toast.error(e.message ?? "Error al buscar"); }
    finally { setSearching(false); }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName.trim()) return toast.error("Indica el nombre del paciente");
    if (!ticketCode.trim()) return toast.error("Indica el número de talón");
    if (!studyType.trim()) return toast.error("Indica el tipo de estudio");
    if (files.length === 0) return toast.error("Selecciona al menos un archivo");

    setUploading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const code = ticketCode.trim();
      const newUploads: UploadedStudy[] = [];
      for (const f of files) {
        const ext = f.name.split(".").pop();
        const key = `${code}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;

        // 1) Get presigned PUT URL from R2
        const { data: signed, error: signErr } = await supabase.functions.invoke("r2-sign-upload", {
          body: { key, content_type: f.type || "application/octet-stream" },
        });
        if (signErr) throw signErr;
        if ((signed as any)?.error) throw new Error((signed as any).error);

        // 2) Upload file directly to Cloudflare R2
        const putRes = await fetch((signed as any).url, {
          method: "PUT",
          headers: f.type ? { "Content-Type": f.type } : undefined,
          body: f,
        });
        if (!putRes.ok) throw new Error(`Error subiendo a R2 (${putRes.status})`);

        // 3) Save record in DB
        const { data: ins, error: insErr } = await supabase.from("studies").insert({
          patient_name: patientName.trim(),
          patient_code: code,
          birth_date: "2000-01-01",
          study_type: studyType.trim(),
          notes: notes.trim() || null,
          file_path: key,
          file_name: f.name,
          referring_doctor: doctorName.trim() || null,
          sede: sede || null,
          storage_provider: "r2",
          r2_key: key,
          created_by: user?.id ?? null,
        } as any).select("id,file_name,file_path,study_type").single();
        if (insErr) throw insErr;
        newUploads.push(ins as UploadedStudy);
      }
      setUploaded((prev) => [...newUploads, ...prev]);
      setSelected((prev) => {
        const n = new Set(prev);
        newUploads.forEach((u) => n.add(u.id));
        return n;
      });
      setFiles([]);
      const fi = document.getElementById("quick-file-input") as HTMLInputElement | null;
      if (fi) fi.value = "";
      toast.success(`${newUploads.length} archivo(s) subido(s)`);
    } catch (err: any) { toast.error(err.message ?? "Error al subir"); }
    finally { setUploading(false); }
  };

  const removeUploaded = async (s: UploadedStudy) => {
    if (!confirm(`¿Eliminar ${s.file_name}?`)) return;
    await supabase.storage.from("studies").remove([s.file_path]);
    await supabase.from("studies").delete().eq("id", s.id);
    setUploaded((prev) => prev.filter((x) => x.id !== s.id));
    setSelected((prev) => { const n = new Set(prev); n.delete(s.id); return n; });
  };

  const startEdit = (s: UploadedStudy) => { setEditingId(s.id); setEditValue(s.study_type || ""); };
  const cancelEdit = () => { setEditingId(null); setEditValue(""); };
  const saveEdit = async (s: UploadedStudy) => {
    const v = editValue.trim();
    if (!v) return toast.error("El nombre no puede estar vacío");
    const { error } = await supabase.from("studies").update({ study_type: v }).eq("id", s.id);
    if (error) return toast.error(error.message);
    setUploaded((prev) => prev.map((x) => x.id === s.id ? { ...x, study_type: v } : x));
    cancelEdit();
    toast.success("Nombre actualizado");
  };

  const getSelectedStudies = () => uploaded.filter((u) => selected.has(u.id));

  // Reusable share: if a non-expired share exists for same ticket+studies, reuse it (don't restart 30 days)
  const buildShareLink = async (): Promise<{ url: string; daysLeft: number } | null> => {
    const sel = getSelectedStudies();
    if (sel.length === 0) { toast.error("Selecciona al menos un estudio para enviar"); return null; }
    setSharing(true);
    try {
      const code = ticketCode.trim();
      const selIds = sel.map((u) => u.id);

      // Search for existing valid share for this ticket
      const { data: existing } = await supabase
        .from("study_shares")
        .select("slug,study_ids,expires_at")
        .eq("patient_code", code)
        .gt("expires_at", new Date().toISOString())
        .order("created_at", { ascending: false });

      let slug: string | null = null;
      let expiresAt: string | null = null;

      if (existing && existing.length > 0) {
        const match = existing.find((s: any) => sameSet((s.study_ids as string[]) ?? [], selIds));
        if (match) { slug = (match as any).slug; expiresAt = (match as any).expires_at; }
      }

      if (!slug) {
        slug = makeSlug();
        expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
        const { data: { user } } = await supabase.auth.getUser();
        const { error } = await supabase.from("study_shares").insert({
          slug,
          patient_code: code,
          patient_name: patientName.trim(),
          doctor_name: doctorName.trim() || null,
          study_ids: selIds,
          expires_at: expiresAt,
        });
        if (error) { toast.error(error.message); return null; }
        await supabase.from("quick_shares").insert({
          patient_name: patientName.trim(),
          ticket_code: code,
          email: email.trim() || null,
          phone: phone.trim() || null,
          study_type: studyType.trim() || null,
          notes: notes.trim() || null,
          study_ids: selIds,
          share_slug: slug,
          doctor_name: doctorName.trim() || null,
          share_expires_at: expiresAt,
          created_by: user?.id ?? null,
        } as any);
      }

      const daysLeft = Math.max(0, Math.ceil((new Date(expiresAt!).getTime() - Date.now()) / (24 * 60 * 60 * 1000)));
      return { url: `https://panoramax3d.app/v/${slug}`, daysLeft };
    } finally { setSharing(false); }
  };

  const buildMessage = (url: string, daysLeft: number) => {
    const sel = getSelectedStudies();
    const names = Array.from(new Set(sel.map((u) => (u.study_type || u.file_name || "").toUpperCase()).filter(Boolean)));
    let studiesText = "";
    if (names.length === 1) studiesText = names[0];
    else if (names.length === 2) studiesText = `${names[0]} Y ${names[1]}`;
    else if (names.length > 2) studiesText = `${names.slice(0, -1).join(", ")} Y ${names[names.length - 1]}`;
    const sedeName = SEDES.find((s) => s.id === sede)?.name || "";
    return (
      `BUEN DÍA 😊✨\n\n` +
      `*LE SALUDAMOS, DE PANORAMAX 3D ☢☢ ${sedeName ? sedeName.toUpperCase() : "SAN JUAN DE LURIGANCHO"} ☢☢*\n\n` +
      (doctorName.trim() ? `Doctor(a) *${doctorName.trim()}*,\n` : "") +
      `Le enviamos de manera virtual 📲 el/los estudio(s) del paciente *${patientName.trim()}* (Talón ${ticketCode.trim()}):\n\n` +
      (studiesText ? `🦷 ${studiesText}\n\n` : "") +
      `🔗 Ver/Descargar: ${url}\n` +
      `(Enlace válido por ${daysLeft} día${daysLeft !== 1 ? "s" : ""} más)\n\n` +
      `GRACIAS POR CONFIAR EN NOSOTROS 🤗 — PANORAMAX 3D`
    );
  };

  const shareWhatsApp = async () => {
    const pendingTab = openPendingExternalTab();
    const r = await buildShareLink();
    if (!r) { closePendingExternalTab(pendingTab); return; }
    const msg = buildMessage(r.url, r.daysLeft);
    try {
      await navigator.clipboard.writeText(msg);
      toast.success("Mensaje copiado; se abrirá WhatsApp");
    } catch {
      window.prompt("Mensaje de WhatsApp:", msg);
    }
    renderWhatsAppShareTab(pendingTab, { phone: getPeruWhatsAppPhone(phone), message: msg });
  };

  const shareEmail = async () => {
    const recipient = (email.trim() || window.prompt("Correo del destinatario:", "") || "").trim();
    if (!recipient) return;
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(recipient)) { toast.error("Correo inválido"); return; }
    const r = await buildShareLink();
    if (!r) return;
    const sel = getSelectedStudies();
    const studyNames = Array.from(new Set(
      sel.map((u) => (u.study_type || u.file_name || "").toUpperCase()).filter(Boolean)
    ));
    const sedeName = SEDES.find((s) => s.id === sede)?.name || "PANORAMAX 3D";
    toast.loading("Enviando correo…", { id: "qs-email" });
    const { error } = await supabase.functions.invoke("send-transactional-email", {
      body: {
        templateName: "study-share",
        recipientEmail: recipient,
        idempotencyKey: `quick-share-${r.url.split("/").pop()}-${recipient}`,
        templateData: {
          recipientName: doctorName.trim() || patientName.trim(),
          patientName: patientName.trim(),
          ticketCode: ticketCode.trim(),
          studies: studyNames,
          shareUrl: r.url,
          daysValid: r.daysLeft,
          sedeName,
          isDoctor: !!doctorName.trim(),
        },
      },
    });
    toast.dismiss("qs-email");
    if (error) { toast.error("No se pudo enviar: " + error.message); return; }
    toast.success(`Correo enviado a ${recipient}`);
  };

  const copyLink = async () => {
    const r = await buildShareLink();
    if (!r) return;
    try {
      await navigator.clipboard.writeText(buildMessage(r.url, r.daysLeft));
      toast.success(`Copiado. Enlace vigente ${r.daysLeft} día(s) más`);
    } catch { toast.info(r.url); }
  };

  const resetAll = () => {
    if (!confirm("¿Limpiar todo el formulario? Los archivos ya subidos permanecerán en la base de datos.")) return;
    setPatientName(""); setTicketCode(""); setDoctorName(""); setEmail(""); setPhone("");
    setStudyType(""); setNotes(""); setFiles([]); setUploaded([]); setSelected(new Set()); setSede("");
    const fi = document.getElementById("quick-file-input") as HTMLInputElement | null;
    if (fi) fi.value = "";
  };

  const allSelected = uploaded.length > 0 && selected.size === uploaded.length;
  const toggleAll = () => {
    if (allSelected) setSelected(new Set());
    else setSelected(new Set(uploaded.map((u) => u.id)));
  };

  return (
    <div className="space-y-6">
      <Card className="p-6 shadow-soft">
        <h2 className="text-xl font-bold mb-1 flex items-center gap-2">
          <Send className="h-5 w-5 text-primary" /> Envíos rápidos
        </h2>
        <p className="text-sm text-muted-foreground mb-4">
          Sube estudios y compártelos sin necesidad de registrar al paciente. Los estudios se guardan y puedes recuperarlos buscando por talón.
        </p>

        <div className="mb-4 rounded-lg border border-primary/30 bg-primary/5 p-3">
          <Label className="text-xs font-semibold text-primary">Buscar talón existente</Label>
          <div className="flex gap-2 mt-1">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input className="pl-8" value={searchTicket} onChange={(e) => setSearchTicket(e.target.value)} placeholder="Ej. 12345" onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); loadExistingByTicket(searchTicket); } }} />
            </div>
            <Button type="button" onClick={() => loadExistingByTicket(searchTicket)} disabled={searching} variant="outline">
              {searching ? <Loader2 className="h-4 w-4 animate-spin" /> : "Cargar"}
            </Button>
          </div>
        </div>

        <form onSubmit={handleUpload} className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-3">
            <div>
              <Label>Nombre del paciente *</Label>
              <Input value={patientName} onChange={(e) => setPatientName(e.target.value)} placeholder="Apellidos y nombres" />
            </div>
            <div>
              <Label>Número de talón *</Label>
              <Input value={ticketCode} onChange={(e) => setTicketCode(e.target.value)} placeholder="Ej. 12345" />
            </div>
            <div className="sm:col-span-2">
              <Label>Sede del envío *</Label>
              <Select value={sede} onValueChange={setSede}>
                <SelectTrigger><SelectValue placeholder="Selecciona la sede" /></SelectTrigger>
                <SelectContent>
                  {SEDES.map((s) => (
                    <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="sm:col-span-2">
              <Label>Nombre del doctor</Label>
              <Input value={doctorName} onChange={(e) => setDoctorName(e.target.value.toUpperCase())} placeholder="Doctor que recibirá los estudios" />
            </div>
            <div>
              <Label>Correo destinatario</Label>
              <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="doctor@ejemplo.com" />
            </div>
            <div>
              <Label>WhatsApp destinatario</Label>
              <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="9XX XXX XXX" />
            </div>
            <div className="sm:col-span-2">
              <Label>Tipo de estudio *</Label>
              <Input value={studyType} onChange={(e) => setStudyType(e.target.value)} placeholder="Ej. RX PANORÁMICA" />
            </div>
            <div className="sm:col-span-2">
              <Label>Notas</Label>
              <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} />
            </div>
            <div className="sm:col-span-2">
              <Label>Archivos *</Label>
              <Input id="quick-file-input" type="file" multiple accept="image/*,.pdf,.heic,.heif" onChange={(e) => handleFilesSelected(Array.from(e.target.files ?? []))} />
              {converting && <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1"><Loader2 className="h-3 w-3 animate-spin" /> Convirtiendo HEIC…</p>}
              {files.length > 0 && <p className="text-xs text-muted-foreground mt-1">{files.length} archivo(s) listo(s)</p>}
            </div>
          </div>

          <div className="flex gap-2 flex-wrap">
            <Button type="submit" disabled={uploading || converting} className="bg-gradient-hero">
              {uploading ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Upload className="h-4 w-4 mr-1" />}
              Subir estudios
            </Button>
            <Button type="button" variant="outline" onClick={resetAll}>Limpiar</Button>
          </div>
        </form>
      </Card>

      {uploaded.length > 0 && (
        <Card className="p-6 shadow-soft">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-lg flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" /> Estudios subidos ({uploaded.length})
            </h3>
            <button type="button" onClick={toggleAll} className="text-xs text-primary hover:underline">
              {allSelected ? "Deseleccionar todos" : "Seleccionar todos"}
            </button>
          </div>
          <p className="text-xs text-muted-foreground mb-2">
            Marca los estudios que quieres enviar y edita el nombre con el lápiz si lo necesitas.
          </p>
          <div className="space-y-2 mb-4">
            {uploaded.map((u) => (
              <div key={u.id} className="flex items-center gap-2 p-2 rounded border border-border bg-background">
                <Checkbox checked={selected.has(u.id)} onCheckedChange={() => toggleSelected(u.id)} />
                <div className="min-w-0 flex-1">
                  {editingId === u.id ? (
                    <div className="flex items-center gap-1">
                      <Input value={editValue} onChange={(e) => setEditValue(e.target.value)} autoFocus className="h-8"
                        onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); saveEdit(u); } if (e.key === "Escape") cancelEdit(); }} />
                      <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => saveEdit(u)}><Check className="h-4 w-4 text-primary" /></Button>
                      <Button size="icon" variant="ghost" className="h-8 w-8" onClick={cancelEdit}><X className="h-4 w-4" /></Button>
                    </div>
                  ) : (
                    <>
                      <div className="text-sm font-medium truncate">{u.study_type}</div>
                      <div className="text-xs text-muted-foreground truncate">{u.file_name}</div>
                    </>
                  )}
                </div>
                {editingId !== u.id && (
                  <Button size="icon" variant="ghost" onClick={() => startEdit(u)} title="Editar nombre"><Pencil className="h-4 w-4" /></Button>
                )}
                <Button size="icon" variant="ghost" onClick={() => removeUploaded(u)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
              </div>
            ))}
          </div>

          <div className="border-t border-border pt-4">
            <h4 className="font-semibold text-sm mb-2 flex items-center gap-1">
              <Share2 className="h-4 w-4" /> Compartir ({selected.size} seleccionado{selected.size !== 1 ? "s" : ""})
            </h4>
            <p className="text-xs text-muted-foreground mb-2">Los enlaces duran 30 días desde el primer envío. Si compartes el mismo talón de nuevo, se reutiliza el enlace existente (no se reinicia el plazo).</p>
            <div className="flex gap-2 flex-wrap">
              <Button onClick={shareWhatsApp} disabled={sharing || selected.size === 0} className="bg-[#25D366] hover:bg-[#25D366]/90 text-white">
                <MessageCircle className="h-4 w-4 mr-1" /> WhatsApp
              </Button>
              <Button onClick={shareEmail} disabled={sharing || selected.size === 0} variant="outline">
                <Mail className="h-4 w-4 mr-1" /> Correo
              </Button>
              <Button onClick={copyLink} disabled={sharing || selected.size === 0} variant="outline">
                <Copy className="h-4 w-4 mr-1" /> Copiar enlace
              </Button>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}

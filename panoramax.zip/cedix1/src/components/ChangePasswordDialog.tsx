import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { KeyRound, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const ChangePasswordDialog = () => {
  const [open, setOpen] = useState(false);
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    if (next.length < 6) return toast.error("La nueva contraseña debe tener mínimo 6 caracteres");
    if (next !== confirm) return toast.error("Las contraseñas no coinciden");
    setLoading(true);
    try {
      const { data: u } = await supabase.auth.getUser();
      const email = u.user?.email;
      if (!email) throw new Error("Sesión no válida");
      const { error: e1 } = await supabase.auth.signInWithPassword({ email, password: current });
      if (e1) throw new Error("Contraseña actual incorrecta");
      const { error: e2 } = await supabase.auth.updateUser({ password: next });
      if (e2) throw e2;
      toast.success("Contraseña actualizada");
      setCurrent(""); setNext(""); setConfirm(""); setOpen(false);
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm"><KeyRound className="h-4 w-4 mr-1" /> Cambiar contraseña</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader><DialogTitle>Cambiar contraseña</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>Contraseña actual</Label><Input type="password" value={current} onChange={(e) => setCurrent(e.target.value)} /></div>
          <div><Label>Nueva contraseña</Label><Input type="password" value={next} onChange={(e) => setNext(e.target.value)} /></div>
          <div><Label>Confirmar nueva</Label><Input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} /></div>
        </div>
        <DialogFooter>
          <Button onClick={submit} disabled={loading}>
            {loading && <Loader2 className="h-4 w-4 animate-spin mr-2" />}Actualizar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ChangePasswordDialog;

/**
 * PageBackground
 * Wrapper que aplica el fondo de clínica dental desenfocado + overlay blanco
 * a cualquier página. Uso:
 *   <PageBackground>  ...contenido...  </PageBackground>
 */
import dentalBg from "@/assets/dental-bg.png";

interface PageBackgroundProps {
  children: React.ReactNode;
  className?: string;
  overlayOpacity?: number; // 0-1, default 0.85
  blurPx?: number;          // px, default 6
}

export const PageBackground = ({
  children,
  className = "",
  overlayOpacity = 0.85,
  blurPx = 6,
}: PageBackgroundProps) => (
  <div
    className={`min-h-screen relative ${className}`}
    style={{
      backgroundImage: `url(${dentalBg})`,
      backgroundSize: "cover",
      backgroundPosition: "center",
      backgroundAttachment: "fixed",
    }}
  >
    {/* Blur + white overlay */}
    <div
      className="absolute inset-0 pointer-events-none"
      style={{
        backdropFilter: `blur(${blurPx}px)`,
        WebkitBackdropFilter: `blur(${blurPx}px)`,
        background: `rgba(255, 255, 255, ${overlayOpacity})`,
      }}
    />
    {/* Content */}
    <div className="relative z-10 flex flex-col min-h-screen">
      {children}
    </div>
  </div>
);

export default PageBackground;

import logo from "@/assets/panoramax-logo.jpg";

interface BrandLogoProps {
  className?: string;
  style?: React.CSSProperties;
}

export const BrandLogo = ({ className = "h-12 w-auto", style }: BrandLogoProps) => (
  <img
    src={logo}
    alt="Panoramax 3D - Tomografía y Radiología Odontológica"
    className={className}
    style={style}
  />
);

export default BrandLogo;

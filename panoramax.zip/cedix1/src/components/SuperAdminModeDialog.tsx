import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Shield, Wrench } from "lucide-react";

export const SuperAdminModeDialog = ({
  open,
  onChoose,
}: {
  open: boolean;
  onChoose: (mode: "admin" | "editor") => void;
}) => {
  return (
    <Dialog open={open}>
      <DialogContent className="sm:max-w-md" onPointerDownOutside={(e) => e.preventDefault()} onEscapeKeyDown={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle className="text-center">¿Cómo deseas ingresar?</DialogTitle>
          <DialogDescription className="text-center">Selecciona el tipo de acceso para esta sesión.</DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          <Button variant="outline" className="h-28 flex-col gap-2" onClick={() => onChoose("admin")}>
            <Shield className="h-6 w-6 text-primary" />
            <span className="font-semibold">Administrador</span>
            <span className="text-xs text-muted-foreground">Vista normal</span>
          </Button>
          <Button className="h-28 flex-col gap-2 bg-gradient-hero" onClick={() => onChoose("editor")}>
            <Wrench className="h-6 w-6" />
            <span className="font-semibold">Editor libre</span>
            <span className="text-xs opacity-90">Editar catálogo, talones y más</span>
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default SuperAdminModeDialog;

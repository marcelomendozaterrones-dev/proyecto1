export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      app_passwords: {
        Row: {
          description: string | null
          key: string
          label: string
          updated_at: string
          value: string
        }
        Insert: {
          description?: string | null
          key: string
          label: string
          updated_at?: string
          value: string
        }
        Update: {
          description?: string | null
          key?: string
          label?: string
          updated_at?: string
          value?: string
        }
        Relationships: []
      }
      cancel_doctors: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          name: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          name: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          name?: string
        }
        Relationships: []
      }
      custom_doctors: {
        Row: {
          cop: string | null
          created_at: string
          created_by: string | null
          email: string | null
          full_name: string
          id: string
          phone: string | null
          specialty: string | null
        }
        Insert: {
          cop?: string | null
          created_at?: string
          created_by?: string | null
          email?: string | null
          full_name: string
          id?: string
          phone?: string | null
          specialty?: string | null
        }
        Update: {
          cop?: string | null
          created_at?: string
          created_by?: string | null
          email?: string | null
          full_name?: string
          id?: string
          phone?: string | null
          specialty?: string | null
        }
        Relationships: []
      }
      doctor_accounts: {
        Row: {
          cop: string | null
          created_at: string
          email: string | null
          full_name: string
          id: string
          must_change_password: boolean
          phone: string | null
          pwd_hash: string
          pwd_salt: string
          session_expires_at: string | null
          session_token_hash: string | null
          specialty: string | null
          updated_at: string
        }
        Insert: {
          cop?: string | null
          created_at?: string
          email?: string | null
          full_name: string
          id?: string
          must_change_password?: boolean
          phone?: string | null
          pwd_hash: string
          pwd_salt: string
          session_expires_at?: string | null
          session_token_hash?: string | null
          specialty?: string | null
          updated_at?: string
        }
        Update: {
          cop?: string | null
          created_at?: string
          email?: string | null
          full_name?: string
          id?: string
          must_change_password?: boolean
          phone?: string | null
          pwd_hash?: string
          pwd_salt?: string
          session_expires_at?: string | null
          session_token_hash?: string | null
          specialty?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      doctor_commissions: {
        Row: {
          commission_type: string
          commission_value: number
          created_at: string
          doctor_id: string
          enabled: boolean
          id: string
          tarifario_item_id: string | null
          updated_at: string
        }
        Insert: {
          commission_type?: string
          commission_value?: number
          created_at?: string
          doctor_id: string
          enabled?: boolean
          id?: string
          tarifario_item_id?: string | null
          updated_at?: string
        }
        Update: {
          commission_type?: string
          commission_value?: number
          created_at?: string
          doctor_id?: string
          enabled?: boolean
          id?: string
          tarifario_item_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "doctor_commissions_doctor_id_fkey"
            columns: ["doctor_id"]
            isOneToOne: false
            referencedRelation: "doctors_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "doctor_commissions_tarifario_item_id_fkey"
            columns: ["tarifario_item_id"]
            isOneToOne: false
            referencedRelation: "tarifario_items"
            referencedColumns: ["id"]
          },
        ]
      }
      doctor_order_deliveries: {
        Row: {
          created_at: string
          created_by: string | null
          delivery_date: string
          doctor_id: string | null
          doctor_name: string
          id: string
          notes: string | null
          quantity: number
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          delivery_date?: string
          doctor_id?: string | null
          doctor_name: string
          id?: string
          notes?: string | null
          quantity?: number
        }
        Update: {
          created_at?: string
          created_by?: string | null
          delivery_date?: string
          doctor_id?: string | null
          doctor_name?: string
          id?: string
          notes?: string | null
          quantity?: number
        }
        Relationships: []
      }
      doctors_directory: {
        Row: {
          cop: string | null
          created_at: string
          district: string | null
          email: string | null
          full_name: string
          id: string
          notes: string | null
          phone: string | null
          specialty: string | null
          status: string
          updated_at: string
        }
        Insert: {
          cop?: string | null
          created_at?: string
          district?: string | null
          email?: string | null
          full_name: string
          id?: string
          notes?: string | null
          phone?: string | null
          specialty?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          cop?: string | null
          created_at?: string
          district?: string | null
          email?: string | null
          full_name?: string
          id?: string
          notes?: string | null
          phone?: string | null
          specialty?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      email_send_log: {
        Row: {
          created_at: string
          error_message: string | null
          id: string
          message_id: string | null
          metadata: Json | null
          recipient_email: string
          status: string
          template_name: string
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_id?: string | null
          metadata?: Json | null
          recipient_email: string
          status: string
          template_name: string
        }
        Update: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_id?: string | null
          metadata?: Json | null
          recipient_email?: string
          status?: string
          template_name?: string
        }
        Relationships: []
      }
      email_send_state: {
        Row: {
          auth_email_ttl_minutes: number
          batch_size: number
          id: number
          retry_after_until: string | null
          send_delay_ms: number
          transactional_email_ttl_minutes: number
          updated_at: string
        }
        Insert: {
          auth_email_ttl_minutes?: number
          batch_size?: number
          id?: number
          retry_after_until?: string | null
          send_delay_ms?: number
          transactional_email_ttl_minutes?: number
          updated_at?: string
        }
        Update: {
          auth_email_ttl_minutes?: number
          batch_size?: number
          id?: number
          retry_after_until?: string | null
          send_delay_ms?: number
          transactional_email_ttl_minutes?: number
          updated_at?: string
        }
        Relationships: []
      }
      email_unsubscribe_tokens: {
        Row: {
          created_at: string
          email: string
          id: string
          token: string
          used_at: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          token: string
          used_at?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          token?: string
          used_at?: string | null
        }
        Relationships: []
      }
      institution_campaigns: {
        Row: {
          active: boolean
          created_at: string
          id: string
          institution_id: string
          special_price: number
          tarifario_item_id: string
          updated_at: string
          valid_from: string | null
          valid_to: string | null
        }
        Insert: {
          active?: boolean
          created_at?: string
          id?: string
          institution_id: string
          special_price?: number
          tarifario_item_id: string
          updated_at?: string
          valid_from?: string | null
          valid_to?: string | null
        }
        Update: {
          active?: boolean
          created_at?: string
          id?: string
          institution_id?: string
          special_price?: number
          tarifario_item_id?: string
          updated_at?: string
          valid_from?: string | null
          valid_to?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "institution_campaigns_institution_id_fkey"
            columns: ["institution_id"]
            isOneToOne: false
            referencedRelation: "institutions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "institution_campaigns_tarifario_item_id_fkey"
            columns: ["tarifario_item_id"]
            isOneToOne: false
            referencedRelation: "tarifario_items"
            referencedColumns: ["id"]
          },
        ]
      }
      institutions: {
        Row: {
          contact: string | null
          created_at: string
          id: string
          name: string
          notes: string | null
          phone: string | null
          updated_at: string
        }
        Insert: {
          contact?: string | null
          created_at?: string
          id?: string
          name: string
          notes?: string | null
          phone?: string | null
          updated_at?: string
        }
        Update: {
          contact?: string | null
          created_at?: string
          id?: string
          name?: string
          notes?: string | null
          phone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      patient_registrations: {
        Row: {
          age: number | null
          birth_date: string | null
          created_at: string
          created_by: string | null
          doc_number: string | null
          doc_type: string
          doctor_name: string | null
          first_names: string
          id: string
          institution_id: string | null
          items: Json
          last_names: string
          notes: string | null
          payments: Json
          phone: string | null
          sede: string
          special_price: boolean
          special_reason: string | null
          subtotal: number
          ticket_code: string
          ticket_number: number
          total: number
        }
        Insert: {
          age?: number | null
          birth_date?: string | null
          created_at?: string
          created_by?: string | null
          doc_number?: string | null
          doc_type: string
          doctor_name?: string | null
          first_names: string
          id?: string
          institution_id?: string | null
          items?: Json
          last_names: string
          notes?: string | null
          payments?: Json
          phone?: string | null
          sede: string
          special_price?: boolean
          special_reason?: string | null
          subtotal?: number
          ticket_code: string
          ticket_number: number
          total?: number
        }
        Update: {
          age?: number | null
          birth_date?: string | null
          created_at?: string
          created_by?: string | null
          doc_number?: string | null
          doc_type?: string
          doctor_name?: string | null
          first_names?: string
          id?: string
          institution_id?: string | null
          items?: Json
          last_names?: string
          notes?: string | null
          payments?: Json
          phone?: string | null
          sede?: string
          special_price?: boolean
          special_reason?: string | null
          subtotal?: number
          ticket_code?: string
          ticket_number?: number
          total?: number
        }
        Relationships: [
          {
            foreignKeyName: "patient_registrations_institution_id_fkey"
            columns: ["institution_id"]
            isOneToOne: false
            referencedRelation: "institutions"
            referencedColumns: ["id"]
          },
        ]
      }
      quick_shares: {
        Row: {
          created_at: string
          created_by: string | null
          doctor_name: string | null
          email: string | null
          id: string
          notes: string | null
          patient_name: string
          phone: string | null
          share_expires_at: string | null
          share_slug: string | null
          study_ids: string[]
          study_type: string | null
          ticket_code: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          doctor_name?: string | null
          email?: string | null
          id?: string
          notes?: string | null
          patient_name: string
          phone?: string | null
          share_expires_at?: string | null
          share_slug?: string | null
          study_ids?: string[]
          study_type?: string | null
          ticket_code: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          doctor_name?: string | null
          email?: string | null
          id?: string
          notes?: string | null
          patient_name?: string
          phone?: string | null
          share_expires_at?: string | null
          share_slug?: string | null
          study_ids?: string[]
          study_type?: string | null
          ticket_code?: string
          updated_at?: string
        }
        Relationships: []
      }
      studies: {
        Row: {
          birth_date: string
          created_at: string
          created_by: string | null
          file_name: string
          file_path: string
          id: string
          notes: string | null
          patient_code: string
          patient_name: string
          r2_key: string | null
          referring_doctor: string | null
          sede: string | null
          storage_provider: string
          study_type: string
        }
        Insert: {
          birth_date: string
          created_at?: string
          created_by?: string | null
          file_name: string
          file_path: string
          id?: string
          notes?: string | null
          patient_code: string
          patient_name: string
          r2_key?: string | null
          referring_doctor?: string | null
          sede?: string | null
          storage_provider?: string
          study_type: string
        }
        Update: {
          birth_date?: string
          created_at?: string
          created_by?: string | null
          file_name?: string
          file_path?: string
          id?: string
          notes?: string | null
          patient_code?: string
          patient_name?: string
          r2_key?: string | null
          referring_doctor?: string | null
          sede?: string | null
          storage_provider?: string
          study_type?: string
        }
        Relationships: []
      }
      study_shares: {
        Row: {
          created_at: string
          created_by: string | null
          doctor_name: string | null
          expires_at: string
          patient_code: string
          patient_name: string
          slug: string
          study_ids: string[]
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          doctor_name?: string | null
          expires_at: string
          patient_code: string
          patient_name: string
          slug: string
          study_ids: string[]
        }
        Update: {
          created_at?: string
          created_by?: string | null
          doctor_name?: string | null
          expires_at?: string
          patient_code?: string
          patient_name?: string
          slug?: string
          study_ids?: string[]
        }
        Relationships: []
      }
      suppressed_emails: {
        Row: {
          created_at: string
          email: string
          id: string
          metadata: Json | null
          reason: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          metadata?: Json | null
          reason: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          metadata?: Json | null
          reason?: string
        }
        Relationships: []
      }
      surveys: {
        Row: {
          created_at: string
          id: string
          patient_code: string | null
          recommendations: string | null
          sede: string | null
          service_rating: number
          technician: string
          technician_observation: string | null
          technician_rating: number
        }
        Insert: {
          created_at?: string
          id?: string
          patient_code?: string | null
          recommendations?: string | null
          sede?: string | null
          service_rating: number
          technician: string
          technician_observation?: string | null
          technician_rating: number
        }
        Update: {
          created_at?: string
          id?: string
          patient_code?: string | null
          recommendations?: string | null
          sede?: string | null
          service_rating?: number
          technician?: string
          technician_observation?: string | null
          technician_rating?: number
        }
        Relationships: []
      }
      tarifario_items: {
        Row: {
          category: string
          code: string
          created_at: string
          id: string
          name: string
          price: number
          sort_order: number
          updated_at: string
        }
        Insert: {
          category?: string
          code: string
          created_at?: string
          id?: string
          name: string
          price?: number
          sort_order?: number
          updated_at?: string
        }
        Update: {
          category?: string
          code?: string
          created_at?: string
          id?: string
          name?: string
          price?: number
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      ticket_counters: {
        Row: {
          last_number: number
          sede: string
        }
        Insert: {
          last_number?: number
          sede: string
        }
        Update: {
          last_number?: number
          sede?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_sede_access: {
        Row: {
          created_at: string
          id: string
          sede: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          sede: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          sede?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      _sha256_hex: { Args: { _input: string }; Returns: string }
      admin_reset_doctor_password: {
        Args: { _doctor_id: string }
        Returns: string
      }
      claim_staff_role: {
        Args: { _master_key: string; _role: string }
        Returns: boolean
      }
      delete_email: {
        Args: { message_id: number; queue_name: string }
        Returns: boolean
      }
      doctor_all_known_names: {
        Args: never
        Returns: {
          full_name: string
        }[]
      }
      doctor_change_password: {
        Args: { _full_name: string; _new: string; _old: string }
        Returns: boolean
      }
      doctor_list_names: {
        Args: never
        Returns: {
          full_name: string
        }[]
      }
      doctor_login: {
        Args: { _full_name: string; _password: string }
        Returns: Json
      }
      doctor_patient_studies: {
        Args: { _patient_code: string; _token: string }
        Returns: {
          created_at: string
          file_name: string
          file_path: string
          id: string
          notes: string
          study_type: string
        }[]
      }
      doctor_patients: {
        Args: { _token: string }
        Returns: {
          age: number
          created_at: string
          doc_number: string
          first_names: string
          id: string
          items: Json
          last_names: string
          sede: string
          ticket_code: string
          total: number
        }[]
      }
      doctor_register:
        | {
            Args: {
              _cop: string
              _email: string
              _full_name: string
              _phone: string
              _specialty: string
            }
            Returns: Json
          }
        | {
            Args: {
              _cop: string
              _email: string
              _full_name: string
              _password: string
              _phone: string
              _specialty: string
            }
            Returns: Json
          }
      enqueue_email: {
        Args: { payload: Json; queue_name: string }
        Returns: number
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_staff: { Args: { _user_id: string }; Returns: boolean }
      list_doctor_accounts: {
        Args: never
        Returns: {
          created_at: string
          email: string
          full_name: string
          id: string
          must_change_password: boolean
          phone: string
          specialty: string
        }[]
      }
      list_staff_accounts: {
        Args: never
        Returns: {
          created_at: string
          email: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }[]
      }
      move_to_dlq: {
        Args: {
          dlq_name: string
          message_id: number
          payload: Json
          source_queue: string
        }
        Returns: number
      }
      next_ticket_number: { Args: { _sede: string }; Returns: number }
      read_email_batch: {
        Args: { batch_size: number; queue_name: string; vt: number }
        Returns: {
          message: Json
          msg_id: number
          read_ct: number
        }[]
      }
    }
    Enums: {
      app_role: "admin" | "user" | "tecnico" | "comercial"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user", "tecnico", "comercial"],
    },
  },
} as const

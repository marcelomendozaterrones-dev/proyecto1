
CREATE TABLE public.app_passwords (
  key text PRIMARY KEY,
  label text NOT NULL,
  description text,
  value text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.app_passwords ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins read passwords" ON public.app_passwords
  FOR SELECT TO authenticated USING (has_role(auth.uid(),'admin'::app_role));

CREATE POLICY "Admins insert passwords" ON public.app_passwords
  FOR INSERT TO authenticated WITH CHECK (has_role(auth.uid(),'admin'::app_role));

CREATE POLICY "Admins update passwords" ON public.app_passwords
  FOR UPDATE TO authenticated USING (has_role(auth.uid(),'admin'::app_role));

CREATE TRIGGER trg_app_passwords_updated_at
  BEFORE UPDATE ON public.app_passwords
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.app_passwords(key,label,description,value) VALUES
  ('edit_ticket_number','Editar N° de talón','Requerida en el reporte para cambiar el número de talón de un registro existente.','DEBOREGISTRARBIEN'),
  ('edit_registration_date','Editar fecha de registro','Requerida en el reporte para modificar la fecha en que se registró un paciente.','DEBOREGISTRARBIEN'),
  ('delete_registration','Eliminar registro','Requerida en el reporte para eliminar un talón/registro.','CEDIX12345'),
  ('manual_ticket','Talón manual','Requerida al registrar un paciente para ingresar el N° de talón manualmente.','NEWTALON')
ON CONFLICT (key) DO NOTHING;

create or replace function public.sync_study_birth_date_from_registration()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  _birth_date date;
begin
  if new.patient_code is not null and regexp_replace(new.patient_code, '\D', '', 'g') <> '' then
    select p.birth_date
      into _birth_date
    from public.patient_registrations p
    where p.birth_date is not null
      and regexp_replace(p.ticket_code, '\D', '', 'g') <> ''
      and regexp_replace(p.ticket_code, '\D', '', 'g')::bigint = regexp_replace(new.patient_code, '\D', '', 'g')::bigint
    order by p.created_at desc
    limit 1;

    if _birth_date is not null then
      new.birth_date := _birth_date;
    end if;
  end if;

  return new;
end;
$$;

drop trigger if exists sync_study_birth_date_from_registration_trigger on public.studies;

create trigger sync_study_birth_date_from_registration_trigger
before insert or update of patient_code, birth_date
on public.studies
for each row
execute function public.sync_study_birth_date_from_registration();
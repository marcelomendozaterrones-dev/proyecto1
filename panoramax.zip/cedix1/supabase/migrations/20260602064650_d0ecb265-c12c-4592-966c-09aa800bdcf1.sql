ALTER TABLE public.custom_doctors ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE public.custom_doctors ADD COLUMN IF NOT EXISTS cop text;
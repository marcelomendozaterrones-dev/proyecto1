
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TABLE public.doctors_directory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL UNIQUE,
  specialty text,
  phone text,
  email text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.doctors_directory ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins manage doctors_directory" ON public.doctors_directory
  FOR ALL TO authenticated USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

CREATE TABLE public.doctor_commissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  doctor_id uuid NOT NULL REFERENCES public.doctors_directory(id) ON DELETE CASCADE,
  tarifario_item_id uuid REFERENCES public.tarifario_items(id) ON DELETE CASCADE,
  commission_type text NOT NULL DEFAULT 'percent' CHECK (commission_type IN ('percent','fixed')),
  commission_value numeric NOT NULL DEFAULT 0,
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX doctor_commissions_unique ON public.doctor_commissions (doctor_id, COALESCE(tarifario_item_id, '00000000-0000-0000-0000-000000000000'::uuid));
ALTER TABLE public.doctor_commissions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins manage commissions" ON public.doctor_commissions
  FOR ALL TO authenticated USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

CREATE TABLE public.institutions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  contact text, phone text, notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.institutions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins manage institutions" ON public.institutions
  FOR ALL TO authenticated USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

CREATE TABLE public.institution_campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  institution_id uuid NOT NULL REFERENCES public.institutions(id) ON DELETE CASCADE,
  tarifario_item_id uuid NOT NULL REFERENCES public.tarifario_items(id) ON DELETE CASCADE,
  special_price numeric NOT NULL DEFAULT 0,
  valid_from date, valid_to date,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.institution_campaigns ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins manage campaigns" ON public.institution_campaigns
  FOR ALL TO authenticated USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

ALTER TABLE public.patient_registrations ADD COLUMN IF NOT EXISTS institution_id uuid REFERENCES public.institutions(id);

INSERT INTO public.doctors_directory (full_name, specialty, phone)
SELECT upper(trim(c.full_name)), c.specialty, c.phone FROM public.custom_doctors c
WHERE c.full_name IS NOT NULL AND length(trim(c.full_name)) > 0
ON CONFLICT (full_name) DO NOTHING;

INSERT INTO public.doctors_directory (full_name, specialty, phone, email)
SELECT upper(trim(d.full_name)), d.specialty, d.phone, d.email FROM public.doctor_accounts d
WHERE d.full_name IS NOT NULL AND length(trim(d.full_name)) > 0
ON CONFLICT (full_name) DO NOTHING;

INSERT INTO public.doctors_directory (full_name)
SELECT DISTINCT upper(trim(p.doctor_name)) FROM public.patient_registrations p
WHERE p.doctor_name IS NOT NULL AND length(trim(p.doctor_name)) > 0
ON CONFLICT (full_name) DO NOTHING;

CREATE TRIGGER trg_doctors_directory_updated BEFORE UPDATE ON public.doctors_directory
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_doctor_commissions_updated BEFORE UPDATE ON public.doctor_commissions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_institutions_updated BEFORE UPDATE ON public.institutions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_institution_campaigns_updated BEFORE UPDATE ON public.institution_campaigns
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

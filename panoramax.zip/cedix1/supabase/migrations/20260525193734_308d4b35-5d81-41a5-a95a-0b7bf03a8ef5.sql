CREATE TABLE public.cancel_doctors (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  created_by uuid
);

CREATE UNIQUE INDEX cancel_doctors_name_uniq ON public.cancel_doctors (upper(trim(name)));

ALTER TABLE public.cancel_doctors ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Staff view cancel doctors" ON public.cancel_doctors
  FOR SELECT TO authenticated USING (public.is_staff(auth.uid()));
CREATE POLICY "Staff insert cancel doctors" ON public.cancel_doctors
  FOR INSERT TO authenticated WITH CHECK (public.is_staff(auth.uid()));
CREATE POLICY "Staff update cancel doctors" ON public.cancel_doctors
  FOR UPDATE TO authenticated USING (public.is_staff(auth.uid()));
CREATE POLICY "Staff delete cancel doctors" ON public.cancel_doctors
  FOR DELETE TO authenticated USING (public.is_staff(auth.uid()));

INSERT INTO public.cancel_doctors (name) VALUES
  ('SONRISA SEGURA'),
  ('MI ORTODONCISTA'),
  ('BRANDON MELLADO')
ON CONFLICT DO NOTHING;
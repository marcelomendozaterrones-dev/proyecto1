
-- Update trigger so every new signup becomes admin (signup is gated by master password in frontend)
CREATE OR REPLACE FUNCTION public.handle_new_user_admin()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'admin')
  ON CONFLICT DO NOTHING;
  RETURN NEW;
END;
$function$;

-- Ensure trigger exists on auth.users
DROP TRIGGER IF EXISTS on_auth_user_created_admin ON auth.users;
CREATE TRIGGER on_auth_user_created_admin
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_admin();

-- Grant admin role to existing technician account
INSERT INTO public.user_roles (user_id, role)
VALUES ('870d9b9a-0a93-4c24-bad2-eb6087e2d5cd', 'admin')
ON CONFLICT DO NOTHING;

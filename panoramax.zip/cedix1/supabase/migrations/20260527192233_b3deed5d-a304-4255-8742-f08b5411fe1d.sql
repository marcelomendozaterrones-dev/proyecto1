
CREATE TABLE public.user_sede_access (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  sede text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, sede)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.user_sede_access TO authenticated;
GRANT ALL ON public.user_sede_access TO service_role;

ALTER TABLE public.user_sede_access ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own sede access" ON public.user_sede_access
FOR SELECT TO authenticated USING (auth.uid() = user_id OR public.has_role(auth.uid(),'admin'::app_role));

CREATE POLICY "Admins manage sede access - insert" ON public.user_sede_access
FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'admin'::app_role));

CREATE POLICY "Admins manage sede access - update" ON public.user_sede_access
FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin'::app_role));

CREATE POLICY "Admins manage sede access - delete" ON public.user_sede_access
FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'::app_role));

-- Grant admin role to the two new users
INSERT INTO public.user_roles(user_id, role) VALUES
  ('467ac6ad-b143-4813-9d54-6c9d59e6cffe','admin'),
  ('870d9b9a-0a93-4c24-bad2-eb6087e2d5cd','admin')
ON CONFLICT DO NOTHING;

-- Insert sede restrictions
INSERT INTO public.user_sede_access(user_id, sede) VALUES
  ('467ac6ad-b143-4813-9d54-6c9d59e6cffe','surco'),
  ('3232eb92-1c23-4cd1-be94-a5920a700316','san-borja'),
  ('870d9b9a-0a93-4c24-bad2-eb6087e2d5cd','sjl')
ON CONFLICT DO NOTHING;

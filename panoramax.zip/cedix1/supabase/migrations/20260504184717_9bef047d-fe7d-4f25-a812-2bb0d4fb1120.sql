
DROP POLICY IF EXISTS "Admins can view study files" ON storage.objects;
DROP POLICY IF EXISTS "Admins can upload study files" ON storage.objects;
DROP POLICY IF EXISTS "Admins can update study files" ON storage.objects;
DROP POLICY IF EXISTS "Admins can delete study files" ON storage.objects;

CREATE POLICY "Admins can view study files"
ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'studies' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can upload study files"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'studies' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update study files"
ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'studies' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete study files"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'studies' AND public.has_role(auth.uid(), 'admin'));

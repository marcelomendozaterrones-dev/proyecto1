
-- Roles
CREATE TYPE public.app_role AS ENUM ('admin', 'user');

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE POLICY "Users can view their own roles" ON public.user_roles
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- Studies
CREATE TABLE public.studies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_name TEXT NOT NULL,
  patient_code TEXT NOT NULL,
  birth_date DATE NOT NULL,
  study_type TEXT NOT NULL,
  notes TEXT,
  file_path TEXT NOT NULL,
  file_name TEXT NOT NULL,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_studies_lookup ON public.studies (lower(patient_code), birth_date);
ALTER TABLE public.studies ENABLE ROW LEVEL SECURITY;

-- Only admins can read/write studies via direct DB. Public lookup uses an edge function.
CREATE POLICY "Admins can view all studies" ON public.studies
  FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can insert studies" ON public.studies
  FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin') AND auth.uid() = created_by);
CREATE POLICY "Admins can update studies" ON public.studies
  FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete studies" ON public.studies
  FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- Storage bucket (private)
INSERT INTO storage.buckets (id, name, public) VALUES ('studies', 'studies', false);

CREATE POLICY "Admins can read study files" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'studies' AND public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can upload study files" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'studies' AND public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete study files" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'studies' AND public.has_role(auth.uid(), 'admin'));

-- Auto-grant admin role to the FIRST registered user (so the owner can self-onboard)
CREATE OR REPLACE FUNCTION public.handle_new_user_admin()
RETURNS TRIGGER
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'admin') THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin');
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created_admin
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_admin();


CREATE TABLE public.tarifario_items (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  price numeric NOT NULL DEFAULT 0,
  category text NOT NULL DEFAULT 'General',
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.tarifario_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated read tarifario" ON public.tarifario_items
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins insert tarifario" ON public.tarifario_items
  FOR INSERT TO authenticated WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins update tarifario" ON public.tarifario_items
  FOR UPDATE TO authenticated USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins delete tarifario" ON public.tarifario_items
  FOR DELETE TO authenticated USING (has_role(auth.uid(), 'admin'::app_role));

-- Seed initial data from src/data/tarifario.ts
INSERT INTO public.tarifario_items (code, name, price, category, sort_order) VALUES
('C001','Panorámica',80,'Radiografías',1),
('C002','Cefalométrica',70,'Radiografías',2),
('C003','ATM + Panorámica',140,'Radiografías',3),
('C004','Póstero anterior sin análisis',70,'Radiografías',4),
('C005','Carpal sin análisis',60,'Radiografías',5),
('C006','Pano + fotos extra-intraorales',130,'Radiografías',6),
('C007','Localización de diente Impactado Rx',90,'Radiografías',7),
('C008','Oclusal',50,'Radiografías',8),
('C009','Bitewing',35,'Radiografías',9),
('C010','Seriada',220,'Radiografías',10),
('C011','Seriada + Panorámica',250,'Radiografías',11),
('C012','Periapical',25,'Radiografías',12),
('C013','Periapical RVG',30,'Radiografías',13),
('C014','Análisis 1: Pano + Cef + 2 análisis + Fotos extra',160,'Ortodoncia',14),
('C015','Análisis 2: Pano + Cef + 2 análisis + Fotos extra/intra',200,'Ortodoncia',15),
('C016','Frontal con análisis',100,'Ortodoncia',16),
('C017','Cefalométrica con análisis',130,'Ortodoncia',17),
('C018','Carpal con análisis',80,'Ortodoncia',18),
('C019','Fotos extraorales',40,'Ortodoncia',19),
('C020','Fotos extraorales + intraorales',60,'Ortodoncia',20),
('C021','Tomografía campo pequeño/mediano USB',180,'Tomografía',21),
('C022','Tomografía campo amplio con USB',250,'Tomografía',22),
('C023','Tomografía sin análisis BA/BC con USB',330,'Tomografía',23),
('C024','Tomografía con análisis (1 maxilar) USB',350,'Tomografía',24),
('C025','Tomografía con análisis (2 maxilares) USB',390,'Tomografía',25),
('C026','Tomografía para ortodoncia c/análisis USB',510,'Tomografía',26),
('C027','ATM con análisis BA/BC con USB',510,'Tomografía',27),
('A001','Duplicado USB',50,'Adicionales',28),
('A002','Duplicado CD',30,'Adicionales',29),
('A003','Duplicado Placa',40,'Adicionales',30),
('A004','Análisis adicional',30,'Adicionales',31),
('A005','Duplicado estudio orto placas + documentación',100,'Adicionales',32),
('C028','Panorámica DIGITAL',60,'Entrega Digital',33),
('C029','Cefalométrica DIGITAL',60,'Entrega Digital',34),
('C030','Análisis 1 DIGITAL',140,'Entrega Digital',35),
('C031','Análisis 2 DIGITAL',180,'Entrega Digital',36),
('C032','Tomografía DIGITAL campo amplio',200,'Entrega Digital',37),
('C033','Tomografía DIGITAL campo mediano',120,'Entrega Digital',38),
('F001','Escáner intraoral',180,'Flujo Digital',39),
('F002','Escáner intraoral - Delivery',180,'Flujo Digital',40),
('F003','Escáner de yeso - por arcada',50,'Flujo Digital',41),
('F004','Escáner + impresión 1 maxilar',300,'Flujo Digital',42),
('F005','Escáner + impresión 2 maxilares',420,'Flujo Digital',43),
('F006','Sólo impresión 1 maxilar',200,'Flujo Digital',44),
('F007','Sólo impresión 2 maxilares',350,'Flujo Digital',45),
('F008','Alineadores - Protocolo',400,'Flujo Digital',46),
('F009','Alineadores - Planificación',600,'Flujo Digital',47),
('F010','Alineadores - Impresión',130,'Flujo Digital',48),
('F011','Alineadores - Duplicado',130,'Flujo Digital',49),
('F012','Alineadores - Contención',130,'Flujo Digital',50),
('F013','Análisis ortodóntico - Todos los análisis',150,'Flujo Digital',51),
('F014','Guías quirúrgicas - Protocolo',300,'Flujo Digital',52),
('F015','Guías quirúrgicas - Planificación',500,'Flujo Digital',53),
('F016','Guías quirúrgicas - Impresión',200,'Flujo Digital',54);

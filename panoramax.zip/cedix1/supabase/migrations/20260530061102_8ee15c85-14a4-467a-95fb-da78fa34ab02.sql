CREATE TABLE public.study_shares (
  slug text PRIMARY KEY,
  patient_code text NOT NULL,
  patient_name text NOT NULL,
  doctor_name text,
  study_ids uuid[] NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid
);

GRANT SELECT, INSERT ON public.study_shares TO authenticated;
GRANT ALL ON public.study_shares TO service_role;

ALTER TABLE public.study_shares ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Staff insert shares" ON public.study_shares
  FOR INSERT TO authenticated
  WITH CHECK (is_staff(auth.uid()));

CREATE POLICY "Staff view shares" ON public.study_shares
  FOR SELECT TO authenticated
  USING (is_staff(auth.uid()));

CREATE INDEX idx_study_shares_expires ON public.study_shares(expires_at);
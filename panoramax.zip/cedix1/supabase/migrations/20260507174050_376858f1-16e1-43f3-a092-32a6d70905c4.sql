
-- Custom doctors registry (added via the "+" button)
CREATE TABLE public.custom_doctors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  specialty text,
  phone text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.custom_doctors ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins view doctors" ON public.custom_doctors FOR SELECT TO authenticated USING (has_role(auth.uid(),'admin'));
CREATE POLICY "Admins insert doctors" ON public.custom_doctors FOR INSERT TO authenticated WITH CHECK (has_role(auth.uid(),'admin'));
CREATE POLICY "Admins update doctors" ON public.custom_doctors FOR UPDATE TO authenticated USING (has_role(auth.uid(),'admin'));
CREATE POLICY "Admins delete doctors" ON public.custom_doctors FOR DELETE TO authenticated USING (has_role(auth.uid(),'admin'));

-- Sequential ticket number per sede
CREATE TABLE public.ticket_counters (
  sede text PRIMARY KEY,
  last_number integer NOT NULL DEFAULT 0
);
ALTER TABLE public.ticket_counters ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins read counters" ON public.ticket_counters FOR SELECT TO authenticated USING (has_role(auth.uid(),'admin'));

CREATE OR REPLACE FUNCTION public.next_ticket_number(_sede text)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE n integer;
BEGIN
  INSERT INTO public.ticket_counters(sede,last_number) VALUES (_sede,1)
  ON CONFLICT (sede) DO UPDATE SET last_number = public.ticket_counters.last_number + 1
  RETURNING last_number INTO n;
  RETURN n;
END; $$;

-- Patient registrations (tickets)
CREATE TABLE public.patient_registrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_number integer NOT NULL,
  ticket_code text NOT NULL,
  sede text NOT NULL,
  doc_type text NOT NULL,             -- 'dni' | 'ce' | 'sin'
  doc_number text,
  first_names text NOT NULL,
  last_names text NOT NULL,
  birth_date date,
  age integer,
  phone text,
  doctor_name text,
  items jsonb NOT NULL DEFAULT '[]'::jsonb,    -- [{code,name,price,custom}]
  subtotal numeric(10,2) NOT NULL DEFAULT 0,
  total numeric(10,2) NOT NULL DEFAULT 0,
  special_price boolean NOT NULL DEFAULT false,
  special_reason text,
  payments jsonb NOT NULL DEFAULT '[]'::jsonb, -- [{method,amount}]
  notes text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.patient_registrations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins view regs" ON public.patient_registrations FOR SELECT TO authenticated USING (has_role(auth.uid(),'admin'));
CREATE POLICY "Admins insert regs" ON public.patient_registrations FOR INSERT TO authenticated WITH CHECK (has_role(auth.uid(),'admin') AND auth.uid() = created_by);
CREATE POLICY "Admins update regs" ON public.patient_registrations FOR UPDATE TO authenticated USING (has_role(auth.uid(),'admin'));
CREATE POLICY "Admins delete regs" ON public.patient_registrations FOR DELETE TO authenticated USING (has_role(auth.uid(),'admin'));

CREATE INDEX idx_pat_reg_sede_date ON public.patient_registrations(sede, created_at DESC);


-- 1) Doctors directory: add cop, district, status
ALTER TABLE public.doctors_directory
  ADD COLUMN IF NOT EXISTS cop text,
  ADD COLUMN IF NOT EXISTS district text,
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'nuevo';

-- 2) Quick shares: add doctor_name and share_expires_at (for reuse)
ALTER TABLE public.quick_shares
  ADD COLUMN IF NOT EXISTS doctor_name text,
  ADD COLUMN IF NOT EXISTS share_expires_at timestamptz;

-- 3) Migrate TU DENTARIA PARTICULAR -> TU DENTARIA
UPDATE public.patient_registrations
  SET doctor_name = 'TU DENTARIA'
  WHERE upper(trim(doctor_name)) = 'TU DENTARIA PARTICULAR';

UPDATE public.studies
  SET referring_doctor = 'TU DENTARIA'
  WHERE upper(trim(referring_doctor)) = 'TU DENTARIA PARTICULAR';

-- Remove "TU DENTARIA PARTICULAR" from custom_doctors and doctors_directory (merge)
DELETE FROM public.custom_doctors
  WHERE upper(trim(full_name)) = 'TU DENTARIA PARTICULAR'
    AND EXISTS (SELECT 1 FROM public.custom_doctors c2 WHERE upper(trim(c2.full_name)) = 'TU DENTARIA');

UPDATE public.custom_doctors
  SET full_name = 'TU DENTARIA'
  WHERE upper(trim(full_name)) = 'TU DENTARIA PARTICULAR';

DELETE FROM public.doctors_directory
  WHERE upper(trim(full_name)) = 'TU DENTARIA PARTICULAR'
    AND EXISTS (SELECT 1 FROM public.doctors_directory d2 WHERE upper(trim(d2.full_name)) = 'TU DENTARIA');

UPDATE public.doctors_directory
  SET full_name = 'TU DENTARIA'
  WHERE upper(trim(full_name)) = 'TU DENTARIA PARTICULAR';

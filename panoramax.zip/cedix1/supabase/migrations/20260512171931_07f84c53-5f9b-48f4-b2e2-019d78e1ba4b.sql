revoke all on function public.sync_study_birth_date_from_registration() from public;
revoke all on function public.sync_study_birth_date_from_registration() from anon;
revoke all on function public.sync_study_birth_date_from_registration() from authenticated;
CREATE OR REPLACE FUNCTION public.doctor_register(_full_name text, _cop text, _specialty text, _email text, _phone text, _password text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
DECLARE
  _name text := upper(trim(_full_name));
  _salt text := encode(extensions.gen_random_bytes(8), 'hex');
BEGIN
  IF length(_name) < 3 THEN RAISE EXCEPTION 'Nombre inválido'; END IF;
  IF _password IS NULL OR length(_password) < 6 THEN RAISE EXCEPTION 'La contraseña debe tener mínimo 6 caracteres'; END IF;
  IF EXISTS (SELECT 1 FROM doctor_accounts WHERE full_name = _name) THEN
    RAISE EXCEPTION 'Ya existe una cuenta con ese nombre. Inicia sesión.';
  END IF;
  INSERT INTO doctor_accounts(full_name, cop, specialty, email, phone, pwd_hash, pwd_salt, initial_password, must_change_password)
  VALUES (_name, NULLIF(trim(_cop),''), NULLIF(trim(_specialty),''), NULLIF(trim(_email),''), NULLIF(trim(_phone),''),
          public._sha256_hex(_salt || _password), _salt, NULL, false);
  RETURN jsonb_build_object('full_name', _name);
END; $function$;

CREATE OR REPLACE FUNCTION public.doctor_change_password(_full_name text, _old text, _new text)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
DECLARE r doctor_accounts; _salt text := encode(extensions.gen_random_bytes(8),'hex');
BEGIN
  SELECT * INTO r FROM doctor_accounts WHERE full_name = upper(trim(_full_name));
  IF NOT FOUND THEN RAISE EXCEPTION 'Doctor no registrado'; END IF;
  IF r.pwd_hash <> public._sha256_hex(r.pwd_salt || _old) THEN RAISE EXCEPTION 'Contraseña actual incorrecta'; END IF;
  IF length(_new) < 6 THEN RAISE EXCEPTION 'La nueva contraseña debe tener mínimo 6 caracteres'; END IF;
  UPDATE doctor_accounts SET pwd_hash = public._sha256_hex(_salt || _new), pwd_salt = _salt, must_change_password = false, initial_password = NULL, updated_at = now()
    WHERE id = r.id;
  RETURN true;
END; $function$;
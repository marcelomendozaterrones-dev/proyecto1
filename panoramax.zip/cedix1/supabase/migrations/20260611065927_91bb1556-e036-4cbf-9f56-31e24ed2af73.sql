GRANT SELECT, INSERT, UPDATE, DELETE ON public.studies TO authenticated;
GRANT ALL ON public.studies TO service_role;
GRANT ALL ON public.study_shares TO service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.study_shares TO authenticated;
GRANT ALL ON public.patient_registrations TO service_role;
GRANT ALL ON public.doctor_accounts TO service_role;
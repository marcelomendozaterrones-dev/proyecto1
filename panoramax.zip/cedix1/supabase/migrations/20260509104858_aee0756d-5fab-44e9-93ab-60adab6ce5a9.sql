-- Doctor portal accounts
CREATE TABLE public.doctor_accounts (
  id uuid primary key default gen_random_uuid(),
  full_name text not null unique,
  cop text,
  specialty text,
  email text,
  phone text,
  pwd_hash text not null,
  pwd_salt text not null,
  must_change_password boolean not null default true,
  initial_password text, -- shown once on registration (since email sending not yet enabled)
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

ALTER TABLE public.doctor_accounts ENABLE ROW LEVEL SECURITY;

-- Admins can view/manage everything
CREATE POLICY "Admins view doctor accounts" ON public.doctor_accounts
  FOR SELECT TO authenticated USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Admins manage doctor accounts" ON public.doctor_accounts
  FOR ALL TO authenticated USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- helper: hash sha256 hex
CREATE OR REPLACE FUNCTION public._sha256_hex(_input text) RETURNS text
LANGUAGE sql IMMUTABLE AS $$
  SELECT encode(digest(_input, 'sha256'), 'hex');
$$;

-- Register
CREATE OR REPLACE FUNCTION public.doctor_register(
  _full_name text, _cop text, _specialty text, _email text, _phone text
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _name text := upper(trim(_full_name));
  _salt text := encode(gen_random_bytes(8), 'hex');
  _pwd  text := upper(substr(encode(gen_random_bytes(6), 'hex'), 1, 8));
BEGIN
  IF length(_name) < 3 THEN RAISE EXCEPTION 'Nombre inválido'; END IF;
  IF EXISTS (SELECT 1 FROM doctor_accounts WHERE full_name = _name) THEN
    RAISE EXCEPTION 'Ya existe una cuenta con ese nombre. Inicia sesión.';
  END IF;
  INSERT INTO doctor_accounts(full_name, cop, specialty, email, phone, pwd_hash, pwd_salt, initial_password, must_change_password)
  VALUES (_name, NULLIF(trim(_cop),''), NULLIF(trim(_specialty),''), NULLIF(trim(_email),''), NULLIF(trim(_phone),''),
          _sha256_hex(_salt || _pwd), _salt, _pwd, true);
  RETURN jsonb_build_object('full_name', _name, 'password', _pwd);
END; $$;

-- Login: returns {ok, must_change, full_name} or raises
CREATE OR REPLACE FUNCTION public.doctor_login(_full_name text, _password text)
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE r doctor_accounts;
BEGIN
  SELECT * INTO r FROM doctor_accounts WHERE full_name = upper(trim(_full_name));
  IF NOT FOUND THEN RAISE EXCEPTION 'Doctor no registrado'; END IF;
  IF r.pwd_hash <> _sha256_hex(r.pwd_salt || _password) THEN RAISE EXCEPTION 'Contraseña incorrecta'; END IF;
  RETURN jsonb_build_object('full_name', r.full_name, 'must_change', r.must_change_password, 'email', r.email);
END; $$;

-- Change password
CREATE OR REPLACE FUNCTION public.doctor_change_password(_full_name text, _old text, _new text)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE r doctor_accounts; _salt text := encode(gen_random_bytes(8),'hex');
BEGIN
  SELECT * INTO r FROM doctor_accounts WHERE full_name = upper(trim(_full_name));
  IF NOT FOUND THEN RAISE EXCEPTION 'Doctor no registrado'; END IF;
  IF r.pwd_hash <> _sha256_hex(r.pwd_salt || _old) THEN RAISE EXCEPTION 'Contraseña actual incorrecta'; END IF;
  IF length(_new) < 6 THEN RAISE EXCEPTION 'La nueva contraseña debe tener mínimo 6 caracteres'; END IF;
  UPDATE doctor_accounts SET pwd_hash = _sha256_hex(_salt || _new), pwd_salt = _salt, must_change_password = false, initial_password = NULL, updated_at = now()
    WHERE id = r.id;
  RETURN true;
END; $$;

-- List doctor names (for registration suggestions / global doctor list)
CREATE OR REPLACE FUNCTION public.doctor_list_names() RETURNS TABLE(full_name text)
LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  SELECT full_name FROM doctor_accounts ORDER BY full_name;
$$;

-- Public can call register/login/change-password and list names
GRANT EXECUTE ON FUNCTION public.doctor_register(text,text,text,text,text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.doctor_login(text,text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.doctor_change_password(text,text,text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.doctor_list_names() TO anon, authenticated;

-- Allow anon to read patient_registrations & studies via security-definer functions
CREATE OR REPLACE FUNCTION public.doctor_patients(_doctor_name text)
RETURNS TABLE(
  id uuid, ticket_code text, sede text, first_names text, last_names text,
  doc_number text, age int, items jsonb, total numeric, created_at timestamptz
)
LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  SELECT id, ticket_code, sede, first_names, last_names, doc_number, age, items, total, created_at
  FROM patient_registrations
  WHERE upper(coalesce(doctor_name,'')) = upper(trim(_doctor_name))
  ORDER BY created_at DESC;
$$;

CREATE OR REPLACE FUNCTION public.doctor_patient_studies(_doctor_name text, _patient_code text)
RETURNS TABLE(id uuid, study_type text, file_name text, file_path text, notes text, created_at timestamptz)
LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  SELECT s.id, s.study_type, s.file_name, s.file_path, s.notes, s.created_at
  FROM studies s
  WHERE s.patient_code = _patient_code
    AND EXISTS (
      SELECT 1 FROM patient_registrations p
      WHERE p.ticket_code = _patient_code
        AND upper(coalesce(p.doctor_name,'')) = upper(trim(_doctor_name))
    )
  ORDER BY s.created_at DESC;
$$;

GRANT EXECUTE ON FUNCTION public.doctor_patients(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.doctor_patient_studies(text,text) TO anon, authenticated;

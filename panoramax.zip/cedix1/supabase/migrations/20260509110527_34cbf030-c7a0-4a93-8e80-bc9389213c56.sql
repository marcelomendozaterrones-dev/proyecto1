CREATE OR REPLACE FUNCTION public.doctor_all_known_names()
RETURNS TABLE(full_name text)
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT DISTINCT upper(trim(full_name)) AS full_name FROM doctor_accounts WHERE full_name IS NOT NULL AND length(trim(full_name)) > 0
  UNION
  SELECT DISTINCT upper(trim(full_name)) FROM custom_doctors WHERE full_name IS NOT NULL AND length(trim(full_name)) > 0
  UNION
  SELECT DISTINCT upper(trim(doctor_name)) FROM patient_registrations WHERE doctor_name IS NOT NULL AND length(trim(doctor_name)) > 0
  ORDER BY 1;
$$;

GRANT EXECUTE ON FUNCTION public.doctor_all_known_names() TO anon, authenticated;
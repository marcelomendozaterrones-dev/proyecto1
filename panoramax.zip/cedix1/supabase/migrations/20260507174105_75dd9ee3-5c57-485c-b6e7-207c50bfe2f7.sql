
REVOKE EXECUTE ON FUNCTION public.next_ticket_number(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.next_ticket_number(text) TO authenticated;

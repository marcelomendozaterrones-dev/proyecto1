CREATE TABLE public.quick_shares (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_name text NOT NULL,
  ticket_code text NOT NULL,
  email text,
  phone text,
  study_type text,
  notes text,
  study_ids uuid[] NOT NULL DEFAULT '{}',
  share_slug text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.quick_shares TO authenticated;
GRANT ALL ON public.quick_shares TO service_role;

ALTER TABLE public.quick_shares ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Staff manage quick_shares" ON public.quick_shares
  FOR ALL TO authenticated
  USING (is_staff(auth.uid()))
  WITH CHECK (is_staff(auth.uid()));

CREATE TRIGGER trg_quick_shares_updated_at
  BEFORE UPDATE ON public.quick_shares
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


-- Surveys table for patient attention feedback
CREATE TABLE public.surveys (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  technician TEXT NOT NULL,
  technician_rating INT NOT NULL CHECK (technician_rating BETWEEN 1 AND 5),
  technician_observation TEXT,
  service_rating INT NOT NULL CHECK (service_rating BETWEEN 1 AND 5),
  recommendations TEXT,
  patient_code TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.surveys ENABLE ROW LEVEL SECURITY;

-- Anyone (anon) can submit a survey
CREATE POLICY "Anyone can submit surveys"
ON public.surveys FOR INSERT
TO anon, authenticated
WITH CHECK (true);

-- Only admins can view
CREATE POLICY "Admins can view surveys"
ON public.surveys FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'admin'));

-- Only admins can delete
CREATE POLICY "Admins can delete surveys"
ON public.surveys FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'admin'));

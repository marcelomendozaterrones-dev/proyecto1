UPDATE public.studies s
SET birth_date = p.birth_date
FROM public.patient_registrations p
WHERE p.ticket_code = s.patient_code
  AND p.birth_date IS NOT NULL
  AND s.birth_date <> p.birth_date;
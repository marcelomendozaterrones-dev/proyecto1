ALTER TABLE public.studies
  ADD COLUMN IF NOT EXISTS storage_provider text NOT NULL DEFAULT 'supabase',
  ADD COLUMN IF NOT EXISTS r2_key text;

CREATE INDEX IF NOT EXISTS idx_studies_storage_provider ON public.studies(storage_provider);
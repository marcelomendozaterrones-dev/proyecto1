CREATE OR REPLACE FUNCTION public._sha256_hex(_input text)
RETURNS text
LANGUAGE sql
IMMUTABLE
SET search_path TO 'public', 'extensions'
AS $$
  SELECT encode(extensions.digest(_input, 'sha256'), 'hex');
$$;
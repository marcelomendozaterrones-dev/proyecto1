import { AwsClient } from "https://esm.sh/aws4fetch@1.0.20";
import { r2Config, signR2GetUrl } from "../_shared/r2.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const encodeKey = (key: string) =>
  key.split("/").map((p) => encodeURIComponent(p)).join("/");

async function putR2(key: string, body: Uint8Array, contentType: string) {
  const cfg = r2Config();
  if (!cfg) throw new Error("R2 no configurado");
  const aws = new AwsClient({
    accessKeyId: cfg.accessKeyId,
    secretAccessKey: cfg.secretAccessKey,
    service: "s3",
    region: "auto",
  });
  const url = `${cfg.endpoint}/${cfg.bucket}/${encodeKey(key)}`;
  const res = await aws.fetch(url, {
    method: "PUT",
    headers: { "Content-Type": contentType },
    body,
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new Error(`R2 PUT failed (${res.status}) ${txt}`);
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const form = await req.formData();
    const ticket = String(form.get("ticket_code") || "general").replace(/[^\w-]/g, "_");
    const ts = Date.now();
    const files: { field: string; file: File }[] = [];
    for (const [key, value] of form.entries()) {
      if (value instanceof File) files.push({ field: key, file: value });
    }
    if (files.length === 0) {
      return new Response(JSON.stringify({ error: "Sin archivos" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const expires = 60 * 60 * 24 * 7; // 7 días
    const result: Record<string, { url: string; fileName: string }> = {};

    for (const { field, file } of files) {
      const safeName = file.name.replace(/[^\w.\-]/g, "_");
      const key = `informes/${ticket}/${ts}/${field}-${safeName}`;
      const buf = new Uint8Array(await file.arrayBuffer());
      const ct = file.type || "application/octet-stream";
      await putR2(key, buf, ct);
      const url = await signR2GetUrl(key, file.name, expires, "attachment");
      if (!url) throw new Error("No se pudo firmar URL");
      result[field] = { url, fileName: file.name };
    }

    return new Response(JSON.stringify({ ok: true, files: result, expires_in: expires }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: (e as Error).message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

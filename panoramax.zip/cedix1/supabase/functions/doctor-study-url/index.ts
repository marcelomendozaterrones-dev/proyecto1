import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { signR2GetUrl } from "../_shared/r2.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { token, study_id, download } = await req.json();
    if (!token || !study_id) {
      return new Response(JSON.stringify({ error: "Faltan parámetros" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    // Hash token to validate against doctor_accounts
    const hashHex = async (s: string) => {
      const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
      return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
    };
    const tokenHash = await hashHex(token);

    const { data: doctor, error: dErr } = await supabase
      .from("doctor_accounts")
      .select("full_name, session_expires_at")
      .eq("session_token_hash", tokenHash)
      .maybeSingle();
    if (dErr) throw dErr;
    if (!doctor || !doctor.session_expires_at || new Date(doctor.session_expires_at) < new Date()) {
      return new Response(JSON.stringify({ error: "Sesión inválida o expirada" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: study, error: sErr } = await supabase
      .from("studies")
      .select("file_path, file_name, patient_code, storage_provider, r2_key")
      .eq("id", study_id)
      .maybeSingle();
    if (sErr) throw sErr;
    if (!study) {
      return new Response(JSON.stringify({ error: "Estudio no encontrado" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Verify the doctor is the requesting doctor on that patient
    const { data: reg } = await supabase
      .from("patient_registrations")
      .select("doctor_name")
      .eq("ticket_code", study.patient_code)
      .limit(1)
      .maybeSingle();
    const docName = (reg?.doctor_name ?? "").trim().toUpperCase();
    if (docName !== doctor.full_name.trim().toUpperCase()) {
      return new Response(JSON.stringify({ error: "No autorizado para este estudio" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    let url: string | null = null;
    const r2Key = (study as any).r2_key || study.file_path;
    const disposition: "inline" | "attachment" = download ? "attachment" : "inline";

    if ((study as any).storage_provider === "r2") {
      url = await signR2GetUrl(r2Key, (study as any).file_name, 3600, disposition);
    } else {
      const { data: signed, error: uErr } = await supabase.storage
        .from("studies")
        .createSignedUrl(study.file_path, 300, download ? { download: (study as any).file_name } : undefined);
      if (uErr || !signed?.signedUrl) {
        // Fallback: try R2 with the same key (file may have been migrated
        // without updating storage_provider, or never existed in Supabase).
        console.warn("Supabase storage miss, falling back to R2:", uErr?.message);
        url = await signR2GetUrl(r2Key, (study as any).file_name, 3600, disposition);
      } else {
        url = signed.signedUrl;
      }
    }
    if (!url) {
      return new Response(JSON.stringify({ error: "Archivo no disponible en el almacenamiento" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ url }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: (e as Error).message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

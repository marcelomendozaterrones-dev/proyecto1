import { AwsClient } from "https://esm.sh/aws4fetch@1.0.20";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const endpoint = Deno.env.get("R2_ACCOUNT_ENDPOINT")!.replace(/\/$/, "");
    const bucket = Deno.env.get("R2_BUCKET")!;
    const accessKeyId = Deno.env.get("R2_ACCESS_KEY_ID")!;
    const secretAccessKey = Deno.env.get("R2_SECRET_ACCESS_KEY")!;

    const { key, content_type } = await req.json();
    if (!key || typeof key !== "string") {
      return new Response(JSON.stringify({ error: "Falta 'key'" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const safeKey = key.replace(/^\/+/, "");
    const url = new URL(`${endpoint}/${bucket}/${encodeURI(safeKey)}`);
    // Presign as query (valid 1h)
    url.searchParams.set("X-Amz-Expires", "3600");

    const aws = new AwsClient({
      accessKeyId,
      secretAccessKey,
      service: "s3",
      region: "auto",
    });

    const signed = await aws.sign(
      new Request(url, { method: "PUT", headers: content_type ? { "Content-Type": content_type } : undefined }),
      { aws: { signQuery: true } },
    );

    return new Response(JSON.stringify({ url: signed.url, method: "PUT", key: safeKey }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: (e as Error).message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { signR2GetUrl } from "../_shared/r2.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const normalizeDate = (value: string) => {
  const trimmed = value.trim();
  const iso = trimmed.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (iso) return `${iso[1]}-${iso[2]}-${iso[3]}`;
  const dmy = trimmed.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})$/);
  if (!dmy) return null;
  const year = dmy[3].length === 2 ? `20${dmy[3]}` : dmy[3];
  return `${year}-${dmy[2].padStart(2, "0")}-${dmy[1].padStart(2, "0")}`;
};

const digitsOnly = (value: string) => value.replace(/\D/g, "");
const canonicalDigits = (value: string) => digitsOnly(value).replace(/^0+/, "");

const codeMatches = (input: string, stored: string) => {
  const inputText = input.trim().toLowerCase();
  const storedText = stored.trim().toLowerCase();
  if (inputText === storedText) return true;

  const inputDigits = canonicalDigits(input);
  const storedDigits = canonicalDigits(stored);
  if (!inputDigits || !storedDigits) return false;
  return inputDigits === storedDigits || storedDigits.endsWith(inputDigits);
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { code, birth_date } = await req.json();
    if (!code || !birth_date || typeof code !== "string" || typeof birth_date !== "string") {
      return new Response(JSON.stringify({ error: "Código y fecha de nacimiento son requeridos" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const normalizedBirthDate = normalizeDate(birth_date);
    if (!normalizedBirthDate) {
      return new Response(JSON.stringify({ error: "Fecha de nacimiento inválida" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: registrations, error: regError } = await supabase
      .from("patient_registrations")
      .select("ticket_code")
      .eq("birth_date", normalizedBirthDate)
      .limit(1000);

    if (regError) throw regError;

    const matchedCodes = (registrations ?? [])
      .map((r) => r.ticket_code)
      .filter((ticketCode) => typeof ticketCode === "string" && codeMatches(code, ticketCode));

    const studyBirthDate = matchedCodes.length > 0 ? undefined : normalizedBirthDate;

    let studiesQuery = supabase
      .from("studies")
      .select("id, patient_name, patient_code, study_type, notes, file_name, file_path, created_at, birth_date, storage_provider, r2_key")
      .eq("birth_date", studyBirthDate ?? normalizedBirthDate)
      .order("created_at", { ascending: false });

    if (matchedCodes.length > 0) {
      const codeFilters = matchedCodes.map((ticketCode) => `patient_code.eq.${ticketCode.replace(/,/g, "")}`);
      studiesQuery = studiesQuery.or(codeFilters.join(","));
    }

    const { data: studiesData, error } = await studiesQuery;

    if (error) throw error;

    const studies = (studiesData ?? []).filter((s) =>
      matchedCodes.length > 0 ? matchedCodes.includes(s.patient_code) : codeMatches(code, s.patient_code)
    );

    const results = await Promise.all(
      (studies ?? []).map(async (s: any) => {
        let url: string | null = null;
        if (s.storage_provider === "r2" && s.r2_key) {
          url = await signR2GetUrl(s.r2_key, s.file_name);
        } else {
          const { data: signed } = await supabase.storage
            .from("studies")
            .createSignedUrl(s.file_path, 60 * 60);
          url = signed?.signedUrl ?? null;
        }
        return {
          id: s.id,
          patient_name: s.patient_name,
          patient_code: s.patient_code,
          study_type: s.study_type,
          notes: s.notes,
          file_name: s.file_name,
          created_at: s.created_at,
          url,
        };
      })
    );

    return new Response(JSON.stringify({ studies: results }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: (e as Error).message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { AwsClient } from "https://esm.sh/aws4fetch@1.0.20";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function sanitizeFilename(name: string) {
  const cleaned = name.replace(/[\x00-\x1f\x7f]/g, "").trim();
  const ascii = cleaned.replace(/[^\x20-\x7e]/g, "_").replace(/"/g, "");
  return { ascii: ascii || "archivo", needsExt: cleaned !== ascii, original: cleaned };
}

async function signR2Url(
  key: string,
  fileName?: string | null,
  disposition: "inline" | "attachment" = "inline",
): Promise<string | null> {
  const endpoint = Deno.env.get("R2_ACCOUNT_ENDPOINT");
  const bucket = Deno.env.get("R2_BUCKET");
  const accessKeyId = Deno.env.get("R2_ACCESS_KEY_ID");
  const secretAccessKey = Deno.env.get("R2_SECRET_ACCESS_KEY");
  if (!endpoint || !bucket || !accessKeyId || !secretAccessKey) return null;
  const encodedKey = key.split("/").map((p) => encodeURIComponent(p)).join("/");
  const qs: string[] = ["X-Amz-Expires=3600"];
  if (fileName) {
    const { ascii, needsExt, original } = sanitizeFilename(fileName);
    let disp = `${disposition}; filename="${ascii}"`;
    if (needsExt) {
      disp += `; filename*=UTF-8''${encodeURIComponent(original).replace(/\+/g, "%20")}`;
    }
    qs.push(`response-content-disposition=${encodeURIComponent(disp).replace(/\+/g, "%20")}`);
  }
  const urlStr = `${endpoint.replace(/\/$/, "")}/${bucket}/${encodedKey}?${qs.join("&")}`;
  const aws = new AwsClient({ accessKeyId, secretAccessKey, service: "s3", region: "auto" });
  const signed = await aws.sign(new Request(urlStr, { method: "GET" }), { aws: { signQuery: true } });
  return signed.url;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const url = new URL(req.url);
    let slug = url.searchParams.get("slug");
    if (!slug && req.method === "POST") {
      const body = await req.json().catch(() => ({}));
      slug = body.slug;
    }
    if (!slug) {
      return new Response(JSON.stringify({ error: "Falta el código del enlace" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: share, error: shErr } = await supabase
      .from("study_shares")
      .select("slug, patient_code, patient_name, doctor_name, study_ids, expires_at")
      .eq("slug", slug)
      .maybeSingle();
    if (shErr) throw shErr;
    if (!share) {
      return new Response(JSON.stringify({ error: "Enlace no encontrado" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (new Date(share.expires_at) < new Date()) {
      return new Response(JSON.stringify({ error: "Este enlace expiró" }), {
        status: 410, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const ids: string[] = share.study_ids ?? [];
    const { data: studies, error: stErr } = await supabase
      .from("studies")
      .select("id, file_name, file_path, study_type, created_at, storage_provider, r2_key")
      .in("id", ids);
    if (stErr) throw stErr;
    console.log("resolve-share", { slug, ids, found: studies?.length, studies });

    const list = studies ?? [];

    const signed = await Promise.all(
      list.map(async (s: any) => {
        let url: string | null = null;
        let download_url: string | null = null;
        if (s.storage_provider === "r2" && s.r2_key) {
          url = await signR2Url(s.r2_key, s.file_name, "inline");
          download_url = await signR2Url(s.r2_key, s.file_name, "attachment");
        } else {
          const { data: inlineData } = await supabase.storage
            .from("studies").createSignedUrl(s.file_path, 60 * 60);
          url = inlineData?.signedUrl ?? null;
          const { data: dlData } = await supabase.storage
            .from("studies").createSignedUrl(s.file_path, 60 * 60, { download: s.file_name ?? true });
          download_url = dlData?.signedUrl ?? null;
        }
        return {
          id: s.id,
          file_name: s.file_name,
          study_type: s.study_type,
          created_at: s.created_at,
          url,
          download_url,
        };
      })
    );

    return new Response(
      JSON.stringify({
        patient_name: share.patient_name,
        patient_code: share.patient_code,
        doctor_name: share.doctor_name,
        expires_at: share.expires_at,
        studies: signed,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: (e as Error).message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

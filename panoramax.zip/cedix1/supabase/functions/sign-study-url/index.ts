import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { signR2GetUrl, deleteR2Object } from "../_shared/r2.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const jwt = authHeader.replace(/^Bearer\s+/i, "");
    if (!jwt) {
      return new Response(JSON.stringify({ error: "No autorizado" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: userData, error: uErr } = await supabase.auth.getUser(jwt);
    if (uErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "Sesión inválida" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const { data: roleRow } = await supabase
      .from("user_roles").select("role").eq("user_id", userData.user.id).eq("role", "admin").maybeSingle();
    if (!roleRow) {
      return new Response(JSON.stringify({ error: "Sin permisos" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json().catch(() => ({}));
    const { study_id, action = "sign", download } = body as { study_id?: string; action?: "sign" | "delete"; download?: boolean };
    if (!study_id) {
      return new Response(JSON.stringify({ error: "Falta study_id" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: study, error: sErr } = await supabase
      .from("studies")
      .select("id, file_path, file_name, storage_provider, r2_key")
      .eq("id", study_id)
      .maybeSingle();
    if (sErr) throw sErr;
    if (!study) {
      return new Response(JSON.stringify({ error: "Estudio no encontrado" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "delete") {
      if (study.storage_provider === "r2" && study.r2_key) {
        await deleteR2Object(study.r2_key);
      } else if (study.file_path) {
        await supabase.storage.from("studies").remove([study.file_path]);
      }
      await supabase.from("studies").delete().eq("id", study_id);
      return new Response(JSON.stringify({ ok: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    let url: string | null = null;
    const disposition: "inline" | "attachment" = download ? "attachment" : "inline";
    if (study.storage_provider === "r2" && study.r2_key) {
      url = await signR2GetUrl(study.r2_key, study.file_name, 3600, disposition);
    } else if (study.file_path) {
      const { data } = await supabase.storage.from("studies").createSignedUrl(
        study.file_path, 600, download ? { download: study.file_name ?? true } : undefined,
      );
      url = data?.signedUrl ?? null;
    }
    if (!url) {
      return new Response(JSON.stringify({ error: "No se pudo generar enlace" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    return new Response(JSON.stringify({ url }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: (e as Error).message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

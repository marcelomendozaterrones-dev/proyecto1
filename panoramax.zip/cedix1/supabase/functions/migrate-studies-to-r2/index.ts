import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { AwsClient } from "https://esm.sh/aws4fetch@1.0.20";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const MASTER_KEY = "CEDIX123.";
const SUPABASE_BUCKET = "studies";
const CHUNK_SIZE = 1;          // one file at a time to keep memory flat
const CHUNK_PAUSE_MS = 1000;   // pause between internal chunks
const PER_FILE_TIMEOUT_MS = 60_000;

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function withTimeout<T>(p: Promise<T>, ms: number, label: string): Promise<T> {
  return await Promise.race([
    p,
    new Promise<T>((_, rej) => setTimeout(() => rej(new Error(`${label} timeout ${ms}ms`)), ms)),
  ]);
}

function encodeObjectKey(key: string) {
  return key.split("/").map((part) => encodeURIComponent(part)).join("/");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const body = await req.json().catch(() => ({}));
    const admin_key = body.admin_key as string | undefined;
    const limit = Math.min(Math.max(Number(body.limit ?? 5), 1), 10);
    const dry_run = Boolean(body.dry_run);

    if (admin_key !== MASTER_KEY) {
      return new Response(JSON.stringify({ error: "No autorizado" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const endpoint = Deno.env.get("R2_ACCOUNT_ENDPOINT")!.replace(/\/$/, "");
    const r2Bucket = Deno.env.get("R2_BUCKET")!;
    const aws = new AwsClient({
      accessKeyId: Deno.env.get("R2_ACCESS_KEY_ID")!,
      secretAccessKey: Deno.env.get("R2_SECRET_ACCESS_KEY")!,
      service: "s3",
      region: "auto",
    });

    // Migrate ALL pending studies (no date filter) — anything still on Supabase Storage
    const { data: rows, error: qErr } = await supabase
      .from("studies")
      .select("id, file_path, file_name, created_at, storage_provider")
      .eq("storage_provider", "supabase")
      .order("created_at", { ascending: true })
      .limit(limit);
    if (qErr) throw qErr;

    const total = rows?.length ?? 0;
    const results: Array<Record<string, unknown>> = [];
    let migrated = 0;
    let failed = 0;

    const processOne = async (row: any) => {
      const key = (row.file_path as string).replace(/^\/+/, "");
      try {
        if (dry_run) {
          results.push({ id: row.id, key, status: "would_migrate" });
          return;
        }

        // 1. Create a temporary signed URL and stream from Supabase Storage.
        // Avoid download()/Blob because large studies exceed Edge memory.
        const { data: signedSource, error: signErr } = await withTimeout(
          supabase.storage.from(SUPABASE_BUCKET).createSignedUrl(key, 600),
          PER_FILE_TIMEOUT_MS,
          "source sign",
        );
        if (signErr || !signedSource?.signedUrl) {
          throw new Error(`source sign: ${signErr?.message ?? "no signed url"}`);
        }

        const sourceRes = await withTimeout(fetch(signedSource.signedUrl), PER_FILE_TIMEOUT_MS, "source fetch");
        if (!sourceRes.ok || !sourceRes.body) {
          throw new Error(`source fetch ${sourceRes.status}: ${(await sourceRes.text()).slice(0, 200)}`);
        }

        const sourceLen = Number(sourceRes.headers.get("content-length") ?? "0");
        if (!Number.isFinite(sourceLen) || sourceLen <= 0) {
          await sourceRes.body.cancel().catch(() => undefined);
          throw new Error("source missing content-length; not safe to delete original");
        }
        const contentType = sourceRes.headers.get("content-type") || "application/octet-stream";
        const objectUrl = `${endpoint}/${r2Bucket}/${encodeObjectKey(key)}`;

        // 2. Upload to R2 via presigned URL (no payload hashing in worker)
        const putUrl = new URL(objectUrl);
        putUrl.searchParams.set("X-Amz-Expires", "3600");
        const signed = await aws.sign(
          new Request(putUrl, { method: "PUT", headers: { "Content-Type": contentType } }),
          { aws: { signQuery: true } },
        );
        const putRes = await withTimeout(
          fetch(signed.url, {
            method: "PUT",
            body: sourceRes.body,
            headers: { "Content-Type": contentType, "Content-Length": String(sourceLen) },
            // Required when streaming a request body in fetch-compatible runtimes.
            duplex: "half",
          } as RequestInit & { duplex: "half" }),
          PER_FILE_TIMEOUT_MS,
          "r2 put",
        );
        if (!putRes.ok) {
          const txt = await putRes.text();
          throw new Error(`r2 put ${putRes.status}: ${txt.slice(0, 200)}`);
        }
        await putRes.body?.cancel();

        // 3. Verify by HEAD
        const headRes = await withTimeout(
          aws.fetch(objectUrl, { method: "HEAD" }),
          15_000,
          "r2 head",
        );
        if (!headRes.ok) throw new Error(`r2 head ${headRes.status}`);
        const remoteLen = Number(headRes.headers.get("content-length") ?? "0");
        if (remoteLen !== sourceLen) {
          throw new Error(`size mismatch source=${sourceLen} remote=${remoteLen}`);
        }

        // 4. Update DB
        const { error: uErr } = await supabase
          .from("studies")
          .update({ storage_provider: "r2", r2_key: key })
          .eq("id", row.id);
        if (uErr) throw new Error(`db update: ${uErr.message}`);

        // 5. Delete from Supabase Storage
        const { error: rmErr } = await supabase.storage
          .from(SUPABASE_BUCKET)
          .remove([key]);
        if (rmErr) {
          console.error("remove failed", row.id, rmErr.message);
          results.push({ id: row.id, key, status: "migrated_remove_failed", error: rmErr.message });
          migrated++;
          return;
        }

        results.push({ id: row.id, key, status: "migrated", bytes: sourceLen });
        migrated++;
      } catch (e) {
        failed++;
        const msg = (e as Error).message;
        console.error("migration failed", row.id, msg);
        results.push({ id: row.id, key, status: "failed", error: msg });
      }
    };

    // Process in internal chunks with a pause between them
    const allRows = rows ?? [];
    for (let i = 0; i < allRows.length; i += CHUNK_SIZE) {
      const chunk = allRows.slice(i, i + CHUNK_SIZE);
      for (const row of chunk) {
        await processOne(row);
      }
      if (i + CHUNK_SIZE < allRows.length) {
        await sleep(CHUNK_PAUSE_MS);
      }
    }

    return new Response(JSON.stringify({ total, migrated, failed, dry_run, results }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: (e as Error).message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

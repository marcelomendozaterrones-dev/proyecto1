import * as React from 'npm:react@18.3.1'
import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Preview,
  Section,
  Text,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

interface Props {
  recipientName?: string
  patientName?: string
  ticketCode?: string
  studies?: string[]
  shareUrl?: string
  daysValid?: number
  sedeName?: string
  isDoctor?: boolean
}

const Email = ({
  recipientName,
  patientName = 'Paciente',
  ticketCode = '',
  studies = [],
  shareUrl = '#',
  daysValid = 30,
  sedeName = 'CEDIX',
  isDoctor = false,
}: Props) => {
  const greeting = isDoctor
    ? `Dr(a). ${recipientName || ''}`.trim()
    : recipientName || patientName

  return (
    <Html lang="es">
      <Head />
      <Preview>
        Estudios de {patientName} - CEDIX (Talón {ticketCode})
      </Preview>
      <Body style={main}>
        <Container style={container}>
          <Section style={header}>
            <Heading style={brand}>CEDIX</Heading>
            <Text style={tagline}>Centro Radiológico Odontológico</Text>
          </Section>

          <Section style={card}>
            <Text style={hello}>Buen día {greeting} 👋</Text>
            <Text style={paragraph}>
              Le compartimos los estudios del paciente{' '}
              <strong>{patientName}</strong>
              {ticketCode ? <> (Talón {ticketCode})</> : null} desde nuestra
              sede <strong>{sedeName}</strong>.
            </Text>

            {studies.length > 0 && (
              <Section style={studiesBox}>
                <Text style={studiesTitle}>Estudios incluidos:</Text>
                {studies.map((s, i) => (
                  <Text key={i} style={studyItem}>• {s}</Text>
                ))}
              </Section>
            )}

            <Section style={{ textAlign: 'center', margin: '28px 0' }}>
              <Button href={shareUrl} style={button}>
                Ver / Descargar estudios
              </Button>
            </Section>

            <Text style={small}>
              Enlace válido por {daysValid} día{daysValid !== 1 ? 's' : ''}.
            </Text>
            <Text style={smallMuted}>
              Si el botón no funciona, copie este enlace en su navegador:<br />
              <span style={{ wordBreak: 'break-all', color: '#0ea5e9' }}>{shareUrl}</span>
            </Text>

            <Hr style={hr} />
            <Text style={footerNote}>
              Gracias por confiar en nosotros 🤗 — Equipo CEDIX
            </Text>
          </Section>
        </Container>
      </Body>
    </Html>
  )
}

export const template = {
  component: Email,
  subject: (d: Props) =>
    `Estudios de ${d?.patientName || 'paciente'} - CEDIX${d?.ticketCode ? ` (Talón ${d.ticketCode})` : ''}`,
  displayName: 'Envío de estudios',
  previewData: {
    recipientName: 'Juan Pérez',
    patientName: 'María García',
    ticketCode: '12345',
    studies: ['RX PANORÁMICA', 'TOMOGRAFÍA'],
    shareUrl: 'https://cedix.app/v/ABC123',
    daysValid: 30,
    sedeName: 'San Juan de Lurigancho',
    isDoctor: true,
  },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, Helvetica, sans-serif' }
const container = { maxWidth: '560px', margin: '0 auto', padding: '24px 16px' }
const header = { textAlign: 'center' as const, paddingBottom: '8px' }
const brand = { color: '#0ea5e9', fontSize: '32px', fontWeight: 800, margin: 0, letterSpacing: '2px' }
const tagline = { color: '#64748b', fontSize: '13px', margin: '4px 0 16px' }
const card = { background: '#f8fafc', borderRadius: '14px', padding: '24px', border: '1px solid #e2e8f0' }
const hello = { fontSize: '16px', color: '#0f172a', margin: '0 0 12px', fontWeight: 600 }
const paragraph = { fontSize: '15px', color: '#334155', lineHeight: '1.6', margin: '0 0 16px' }
const studiesBox = { background: '#ffffff', borderRadius: '10px', padding: '14px 16px', border: '1px solid #e2e8f0', margin: '12px 0' }
const studiesTitle = { fontSize: '13px', color: '#64748b', fontWeight: 700, margin: '0 0 6px', textTransform: 'uppercase' as const }
const studyItem = { fontSize: '14px', color: '#0f172a', margin: '2px 0' }
const button = { backgroundColor: '#0ea5e9', color: '#ffffff', padding: '14px 28px', borderRadius: '10px', textDecoration: 'none', fontWeight: 700, fontSize: '15px', display: 'inline-block' }
const small = { fontSize: '13px', color: '#475569', textAlign: 'center' as const, margin: '8px 0' }
const smallMuted = { fontSize: '12px', color: '#64748b', textAlign: 'center' as const, margin: '8px 0 0' }
const hr = { borderColor: '#e2e8f0', margin: '20px 0' }
const footerNote = { fontSize: '13px', color: '#64748b', textAlign: 'center' as const, margin: 0 }

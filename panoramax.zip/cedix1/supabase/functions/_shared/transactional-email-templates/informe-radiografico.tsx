import * as React from 'npm:react@18.3.1'
import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Preview,
  Section,
  Text,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

interface Props {
  patientName?: string
  age?: string | number
  ticketCode?: string
  doctorName?: string
  date?: string
  motivo?: string
  sedeName?: string
  docxUrl?: string
  panoUrl?: string
}

const Email = ({
  patientName = '',
  age = '',
  ticketCode = '',
  doctorName = '',
  date = '',
  motivo = '',
  sedeName = 'Panoramax 3D',
  docxUrl = '',
  panoUrl = '',
}: Props) => {
  return (
    <Html lang="es">
      <Head />
      <Preview>Solicitud de informe radiográfico - {patientName}</Preview>
      <Body style={main}>
        <Container style={container}>
          <Section style={header}>
            <Heading style={brand}>PANORAMAX 3D</Heading>
            <Text style={tagline}>Centro Radiológico Odontológico — {sedeName}</Text>
          </Section>

          <Section style={card}>
            <Heading as="h2" style={title}>INFORME ODONTOLÓGICO RADIOGRÁFICO</Heading>

            <Section style={dataBox}>
              <Text style={row}><strong>Paciente:</strong> {patientName}</Text>
              <Text style={row}><strong>Edad:</strong> {age ? `${age} años` : ''}    <strong>Código:</strong> {ticketCode}</Text>
              <Text style={row}><strong>Doctor(a):</strong> {doctorName}    <strong>Fecha:</strong> {date}</Text>
            </Section>

            <Text style={paragraph}>
              A la evaluación de la Radiografía Panorámica se observa:
            </Text>

            <Section style={motivoBox}>
              <Text style={motivoLabel}>MOTIVO DE CONSULTA:</Text>
              <Text style={motivoText}>{motivo || '—'}</Text>
            </Section>

            {(docxUrl || panoUrl) && (
              <Section style={attachBox}>
                <Text style={attachLabel}>ARCHIVOS ADJUNTOS:</Text>
                {docxUrl ? (
                  <Button href={docxUrl} style={btn}>📄 Descargar Informe (Word)</Button>
                ) : null}
                {panoUrl ? (
                  <Button href={panoUrl} style={{ ...btn, background: '#0ea5e9' }}>🦷 Descargar Radiografía Panorámica</Button>
                ) : null}
                <Text style={note}>Enlaces válidos por 7 días.</Text>
              </Section>
            )}

            <Hr style={hr} />
            <Text style={footerNote}>Equipo Panoramax 3D</Text>
          </Section>
        </Container>
      </Body>
    </Html>
  )
}

export const template = {
  component: Email,
  subject: (d: Props) =>
    `Solicitud de informe - ${d?.patientName || 'paciente'}${d?.ticketCode ? ` (${d.ticketCode})` : ''}`,
  displayName: 'Enviar informe',
  previewData: {
    patientName: 'María García',
    age: 35,
    ticketCode: '12345',
    doctorName: 'Dr. Juan Pérez',
    date: new Date().toLocaleDateString('es-PE'),
    motivo: 'Evaluación de terceras molares.',
    sedeName: 'San Juan de Lurigancho',
    docxUrl: 'https://example.com/informe.docx',
    panoUrl: 'https://example.com/pano.jpg',
  },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, Helvetica, sans-serif' }
const container = { maxWidth: '620px', margin: '0 auto', padding: '24px 16px' }
const header = { textAlign: 'center' as const, paddingBottom: '8px' }
const brand = { color: '#0fa895', fontSize: '32px', fontWeight: 800, margin: 0, letterSpacing: '2px' }
const tagline = { color: '#64748b', fontSize: '13px', margin: '4px 0 16px' }
const card = { background: '#f8fafc', borderRadius: '14px', padding: '24px', border: '1px solid #e2e8f0' }
const title = { fontSize: '17px', color: '#0f172a', textAlign: 'center' as const, textDecoration: 'underline', margin: '0 0 18px' }
const dataBox = { background: '#ffffff', borderRadius: '10px', padding: '14px 16px', border: '1px solid #e2e8f0', margin: '0 0 16px' }
const row = { fontSize: '14px', color: '#0f172a', margin: '4px 0', lineHeight: '1.5' }
const paragraph = { fontSize: '15px', color: '#334155', margin: '12px 0 8px', fontWeight: 600 }
const motivoBox = { background: '#ffffff', borderRadius: '10px', padding: '14px 16px', border: '1px solid #e2e8f0', margin: '8px 0' }
const motivoLabel = { fontSize: '13px', color: '#64748b', fontWeight: 700, margin: '0 0 6px', textTransform: 'uppercase' as const }
const motivoText = { fontSize: '15px', color: '#0f172a', margin: 0, lineHeight: '1.6', whiteSpace: 'pre-wrap' as const }
const attachBox = { background: '#ffffff', borderRadius: '10px', padding: '14px 16px', border: '1px solid #e2e8f0', margin: '12px 0', textAlign: 'center' as const }
const attachLabel = { fontSize: '13px', color: '#64748b', fontWeight: 700, margin: '0 0 10px', textTransform: 'uppercase' as const }
const btn = { background: '#16a34a', color: '#ffffff', padding: '12px 18px', borderRadius: '8px', fontSize: '14px', fontWeight: 700, textDecoration: 'none', display: 'inline-block', margin: '6px 4px' }
const note = { fontSize: '12px', color: '#64748b', margin: '8px 0 0' }
const hr = { borderColor: '#e2e8f0', margin: '20px 0' }
const footerNote = { fontSize: '13px', color: '#64748b', textAlign: 'center' as const, margin: 0 }

import { template as studyShare } from './study-share.tsx'
import { template as informeRadiografico } from './informe-radiografico.tsx'

export interface TemplateEntry {
  component: any
  subject: string | ((data: any) => string)
  displayName?: string
  previewData?: Record<string, any>
  to?: string
}

export const TEMPLATES: Record<string, TemplateEntry> = {
  'study-share': studyShare,
  'informe-radiografico': informeRadiografico,
}

import { AwsClient } from "https://esm.sh/aws4fetch@1.0.20";

export function r2Config() {
  const endpoint = Deno.env.get("R2_ACCOUNT_ENDPOINT");
  const bucket = Deno.env.get("R2_BUCKET");
  const accessKeyId = Deno.env.get("R2_ACCESS_KEY_ID");
  const secretAccessKey = Deno.env.get("R2_SECRET_ACCESS_KEY");
  if (!endpoint || !bucket || !accessKeyId || !secretAccessKey) return null;
  return { endpoint: endpoint.replace(/\/$/, ""), bucket, accessKeyId, secretAccessKey };
}

const encodeKey = (key: string) =>
  key.split("/").map((p) => encodeURIComponent(p)).join("/");

function sanitizeFilename(name: string): { ascii: string; needsExt: boolean; original: string } {
  // Strip control chars (incl. \x7f DEL) and trim
  const cleaned = name.replace(/[\x00-\x1f\x7f]/g, "").trim();
  // ASCII-safe fallback: replace any non-ASCII char with "_"
  const ascii = cleaned.replace(/[^\x20-\x7e]/g, "_").replace(/"/g, "");
  const needsExt = cleaned !== ascii;
  return { ascii: ascii || "archivo", needsExt, original: cleaned };
}

export async function signR2GetUrl(
  key: string,
  fileName?: string | null,
  expires = 3600,
  disposition: "inline" | "attachment" = "inline",
): Promise<string | null> {
  const cfg = r2Config();
  if (!cfg) return null;
  const qs: string[] = [`X-Amz-Expires=${expires}`];
  if (fileName) {
    const { ascii, needsExt, original } = sanitizeFilename(fileName);
    let disp = `${disposition}; filename="${ascii}"`;
    if (needsExt) {
      disp += `; filename*=UTF-8''${encodeURIComponent(original).replace(/\+/g, "%20")}`;
    }
    qs.push(`response-content-disposition=${encodeURIComponent(disp).replace(/\+/g, "%20")}`);
  }
  const urlStr = `${cfg.endpoint}/${cfg.bucket}/${encodeKey(key)}?${qs.join("&")}`;
  const aws = new AwsClient({
    accessKeyId: cfg.accessKeyId,
    secretAccessKey: cfg.secretAccessKey,
    service: "s3",
    region: "auto",
  });
  const signed = await aws.sign(new Request(urlStr, { method: "GET" }), { aws: { signQuery: true } });
  return signed.url;
}

export async function deleteR2Object(key: string): Promise<boolean> {
  const cfg = r2Config();
  if (!cfg) return false;
  const aws = new AwsClient({
    accessKeyId: cfg.accessKeyId,
    secretAccessKey: cfg.secretAccessKey,
    service: "s3",
    region: "auto",
  });
  const url = `${cfg.endpoint}/${cfg.bucket}/${encodeKey(key)}`;
  const res = await aws.fetch(url, { method: "DELETE" });
  return res.ok || res.status === 404;
}
